#ifndef CLUSTERERS_H
#define CLUSTERERS_H

#include "common.h"

#define MAX_DISTANCE_CLUSTERING 0.2

#define VERBOSE true 
#define LENGTH_WEIGHT 1
#define DEPTH_WEIGHT 2
#define FILENAME_WEIGHT 5
#define FLAGS_WEIGHT 1
#define RETVALUE_WEIGHT 0.5
#define ADDRESS_WEIGHT 1
#define FILEDES_WEIGHT 1
#define COMMAND_WEIGHT 1
#define EUID_WEIGHT 1
#define GID_WEIGHT 1
#define UID_WEIGHT 1
#define NGROUPS_WEIGHT 1
#define EGID_WEIGHT 1
#define LENGTH1_WEIGHT 1
#define DEPTH1_WEIGHT 2
#define FILENAME1_WEIGHT 5
#define LENGTH2_WEIGHT 1
#define DEPTH2_WEIGHT 2
#define FILENAME2_WEIGHT 5
#define COMMAND_WEIGHT 1
#define ARG_WEIGHT 1
#define PID_WEIGHT 1
#define OWNER_WEIGHT 1
#define GROUP_WEIGHT 1
#define SOCKET_TYPE_WEIGHT 1
#define PORT_WEIGHT 1
#define ADDRESS_WEIGHT 1
#define FD_WEIGHT 1
#define PRIORITY_WEIGHT 1
#define FILEMODE_WEIGHT 1
#define FILE_OWNER_ID_WEIGHT 1
#define FILE_GROUP_ID_WEIGHT 1
#define EUID_WEIGHT 1
#define EGID_WEIGHT 1
#define RUID_WEIGHT 1
#define RGID_WEIGHT 1


/**
############################## CLOSE SysCall ###################################
**/


struct close_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct close_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct close_cluster* close_cluster(struct close_entry * entries, int size, int *max_clusters_number);

struct close_cluster * model_close_clusters(struct close_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct close_transformed_entry * close_transform_data(struct close_entry * entries, int size);

struct close_transformed_entry * close_normalize_data(struct close_transformed_entry * entries, int size);

double close_entries_distance(struct close_transformed_entry * entries, int size, int index1, int index2, double * params);

struct close_cluster close_match_entry_to_cluster(struct close_cluster * clusters, int clusters_number, struct close_transformed_entry entry);




/**
############################## OPEN SysCall ###################################
**/

struct open_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	double z_score_path_length;
	int path_depth;
	double z_score_path_depth;
	char * filename;
    char * flags;
	int retValue;
	double z_score_retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};


struct open_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct string * flags;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};
	
struct open_cluster* open_cluster(struct open_entry * entries, int size, int * max_clusters_number);

struct open_cluster * model_open_clusters(struct open_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct open_transformed_entry * open_transform_data(struct open_entry * entries, int size);

struct open_transformed_entry * open_normalize_data(struct open_transformed_entry * entries, int size);

double open_entries_distance(struct open_transformed_entry * entries, int size, int index1, int index2, double * params);



struct open_cluster open_match_entry_to_cluster(struct open_cluster * clusters, int clusters_number, struct open_transformed_entry entry);

double * get_open_cluster_matching_coefficients(struct open_cluster cluster);

/**
############################## MMAP SysCall ###################################
**/


struct mmap_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct mmap_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct mmap_cluster* mmap_cluster(struct mmap_entry * entries, int size, int * max_clusters_number);

struct mmap_cluster * model_mmap_clusters(struct mmap_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct mmap_transformed_entry * mmap_transform_data(struct mmap_entry * entries, int size);

struct mmap_transformed_entry * mmap_normalize_data(struct mmap_transformed_entry * entries, int size);

double mmap_entries_distance(struct mmap_transformed_entry * entries, int size, int index1, int index2, double * params);

struct mmap_cluster mmap_match_entry_to_cluster(struct mmap_cluster * clusters, int clusters_number, struct mmap_transformed_entry entry);

/**
############################## STAT SysCall ###################################

**/


struct stat_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct stat_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct stat_cluster* stat_cluster(struct stat_entry * entries, int size, int *max_clusters_number);

struct stat_cluster * model_stat_clusters(struct stat_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct stat_transformed_entry * stat_transform_data(struct stat_entry * entries, int size);

struct stat_transformed_entry * stat_normalize_data(struct stat_transformed_entry * entries, int size);

double stat_entries_distance(struct stat_transformed_entry * entries, int size, int index1, int index2, double * params);

struct stat_cluster stat_match_entry_to_cluster(struct stat_cluster * clusters, int clusters_number, struct stat_transformed_entry entry);

/**
############################## ACCESS SysCall ###################################
**/


struct access_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct access_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct access_cluster* access_cluster(struct access_entry * entries, int size, int *max_clusters_number);

struct access_cluster * model_access_clusters(struct access_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct access_transformed_entry * access_transform_data(struct access_entry * entries, int size);

struct access_transformed_entry * access_normalize_data(struct access_transformed_entry * entries, int size);

double access_entries_distance(struct access_transformed_entry * entries, int size, int index1, int index2, double * params);

struct access_cluster access_match_entry_to_cluster(struct access_cluster * clusters, int clusters_number, struct access_transformed_entry entry);

/**
############################## MUNMAP SysCall ###################################
**/

struct munmap_transformed_entry {
	char * syscall;
	int address;
	int length;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct munmap_cluster {
	char * syscall;
	struct integer * addresses;
	struct integer * lengths;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct munmap_cluster* munmap_cluster(struct munmap_entry * entries, int size, int *max_clusters_number);

struct munmap_cluster * model_munmap_clusters(struct munmap_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct munmap_transformed_entry * munmap_transform_data(struct munmap_entry * entries, int size);

struct munmap_transformed_entry * munmap_normalize_data(struct munmap_transformed_entry * entries, int size);

double munmap_entries_distance(struct munmap_transformed_entry * entries, int size, int index1, int index2, double * params);

struct munmap_cluster munmap_match_entry_to_cluster(struct munmap_cluster * clusters, int clusters_number, struct munmap_transformed_entry entry);

/**
############################## PUTMSG SysCall ###################################
**/

struct putmsg_transformed_entry {
	char * syscall;
	int filedes;
	int flags;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct putmsg_cluster {
	char * syscall;
	struct integer * filedess;
	struct integer * flags;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct putmsg_cluster* putmsg_cluster(struct putmsg_entry * entries, int size, int *max_clusters_number);

struct putmsg_cluster * model_putmsg_clusters(struct putmsg_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct putmsg_transformed_entry * putmsg_transform_data(struct putmsg_entry * entries, int size);

struct putmsg_transformed_entry * putmsg_normalize_data(struct putmsg_transformed_entry * entries, int size);

double putmsg_entries_distance(struct putmsg_transformed_entry * entries, int size, int index1, int index2, double * params);

struct putmsg_cluster putmsg_match_entry_to_cluster(struct putmsg_cluster * clusters, int clusters_number, struct putmsg_transformed_entry entry);

/**
############################## SYSINFO SysCall ###################################
**/

struct sysinfo_transformed_entry {
	char * syscall;
	int command;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct sysinfo_cluster {
	char * syscall;
	struct integer * commands;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct sysinfo_cluster* sysinfo_cluster(struct sysinfo_entry * entries, int size, int *max_clusters_number);

struct sysinfo_cluster * model_sysinfo_clusters(struct sysinfo_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct sysinfo_transformed_entry * sysinfo_transform_data(struct sysinfo_entry * entries, int size);

struct sysinfo_transformed_entry * sysinfo_normalize_data(struct sysinfo_transformed_entry * entries, int size);

double sysinfo_entries_distance(struct sysinfo_transformed_entry * entries, int size, int index1, int index2, double * params);

struct sysinfo_cluster sysinfo_match_entry_to_cluster(struct sysinfo_cluster * clusters, int clusters_number, struct sysinfo_transformed_entry entry);

/**
############################## CHDIR SysCall ###################################
**/


struct chdir_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct chdir_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct chdir_cluster* chdir_cluster(struct chdir_entry * entries, int size, int *max_clusters_number);

struct chdir_cluster * model_chdir_clusters(struct chdir_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct chdir_transformed_entry * chdir_transform_data(struct chdir_entry * entries, int size);

struct chdir_transformed_entry * chdir_normalize_data(struct chdir_transformed_entry * entries, int size);

double chdir_entries_distance(struct chdir_transformed_entry * entries, int size, int index1, int index2, double * params);

struct chdir_cluster chdir_match_entry_to_cluster(struct chdir_cluster * clusters, int clusters_number, struct chdir_transformed_entry entry);

/**
############################## READLINK SysCall ###################################
**/


struct readlink_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
	int retValue;
};

struct readlink_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct readlink_cluster* readlink_cluster(struct readlink_entry * entries, int size, int *max_clusters_number);

struct readlink_cluster * model_readlink_clusters(struct readlink_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct readlink_transformed_entry * readlink_transform_data(struct readlink_entry * entries, int size);

struct readlink_transformed_entry * readlink_normalize_data(struct readlink_transformed_entry * entries, int size);

double readlink_entries_distance(struct readlink_transformed_entry * entries, int size, int index1, int index2, double * params);

struct readlink_cluster readlink_match_entry_to_cluster(struct readlink_cluster * clusters, int clusters_number, struct readlink_transformed_entry entry);

/**
############################## UNLINK SysCall ###################################
**/


struct unlink_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
	int retValue;
};

struct unlink_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct unlink_cluster* unlink_cluster(struct unlink_entry * entries, int size, int *max_clusters_number);

struct unlink_cluster * model_unlink_clusters(struct unlink_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct unlink_transformed_entry * unlink_transform_data(struct unlink_entry * entries, int size);

struct unlink_transformed_entry * unlink_normalize_data(struct unlink_transformed_entry * entries, int size);

double unlink_entries_distance(struct unlink_transformed_entry * entries, int size, int index1, int index2, double * params);

struct unlink_cluster unlink_match_entry_to_cluster(struct unlink_cluster * clusters, int clusters_number, struct unlink_transformed_entry entry);

/**
############################## CREAT SysCall ###################################
**/


struct creat_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct creat_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct creat_cluster* creat_cluster(struct creat_entry * entries, int size, int *max_clusters_number);

struct creat_cluster * model_creat_clusters(struct creat_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct creat_transformed_entry * creat_transform_data(struct creat_entry * entries, int size);

struct creat_transformed_entry * creat_normalize_data(struct creat_transformed_entry * entries, int size);

double creat_entries_distance(struct creat_transformed_entry * entries, int size, int index1, int index2, double * params);

struct creat_cluster creat_match_entry_to_cluster(struct creat_cluster * clusters, int clusters_number, struct creat_transformed_entry entry);

/**
############################## LSTAT SysCall ###################################
**/


struct lstat_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct lstat_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct lstat_cluster* lstat_cluster(struct lstat_entry * entries, int size, int *max_clusters_number);

struct lstat_cluster * model_lstat_clusters(struct lstat_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct lstat_transformed_entry * lstat_transform_data(struct lstat_entry * entries, int size);

struct lstat_transformed_entry * lstat_normalize_data(struct lstat_transformed_entry * entries, int size);

double lstat_entries_distance(struct lstat_transformed_entry * entries, int size, int index1, int index2, double * params);

struct lstat_cluster lstat_match_entry_to_cluster(struct lstat_cluster * clusters, int clusters_number, struct lstat_transformed_entry entry);

/**
############################## SETEUID SysCall ###################################
**/

struct seteuid_transformed_entry {
	char * syscall;
	int euid;
	int retValue;
	int p_euid;
	int egid;
	int ruid;
	int rgid;

};

struct seteuid_cluster {
	char * syscall;
	struct integer * euids;
	struct integer * retValues;
	struct integer * p_euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct seteuid_cluster* seteuid_cluster(struct seteuid_entry * entries, int size, int *max_clusters_number);

struct seteuid_cluster * model_seteuid_clusters(struct seteuid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct seteuid_transformed_entry * seteuid_transform_data(struct seteuid_entry * entries, int size);

struct seteuid_transformed_entry * seteuid_normalize_data(struct seteuid_transformed_entry * entries, int size);

double seteuid_entries_distance(struct seteuid_transformed_entry * entries, int size, int index1, int index2, double * params);

struct seteuid_cluster seteuid_match_entry_to_cluster(struct seteuid_cluster * clusters, int clusters_number, struct seteuid_transformed_entry entry);

/**
############################## SETGID SysCall ###################################
**/

struct setgid_transformed_entry {
	char * syscall;
	int gid;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct setgid_cluster {
	char * syscall;
	struct integer * gids;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct setgid_cluster* setgid_cluster(struct setgid_entry * entries, int size, int *max_clusters_number);

struct setgid_cluster * model_setgid_clusters(struct setgid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct setgid_transformed_entry * setgid_transform_data(struct setgid_entry * entries, int size);

struct setgid_transformed_entry * setgid_normalize_data(struct setgid_transformed_entry * entries, int size);

double setgid_entries_distance(struct setgid_transformed_entry * entries, int size, int index1, int index2, double * params);

struct setgid_cluster setgid_match_entry_to_cluster(struct setgid_cluster * clusters, int clusters_number, struct setgid_transformed_entry entry);

/**
############################## SETGROUPS SysCall ###################################
**/

struct setgroups_transformed_entry {
	char * syscall;
	int ngroups;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct setgroups_cluster {
	char * syscall;
	struct integer * ngroupss;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct setgroups_cluster* setgroups_cluster(struct setgroups_entry * entries, int size, int *max_clusters_number);

struct setgroups_cluster * model_setgroups_clusters(struct setgroups_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct setgroups_transformed_entry * setgroups_transform_data(struct setgroups_entry * entries, int size);

struct setgroups_transformed_entry * setgroups_normalize_data(struct setgroups_transformed_entry * entries, int size);

double setgroups_entries_distance(struct setgroups_transformed_entry * entries, int size, int index1, int index2, double * params);

struct setgroups_cluster setgroups_match_entry_to_cluster(struct setgroups_cluster * clusters, int clusters_number, struct setgroups_transformed_entry entry);

/**
############################## SETGID SysCall ###################################
**/

struct setegid_transformed_entry {
	char * syscall;
	int egid;
	int retValue;
	int euid;
	int p_egid;
	int ruid;
	int rgid;

};

struct setegid_cluster {
	char * syscall;
	struct integer * egids;
	struct integer * retValues;
	struct integer * euids;
	struct integer * p_egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct setegid_cluster* setegid_cluster(struct setegid_entry * entries, int size, int *max_clusters_number);

struct setegid_cluster * model_setegid_clusters(struct setegid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct setegid_transformed_entry * setegid_transform_data(struct setegid_entry * entries, int size);

struct setegid_transformed_entry * setegid_normalize_data(struct setegid_transformed_entry * entries, int size);

double setegid_entries_distance(struct setegid_transformed_entry * entries, int size, int index1, int index2, double * params);

struct setegid_cluster setegid_match_entry_to_cluster(struct setegid_cluster * clusters, int clusters_number, struct setegid_transformed_entry entry);

/**
############################## RENAME SysCall ###################################
**/


struct rename_transformed_entry {
	char * syscall;
	char * path1;
	int path_length1;
	int path_depth1;
	char * path2;
	int path_length2;
	int path_depth2;
	char * filename1;
	char * filename2;
	int retValue;
	int filemode1;
	int filemode2;
	int file1_owner_id;
	int file1_group_id;
	int file2_owner_id;
	int file2_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct rename_cluster {
	char * syscall;
	double path_length_mean1;
	double path_length_variance1;
	double path_depth_mean1;
	double path_depth_variance1;
	double path_length_mean2;
	double path_length_variance2;
	double path_depth_mean2;
	double path_depth_variance2;
	struct string * filenames1;
	struct string * filenames2;
	struct integer * retValues;
	struct string * paths1;
	struct string * paths2;
	struct integer * filemodes1;
	struct integer * file1_owner_ids;
	struct integer * file1_group_ids;
	struct integer * filemodes2;
	struct integer * file2_owner_ids;
	struct integer * file2_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;

	int cluster_size;
};

struct rename_cluster* rename_cluster(struct rename_entry * entries, int size, int *max_clusters_number);

struct rename_cluster * model_rename_clusters(struct rename_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct rename_transformed_entry * rename_transform_data(struct rename_entry * entries, int size);

struct rename_transformed_entry * rename_normalize_data(struct rename_transformed_entry * entries, int size);

double rename_entries_distance(struct rename_transformed_entry * entries, int size, int index1, int index2, double * params);

struct rename_cluster rename_match_entry_to_cluster(struct rename_cluster * clusters, int clusters_number, struct rename_transformed_entry entry);

/**
############################## IOCTL SysCall ###################################
**/


struct ioctl_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int command;
	int arg;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct ioctl_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * commands;
	struct integer * args;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct ioctl_cluster* ioctl_cluster(struct ioctl_entry * entries, int size, int *max_clusters_number);

struct ioctl_cluster * model_ioctl_clusters(struct ioctl_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct ioctl_transformed_entry * ioctl_transform_data(struct ioctl_entry * entries, int size);

struct ioctl_transformed_entry * ioctl_normalize_data(struct ioctl_transformed_entry * entries, int size);

double ioctl_entries_distance(struct ioctl_transformed_entry * entries, int size, int index1, int index2, double * params);

struct ioctl_cluster ioctl_match_entry_to_cluster(struct ioctl_cluster * clusters, int clusters_number, struct ioctl_transformed_entry entry);

/**
############################## FCNTL SysCall ###################################
**/


struct fcntl_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int command;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct fcntl_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * commands;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct fcntl_cluster* fcntl_cluster(struct fcntl_entry * entries, int size, int *max_clusters_number);

struct fcntl_cluster * model_fcntl_clusters(struct fcntl_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct fcntl_transformed_entry * fcntl_transform_data(struct fcntl_entry * entries, int size);

struct fcntl_transformed_entry * fcntl_normalize_data(struct fcntl_transformed_entry * entries, int size);

double fcntl_entries_distance(struct fcntl_transformed_entry * entries, int size, int index1, int index2, double * params);

struct fcntl_cluster fcntl_match_entry_to_cluster(struct fcntl_cluster * clusters, int clusters_number, struct fcntl_transformed_entry entry);

/**
############################## GETMSG SysCall ###################################
**/

struct getmsg_transformed_entry {
	char * syscall;
	int filedes;
	int flags;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct getmsg_cluster {
	char * syscall;
	struct integer * filedess;
	struct integer * flags;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct getmsg_cluster* getmsg_cluster(struct getmsg_entry * entries, int size, int *max_clusters_number);

struct getmsg_cluster * model_getmsg_clusters(struct getmsg_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct getmsg_transformed_entry * getmsg_transform_data(struct getmsg_entry * entries, int size);

struct getmsg_transformed_entry * getmsg_normalize_data(struct getmsg_transformed_entry * entries, int size);

double getmsg_entries_distance(struct getmsg_transformed_entry * entries, int size, int index1, int index2, double * params);

struct getmsg_cluster getmsg_match_entry_to_cluster(struct getmsg_cluster * clusters, int clusters_number, struct getmsg_transformed_entry entry);

/**
############################## SETUID SysCall ###################################
**/

struct setuid_transformed_entry {
	char * syscall;
	int uid;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct setuid_cluster {
	char * syscall;
	struct integer * uids;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct setuid_cluster* setuid_cluster(struct setuid_entry * entries, int size, int *max_clusters_number);

struct setuid_cluster * model_setuid_clusters(struct setuid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct setuid_transformed_entry * setuid_transform_data(struct setuid_entry * entries, int size);

struct setuid_transformed_entry * setuid_normalize_data(struct setuid_transformed_entry * entries, int size);

double setuid_entries_distance(struct setuid_transformed_entry * entries, int size, int index1, int index2, double * params);

struct setuid_cluster setuid_match_entry_to_cluster(struct setuid_cluster * clusters, int clusters_number, struct setuid_transformed_entry entry);

/**
############################## VFORK SysCall ###################################
**/

struct vfork_transformed_entry {
	char * syscall;
	int pid;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;

};

struct vfork_cluster {
	char * syscall;
	struct integer * pids;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct vfork_cluster* vfork_cluster(struct vfork_entry * entries, int size, int *max_clusters_number);

struct vfork_cluster * model_vfork_clusters(struct vfork_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct vfork_transformed_entry * vfork_transform_data(struct vfork_entry * entries, int size);

struct vfork_transformed_entry * vfork_normalize_data(struct vfork_transformed_entry * entries, int size);

double vfork_entries_distance(struct vfork_transformed_entry * entries, int size, int index1, int index2, double * params);

struct vfork_cluster vfork_match_entry_to_cluster(struct vfork_cluster * clusters, int clusters_number, struct vfork_transformed_entry entry);

/**
############################## CHOWN SysCall ###################################
**/


struct chown_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int owner;
	int group;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct chown_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * owners;
	struct integer * groups;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct chown_cluster* chown_cluster(struct chown_entry * entries, int size, int *max_clusters_number);

struct chown_cluster * model_chown_clusters(struct chown_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct chown_transformed_entry * chown_transform_data(struct chown_entry * entries, int size);

struct chown_transformed_entry * chown_normalize_data(struct chown_transformed_entry * entries, int size);

double chown_entries_distance(struct chown_transformed_entry * entries, int size, int index1, int index2, double * params);

struct chown_cluster chown_match_entry_to_cluster(struct chown_cluster * clusters, int clusters_number, struct chown_transformed_entry entry);

/**
############################## CHROOT SysCall ###################################
**/


struct chroot_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct chroot_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct chroot_cluster* chroot_cluster(struct chroot_entry * entries, int size, int *max_clusters_number);

struct chroot_cluster * model_chroot_clusters(struct chroot_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct chroot_transformed_entry * chroot_transform_data(struct chroot_entry * entries, int size);

struct chroot_transformed_entry * chroot_normalize_data(struct chroot_transformed_entry * entries, int size);

double chroot_entries_distance(struct chroot_transformed_entry * entries, int size, int index1, int index2, double * params);

struct chroot_cluster chroot_match_entry_to_cluster(struct chroot_cluster * clusters, int clusters_number, struct chroot_transformed_entry entry);

/**
############################## FCHOWN SysCall ###################################
**/


struct fchown_transformed_entry {
	char * syscall;
	char * path;
	int path_length;
	int path_depth;
	char * filename;
	int owner;
	int group;
	int retValue;
	int filemode;
	int file_owner_id;
	int file_group_id;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct fchown_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	struct string * filenames;
	struct integer * owners;
	struct integer * groups;
	struct integer * retValues;
	struct string * paths;
	struct integer * filemodes;
	struct integer * file_owner_ids;
	struct integer * file_group_ids;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct fchown_cluster* fchown_cluster(struct fchown_entry * entries, int size, int *max_clusters_number);

struct fchown_cluster * model_fchown_clusters(struct fchown_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct fchown_transformed_entry * fchown_transform_data(struct fchown_entry * entries, int size);

struct fchown_transformed_entry * fchown_normalize_data(struct fchown_transformed_entry * entries, int size);

double fchown_entries_distance(struct fchown_transformed_entry * entries, int size, int index1, int index2, double * params);

struct fchown_cluster fchown_match_entry_to_cluster(struct fchown_cluster * clusters, int clusters_number, struct fchown_transformed_entry entry);

/**
############################## SOCKCONNECT SysCall ###################################
**/


struct sockconnect_transformed_entry {
	char * syscall;
	int socket_type;
	int port;
	int address;
	int fd;
	int priority;
	int retValue;
	int euid;
	int egid;
	int ruid;
	int rgid;
};

struct sockconnect_cluster {
	char * syscall;
	struct integer * socket_types;
	struct integer * ports;
	struct integer * addresses;
	struct integer * fds;
	struct integer * priorities;
	struct integer * retValues;
	struct integer * euids;
	struct integer * egids;
	struct integer * ruids;
	struct integer * rgids;
	int cluster_size;
};

struct sockconnect_cluster* sockconnect_cluster(struct sockconnect_entry * entries, int size, int *max_clusters_number);

struct sockconnect_cluster * model_sockconnect_clusters(struct sockconnect_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct sockconnect_transformed_entry * sockconnect_transform_data(struct sockconnect_entry * entries, int size);

struct sockconnect_transformed_entry * sockconnect_normalize_data(struct sockconnect_transformed_entry * entries, int size);

double sockconnect_entries_distance(struct sockconnect_transformed_entry * entries, int size, int index1, int index2, double * params);

struct sockconnect_cluster sockconnect_match_entry_to_cluster(struct sockconnect_cluster * clusters, int clusters_number, struct sockconnect_transformed_entry entry);


/**
###################### HELPERS ############################"
**/
double min_max_double(double * values, int size, bool min_max);

double min_max_string(char * filenames[], int size, bool min_max);

bool ** hierarchical_clustering(double ** distance_matrix, int size, int max_clusters_number);

bool ** hierarchical_clustering_2(double ** distance_matrix, int size, int * clusters_number);

double compute_cluster_distances(bool * cluster1, bool * cluster2, double ** distance_matrix, int size);

double compute_filemode_distance(double filemode1, double filemode2);

double compute_file_owner_id_distance(double file_owner_id1, double file_owner_id2);

double compute_file_group_id_distance(double file_group_id1, double file_group_id2);

double compute_euid_distance(double euid1, double euid2);

double compute_egid_distance(double egid1, double egid2);

double compute_ruid_distance(double ruid1, double ruid2);

double compute_rgid_distance(double rgid1, double rgid2);

#endif
