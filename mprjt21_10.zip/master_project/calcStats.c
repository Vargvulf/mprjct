#include <stdio.h>
#include <stdlib.h>
#include "clusterers.h"
#include "converters.h"


int main(int argc, char* argv[]){

	struct open_entry * open_entries = NULL;
	struct open_transformed_entry * open_tr_entries = NULL;
	struct open_cluster * open_clusters = NULL;
	struct open_cluster open_cl;

	struct close_entry * close_entries = NULL;
	struct close_transformed_entry * close_tr_entries = NULL;
	struct close_cluster * close_clusters = NULL;
	struct close_cluster close_cl;

	struct mmap_entry * mmap_entries = NULL;
	struct mmap_transformed_entry * mmap_tr_entries = NULL;
	struct mmap_cluster * mmap_clusters = NULL;
	struct mmap_cluster mmap_cl;

	struct stat_entry * stat_entries = NULL;
	struct stat_transformed_entry * stat_tr_entries = NULL;
	struct stat_cluster * stat_clusters = NULL;
	struct stat_cluster stat_cl;

	struct access_entry * access_entries = NULL;
	struct access_transformed_entry * access_tr_entries = NULL;
	struct access_cluster * access_clusters = NULL;
	struct access_cluster access_cl;

	struct munmap_entry * munmap_entries = NULL;
	struct munmap_transformed_entry * munmap_tr_entries = NULL;
	struct munmap_cluster * munmap_clusters = NULL;
	struct munmap_cluster munmap_cl;

	struct putmsg_entry * putmsg_entries = NULL;
	struct putmsg_transformed_entry * putmsg_tr_entries = NULL;
	struct putmsg_cluster * putmsg_clusters = NULL;
	struct putmsg_cluster putmsg_cl;

	struct sysinfo_entry * sysinfo_entries = NULL;
	struct sysinfo_transformed_entry * sysinfo_tr_entries = NULL;
	struct sysinfo_cluster * sysinfo_clusters = NULL;
	struct sysinfo_cluster sysinfo_cl;

	struct chdir_entry * chdir_entries = NULL;
	struct chdir_transformed_entry * chdir_tr_entries = NULL;
	struct chdir_cluster * chdir_clusters = NULL;
	struct chdir_cluster chdir_cl;

	struct readlink_entry * readlink_entries = NULL;
	struct readlink_transformed_entry * readlink_tr_entries = NULL;
	struct readlink_cluster * readlink_clusters = NULL;
	struct readlink_cluster readlink_cl;

	struct unlink_entry * unlink_entries = NULL;
	struct unlink_transformed_entry * unlink_tr_entries = NULL;
	struct unlink_cluster * unlink_clusters = NULL;
	struct unlink_cluster unlink_cl;

	struct creat_entry * creat_entries = NULL;
	struct creat_transformed_entry * creat_tr_entries = NULL;
	struct creat_cluster * creat_clusters = NULL;
	struct creat_cluster creat_cl;

	struct lstat_entry * lstat_entries = NULL;
	struct lstat_transformed_entry * lstat_tr_entries = NULL;
	struct lstat_cluster * lstat_clusters = NULL;
	struct lstat_cluster lstat_cl;

	struct seteuid_entry * seteuid_entries = NULL;
	struct seteuid_transformed_entry * seteuid_tr_entries = NULL;
	struct seteuid_cluster * seteuid_clusters = NULL;
	struct seteuid_cluster seteuid_cl;

	struct setgid_entry * setgid_entries = NULL;
	struct setgid_transformed_entry * setgid_tr_entries = NULL;
	struct setgid_cluster * setgid_clusters = NULL;
	struct setgid_cluster setgid_cl;


	struct setgroups_entry * setgroups_entries = NULL;
	struct setgroups_transformed_entry * setgroups_tr_entries = NULL;
	struct setgroups_cluster * setgroups_clusters = NULL;
	struct setgroups_cluster setgroups_cl;

	struct setegid_entry * setegid_entries = NULL;
	struct setegid_transformed_entry * setegid_tr_entries = NULL;
	struct setegid_cluster * setegid_clusters = NULL;
	struct setegid_cluster setegid_cl;

	struct rename_entry * rename_entries = NULL;
	struct rename_transformed_entry * rename_tr_entries = NULL;
	struct rename_cluster * rename_clusters = NULL;
	struct rename_cluster rename_cl;
	
	struct ioctl_entry * ioctl_entries = NULL;
	struct ioctl_transformed_entry * ioctl_tr_entries = NULL;
	struct ioctl_cluster * ioctl_clusters = NULL;
	struct ioctl_cluster ioctl_cl;

	struct fcntl_entry * fcntl_entries = NULL;
	struct fcntl_transformed_entry * fcntl_tr_entries = NULL;
	struct fcntl_cluster * fcntl_clusters = NULL;
	struct fcntl_cluster fcntl_cl;

	struct getmsg_entry * getmsg_entries = NULL;
	struct getmsg_transformed_entry * getmsg_tr_entries = NULL;
	struct getmsg_cluster * getmsg_clusters = NULL;
	struct getmsg_cluster getmsg_cl;

	struct setuid_entry * setuid_entries = NULL;
	struct setuid_transformed_entry * setuid_tr_entries = NULL;
	struct setuid_cluster * setuid_clusters = NULL;
	struct setuid_cluster setuid_cl;

	struct vfork_entry * vfork_entries = NULL;
	struct vfork_transformed_entry * vfork_tr_entries = NULL;
	struct vfork_cluster * vfork_clusters = NULL;
	struct vfork_cluster vfork_cl;

	struct chown_entry * chown_entries = NULL;
	struct chown_transformed_entry * chown_tr_entries = NULL;
	struct chown_cluster * chown_clusters = NULL;
	struct chown_cluster chown_cl;

	struct chroot_entry * chroot_entries = NULL;
	struct chroot_transformed_entry * chroot_tr_entries = NULL;
	struct chroot_cluster * chroot_clusters = NULL;
	struct chroot_cluster chroot_cl;

	struct fchown_entry * fchown_entries = NULL;
	struct fchown_transformed_entry * fchown_tr_entries = NULL;
	struct fchown_cluster * fchown_clusters = NULL;
	struct fchown_cluster fchown_cl;

	int i;
	FILE * outfile,  * infile =NULL;
	char * filename = NULL;
	int max_clusters = atoi(argv[3]);

/**
    struct open_result_entry * res;
    res = open_convert_data(argv[1],atoi(argv[2]));
    if (res != NULL){
        printf("Mean : %d\n",res->length_mean);
        printf("Variance : %d\n",res->length_variance);
    }
    else
        printf("Operation failed !");
**/
/**
	int ** res2 = NULL;
    res2 = open_cluster(argv[1],atoi(argv[2]));
**/
	infile = fopen(argv[1], "r");
	char line[400];
	char * token;
	fgets(line,400,infile);
    fclose(infile);
	token = strtok(line,",");
	printf("%s",token);
	if (strcmp(token,"OPEN") == 0){
   		open_entries = open_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",open_entries[0].path);
	    open_clusters = open_cluster(open_entries, atoi(argv[2]), &max_clusters);
		
		open_tr_entries = open_transform_data(open_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			open_cl = open_match_entry_to_cluster(open_clusters,max_clusters,open_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%s:%d",open_entries[i].path,open_entries[i].flags,open_entries[i].retValue);
			printf("\nCluster : %s \n",open_cl.syscall);
			filename = (char *) malloc(13 + strlen(open_cl.syscall)+1);
			strncpy(filename,"results/open/",13);
			sprintf(filename+13,"%s\0",open_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%s,%d\n",open_entries[i].path,open_entries[i].flags,open_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}
	 }
	 else if (strcmp(token,"CLOSE") == 0){
		printf ("Close !");
		close_entries = close_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",close_entries[0].path);
	    close_clusters = close_cluster(close_entries, atoi(argv[2]), &max_clusters);
		
		close_tr_entries = close_transform_data(close_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			close_cl = close_match_entry_to_cluster(close_clusters,max_clusters,close_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",close_entries[i].path,close_entries[i].retValue);
			printf("\nCluster : %s \n",close_cl.syscall);
			filename = (char *) malloc(14 + strlen(close_cl.syscall)+1);
			strncpy(filename,"results/close/",14);
			sprintf(filename+14,"%s\0",close_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",close_entries[i].path,close_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }
	 else if (strcmp(token,"MMAP") == 0){
		printf ("Mmap !");
		mmap_entries = mmap_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",mmap_entries[0].path);
	    mmap_clusters = mmap_cluster(mmap_entries, atoi(argv[2]), &max_clusters);
		
		mmap_tr_entries = mmap_transform_data(mmap_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			mmap_cl = mmap_match_entry_to_cluster(mmap_clusters,max_clusters,mmap_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",mmap_entries[i].path,mmap_entries[i].retValue);
			printf("\nCluster : %s \n",mmap_cl.syscall);
			filename = (char *) malloc(13 + strlen(mmap_cl.syscall)+1);
			strncpy(filename,"results/mmap/",13);
			sprintf(filename+13,"%s\0",mmap_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",mmap_entries[i].path,mmap_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }
	 else if (strcmp(token,"STAT") == 0){
		printf ("Stat !");
		stat_entries = stat_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",stat_entries[0].path);
	    stat_clusters = stat_cluster(stat_entries, atoi(argv[2]), &max_clusters);
		
		stat_tr_entries = stat_transform_data(stat_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			stat_cl = stat_match_entry_to_cluster(stat_clusters,max_clusters,stat_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",stat_entries[i].path,stat_entries[i].retValue);
			printf("\nCluster : %s \n",stat_cl.syscall);
			filename = (char *) malloc(13 + strlen(stat_cl.syscall)+1);
			strncpy(filename,"results/stat/",13);
			sprintf(filename+13,"%s\0",stat_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",stat_entries[i].path,stat_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }
	
	else if (strcmp(token,"ACCESS") == 0){
		printf ("Access !");
		access_entries = access_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",access_entries[0].path);
	    access_clusters = access_cluster(access_entries, atoi(argv[2]), &max_clusters);
		
		access_tr_entries = access_transform_data(access_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			access_cl = access_match_entry_to_cluster(access_clusters,max_clusters,access_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",access_entries[i].path,access_entries[i].retValue);
			printf("\nCluster : %s \n",access_cl.syscall);
			filename = (char *) malloc(15 + strlen(access_cl.syscall)+1);
			strncpy(filename,"results/access/",15);
			sprintf(filename+15,"%s\0",access_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",access_entries[i].path,access_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"MUNMAP") == 0){
		printf ("Munmap !");
		munmap_entries = munmap_load_file(argv[1], atoi(argv[2]));
	    munmap_clusters = munmap_cluster(munmap_entries, atoi(argv[2]), &max_clusters);
		
		munmap_tr_entries = munmap_transform_data(munmap_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			munmap_cl = munmap_match_entry_to_cluster(munmap_clusters,max_clusters,munmap_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d:%d",munmap_entries[i].address,munmap_entries[i].length,munmap_entries[i].retValue);
			printf("\nCluster : %s \n",munmap_cl.syscall);
			filename = (char *) malloc(15 + strlen(munmap_cl.syscall)+1);
			strncpy(filename,"results/munmap/",15);
			sprintf(filename+15,"%s\0",munmap_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%x,%d\n",munmap_entries[i].address,munmap_entries[i].length,munmap_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"PUTMSG") == 0){
		printf ("Putmsg !");
		putmsg_entries = putmsg_load_file(argv[1], atoi(argv[2]));
	    putmsg_clusters = putmsg_cluster(putmsg_entries, atoi(argv[2]), &max_clusters);
		
		putmsg_tr_entries = putmsg_transform_data(putmsg_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			putmsg_cl = putmsg_match_entry_to_cluster(putmsg_clusters,max_clusters,putmsg_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d:%d",putmsg_entries[i].filedes,putmsg_entries[i].flags,putmsg_entries[i].retValue);
			printf("\nCluster : %s \n",putmsg_cl.syscall);
			filename = (char *) malloc(15 + strlen(putmsg_cl.syscall)+1);
			strncpy(filename,"results/putmsg/",15);
			sprintf(filename+15,"%s\0",putmsg_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%x,%d\n",putmsg_entries[i].filedes,putmsg_entries[i].flags,putmsg_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"SYSINFO") == 0){
		printf ("Sysinfo !");
		sysinfo_entries = sysinfo_load_file(argv[1], atoi(argv[2]));
	    sysinfo_clusters = sysinfo_cluster(sysinfo_entries, atoi(argv[2]), &max_clusters);
		
		sysinfo_tr_entries = sysinfo_transform_data(sysinfo_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			sysinfo_cl = sysinfo_match_entry_to_cluster(sysinfo_clusters,max_clusters,sysinfo_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d",sysinfo_entries[i].command,sysinfo_entries[i].retValue);
			printf("\nCluster : %s \n",sysinfo_cl.syscall);
			filename = (char *) malloc(16 + strlen(sysinfo_cl.syscall)+1);
			strncpy(filename,"results/sysinfo/",16);
			sprintf(filename+16,"%s\0",sysinfo_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",sysinfo_entries[i].command,sysinfo_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<atoi(argv[2]); i++)
			free(sysinfo_entries[i].syscall);
		free(sysinfo_entries);

		for(i=0; i<max_clusters; i++){
			free(sysinfo_clusters[i].syscall);
			free(sysinfo_clusters[i].commands);
			free(sysinfo_clusters[i].retValues);
		}
		free(sysinfo_clusters);

		for(i=0; i<atoi(argv[2]); i++)
			free(sysinfo_tr_entries[i].syscall);
		free(sysinfo_tr_entries);
	 }
	else if (strcmp(token,"CHDIR") == 0){
		printf ("Chdir !");
		chdir_entries = chdir_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",chdir_entries[0].path);
	    chdir_clusters = chdir_cluster(chdir_entries, atoi(argv[2]), &max_clusters);
		
		chdir_tr_entries = chdir_transform_data(chdir_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			chdir_cl = chdir_match_entry_to_cluster(chdir_clusters,max_clusters,chdir_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",chdir_entries[i].path,chdir_entries[i].retValue);
			printf("\nCluster : %s \n",chdir_cl.syscall);
			filename = (char *) malloc(14 + strlen(chdir_cl.syscall)+1);
			strncpy(filename,"results/chdir/",14);
			sprintf(filename+14,"%s\0",chdir_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",chdir_entries[i].path,chdir_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }
	
	else if (strcmp(token,"READLINK") == 0){
		printf ("Readlink !");
		readlink_entries = readlink_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",readlink_entries[0].path);
	    readlink_clusters = readlink_cluster(readlink_entries, atoi(argv[2]), &max_clusters);
		
		readlink_tr_entries = readlink_transform_data(readlink_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			readlink_cl = readlink_match_entry_to_cluster(readlink_clusters,max_clusters,readlink_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",readlink_entries[i].path,readlink_entries[i].retValue);
			printf("\nCluster : %s \n",readlink_cl.syscall);
			filename = (char *) malloc(15 + strlen(readlink_cl.syscall)+1);
			strncpy(filename,"results/readlink/",15);
			sprintf(filename+15,"%s\0",readlink_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",readlink_entries[i].path,readlink_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"UNLINK") == 0){
		printf ("Unlink !");
		unlink_entries = unlink_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",unlink_entries[0].path);
	    unlink_clusters = unlink_cluster(unlink_entries, atoi(argv[2]), &max_clusters);
		
		unlink_tr_entries = unlink_transform_data(unlink_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			unlink_cl = unlink_match_entry_to_cluster(unlink_clusters,max_clusters,unlink_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",unlink_entries[i].path,unlink_entries[i].retValue);
			printf("\nCluster : %s \n",unlink_cl.syscall);
			filename = (char *) malloc(15 + strlen(unlink_cl.syscall)+1);
			strncpy(filename,"results/unlink/",15);
			sprintf(filename+15,"%s\0",unlink_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",unlink_entries[i].path,unlink_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }
	else if (strcmp(token,"CREAT") == 0){
		printf ("Creat !");
		creat_entries = creat_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",creat_entries[0].path);
	    creat_clusters = creat_cluster(creat_entries, atoi(argv[2]), &max_clusters);
		
		creat_tr_entries = creat_transform_data(creat_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			creat_cl = creat_match_entry_to_cluster(creat_clusters,max_clusters,creat_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",creat_entries[i].path,creat_entries[i].retValue);
			printf("\nCluster : %s \n",creat_cl.syscall);
			filename = (char *) malloc(15 + strlen(creat_cl.syscall)+1);
			strncpy(filename,"results/creat/",15);
			sprintf(filename+15,"%s\0",creat_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",creat_entries[i].path,creat_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }
	
	else if (strcmp(token,"LSTAT") == 0){
		printf ("Lstat !");
		lstat_entries = lstat_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",lstat_entries[0].path);
	    lstat_clusters = lstat_cluster(lstat_entries, atoi(argv[2]), &max_clusters);
		
		lstat_tr_entries = lstat_transform_data(lstat_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			lstat_cl = lstat_match_entry_to_cluster(lstat_clusters,max_clusters,lstat_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",lstat_entries[i].path,lstat_entries[i].retValue);
			printf("\nCluster : %s \n",lstat_cl.syscall);
			filename = (char *) malloc(15 + strlen(lstat_cl.syscall)+1);
			strncpy(filename,"results/lstat/",15);
			sprintf(filename+15,"%s\0",lstat_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",lstat_entries[i].path,lstat_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"SETEUID") == 0){
		printf ("Seteuid !");
		seteuid_entries = seteuid_load_file(argv[1], atoi(argv[2]));
	    seteuid_clusters = seteuid_cluster(seteuid_entries, atoi(argv[2]), &max_clusters);
		
		seteuid_tr_entries = seteuid_transform_data(seteuid_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			seteuid_cl = seteuid_match_entry_to_cluster(seteuid_clusters,max_clusters,seteuid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",seteuid_entries[i].euid,seteuid_entries[i].retValue);
			printf("\nCluster : %s \n",seteuid_cl.syscall);
			filename = (char *) malloc(16 + strlen(seteuid_cl.syscall)+1);
			strncpy(filename,"results/seteuid/",16);
			sprintf(filename+16,"%s\0",seteuid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",seteuid_entries[i].euid,seteuid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"SETGID") == 0){
		printf ("Setgid !");
		setgid_entries = setgid_load_file(argv[1], atoi(argv[2]));
	    setgid_clusters = setgid_cluster(setgid_entries, atoi(argv[2]), &max_clusters);
		
		setgid_tr_entries = setgid_transform_data(setgid_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			setgid_cl = setgid_match_entry_to_cluster(setgid_clusters,max_clusters,setgid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setgid_entries[i].gid,setgid_entries[i].retValue);
			printf("\nCluster : %s \n",setgid_cl.syscall);
			filename = (char *) malloc(15 + strlen(setgid_cl.syscall)+1);
			strncpy(filename,"results/setgid/",15);
			sprintf(filename+15,"%s\0",setgid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setgid_entries[i].gid,setgid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"SETGROUPS") == 0){
		printf ("Setgroups !");
		setgroups_entries = setgroups_load_file(argv[1], atoi(argv[2]));
	    setgroups_clusters = setgroups_cluster(setgroups_entries, atoi(argv[2]), &max_clusters);
		
		setgroups_tr_entries = setgroups_transform_data(setgroups_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			setgroups_cl = setgroups_match_entry_to_cluster(setgroups_clusters,max_clusters,setgroups_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setgroups_entries[i].ngroups,setgroups_entries[i].retValue);
			printf("\nCluster : %s \n",setgroups_cl.syscall);
			filename = (char *) malloc(18 + strlen(setgroups_cl.syscall)+1);
			strncpy(filename,"results/setgroups/",18);
			sprintf(filename+18,"%s\0",setgroups_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setgroups_entries[i].ngroups,setgroups_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"SETEGID") == 0){
		printf ("Setegid !");
		setegid_entries = setegid_load_file(argv[1], atoi(argv[2]));
	    setegid_clusters = setegid_cluster(setegid_entries, atoi(argv[2]), &max_clusters);
		
		setegid_tr_entries = setegid_transform_data(setegid_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			setegid_cl = setegid_match_entry_to_cluster(setegid_clusters,max_clusters,setegid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setegid_entries[i].egid,setegid_entries[i].retValue);
			printf("\nCluster : %s \n",setegid_cl.syscall);
			filename = (char *) malloc(16 + strlen(setegid_cl.syscall)+1);
			strncpy(filename,"results/setegid/",16);
			sprintf(filename+16,"%s\0",setegid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setegid_entries[i].egid,setegid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"RENAME") == 0){
		printf ("Rename !");
		rename_entries = rename_load_file(argv[1], atoi(argv[2]));
	    rename_clusters = rename_cluster(rename_entries, atoi(argv[2]), &max_clusters);
		rename_tr_entries = rename_transform_data(rename_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			rename_cl = rename_match_entry_to_cluster(rename_clusters,max_clusters,rename_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%s:%d",rename_entries[i].path1, rename_entries[i].path2, rename_entries[i].retValue);
			printf("\nCluster : %s \n",rename_cl.syscall);
			filename = (char *) malloc(15 + strlen(rename_cl.syscall)+1);
			strncpy(filename,"results/rename/",15);
			sprintf(filename+15,"%s\0",rename_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%s,%d\n",rename_entries[i].path1,rename_entries[i].path2,rename_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }
	 else if (strcmp(token,"IOCTL") == 0){
		printf ("Ioctl !");
		ioctl_entries = ioctl_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",ioctl_entries[0].path);
	    ioctl_clusters = ioctl_cluster(ioctl_entries, atoi(argv[2]), &max_clusters);
		
		ioctl_tr_entries = ioctl_transform_data(ioctl_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			ioctl_cl = ioctl_match_entry_to_cluster(ioctl_clusters,max_clusters,ioctl_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d:%d",ioctl_entries[i].path, ioctl_entries[i].command, ioctl_entries[i].arg, ioctl_entries[i].retValue);
			printf("\nCluster : %s \n",ioctl_cl.syscall);
			filename = (char *) malloc(14 + strlen(ioctl_cl.syscall)+1);
			strncpy(filename,"results/ioctl/",14);
			sprintf(filename+14,"%s\0",ioctl_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d,%d\n",ioctl_entries[i].path, ioctl_entries[i].command, ioctl_entries[i].arg, ioctl_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	 else if (strcmp(token,"FCNTL") == 0){
		printf ("Fcntl !");
		fcntl_entries = fcntl_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",fcntl_entries[0].path);
	    fcntl_clusters = fcntl_cluster(fcntl_entries, atoi(argv[2]), &max_clusters);
		
		fcntl_tr_entries = fcntl_transform_data(fcntl_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			fcntl_cl = fcntl_match_entry_to_cluster(fcntl_clusters,max_clusters,fcntl_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d",fcntl_entries[i].path, fcntl_entries[i].command, fcntl_entries[i].retValue);
			printf("\nCluster : %s \n",fcntl_cl.syscall);
			filename = (char *) malloc(14 + strlen(fcntl_cl.syscall)+1);
			strncpy(filename,"results/fcntl/",14);
			sprintf(filename+14,"%s\0",fcntl_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d\n",fcntl_entries[i].path, fcntl_entries[i].command, fcntl_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"GETMSG") == 0){
		printf ("Getmsg !");
		getmsg_entries = getmsg_load_file(argv[1], atoi(argv[2]));
	    getmsg_clusters = getmsg_cluster(getmsg_entries, atoi(argv[2]), &max_clusters);
		
		getmsg_tr_entries = getmsg_transform_data(getmsg_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			getmsg_cl = getmsg_match_entry_to_cluster(getmsg_clusters,max_clusters,getmsg_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d:%d",getmsg_entries[i].filedes,getmsg_entries[i].flags,getmsg_entries[i].retValue);
			printf("\nCluster : %s \n",getmsg_cl.syscall);
			filename = (char *) malloc(15 + strlen(getmsg_cl.syscall)+1);
			strncpy(filename,"results/getmsg/",15);
			sprintf(filename+15,"%s\0",getmsg_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%x,%d\n",getmsg_entries[i].filedes,getmsg_entries[i].flags,getmsg_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"SETUID") == 0){
		printf ("Setuid !");
		setuid_entries = setuid_load_file(argv[1], atoi(argv[2]));
	    setuid_clusters = setuid_cluster(setuid_entries, atoi(argv[2]), &max_clusters);
		
		setuid_tr_entries = setuid_transform_data(setuid_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			setuid_cl = setuid_match_entry_to_cluster(setuid_clusters,max_clusters,setuid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setuid_entries[i].uid,setuid_entries[i].retValue);
			printf("\nCluster : %s \n",setuid_cl.syscall);
			filename = (char *) malloc(15 + strlen(setuid_cl.syscall)+1);
			strncpy(filename,"results/setuid/",15);
			sprintf(filename+15,"%s\0",setuid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setuid_entries[i].uid,setuid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"VFORK") == 0){
		printf ("Vfork !");
		vfork_entries = vfork_load_file(argv[1], atoi(argv[2]));
	    vfork_clusters = vfork_cluster(vfork_entries, atoi(argv[2]), &max_clusters);
		
		vfork_tr_entries = vfork_transform_data(vfork_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			vfork_cl = vfork_match_entry_to_cluster(vfork_clusters,max_clusters,vfork_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",vfork_entries[i].pid,vfork_entries[i].retValue);
			printf("\nCluster : %s \n",vfork_cl.syscall);
			filename = (char *) malloc(14 + strlen(vfork_cl.syscall)+1);
			strncpy(filename,"results/vfork/",14);
			sprintf(filename+14,"%s\0",vfork_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",vfork_entries[i].pid,vfork_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"CHOWN") == 0){
		printf ("Chown !");
		chown_entries = chown_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",chown_entries[0].path);
	    chown_clusters = chown_cluster(chown_entries, atoi(argv[2]), &max_clusters);
		
		chown_tr_entries = chown_transform_data(chown_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			chown_cl = chown_match_entry_to_cluster(chown_clusters,max_clusters,chown_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d:%d",chown_entries[i].path, chown_entries[i].owner, chown_entries[i].group, chown_entries[i].retValue);
			printf("\nCluster : %s \n",chown_cl.syscall);
			filename = (char *) malloc(14 + strlen(chown_cl.syscall)+1);
			strncpy(filename,"results/chown/",14);
			sprintf(filename+14,"%s\0",chown_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d,%d\n",chown_entries[i].path, chown_entries[i].owner, chown_entries[i].group, chown_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"CHROOT") == 0){
		printf ("Chroot !");
		chroot_entries = chroot_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",chroot_entries[0].path);
	    chroot_clusters = chroot_cluster(chroot_entries, atoi(argv[2]), &max_clusters);
		
		chroot_tr_entries = chroot_transform_data(chroot_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			chroot_cl = chroot_match_entry_to_cluster(chroot_clusters,max_clusters,chroot_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",chroot_entries[i].path,chroot_entries[i].retValue);
			printf("\nCluster : %s \n",chroot_cl.syscall);
			filename = (char *) malloc(15 + strlen(chroot_cl.syscall)+1);
			strncpy(filename,"results/chroot/",15);
			sprintf(filename+15,"%s\0",chroot_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",chroot_entries[i].path,chroot_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }

	else if (strcmp(token,"FCHOWN") == 0){
		printf ("Fchown !");
		fchown_entries = fchown_load_file(argv[1], atoi(argv[2]));
		printf("###### %s ########\n",fchown_entries[0].path);
	    fchown_clusters = fchown_cluster(fchown_entries, atoi(argv[2]), &max_clusters);
		
		fchown_tr_entries = fchown_transform_data(fchown_entries,atoi(argv[2]));
   		for (i=0; i< atoi(argv[2]); i++){
			fchown_cl = fchown_match_entry_to_cluster(fchown_clusters,max_clusters,fchown_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d:%d",fchown_entries[i].path, fchown_entries[i].owner, fchown_entries[i].group, fchown_entries[i].retValue);
			printf("\nCluster : %s \n",fchown_cl.syscall);
			filename = (char *) malloc(15 + strlen(fchown_cl.syscall)+1);
			strncpy(filename,"results/fchown/",15);
			sprintf(filename+15,"%s\0",fchown_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d,%d\n",fchown_entries[i].path, fchown_entries[i].owner, fchown_entries[i].group, fchown_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

	 }


}
