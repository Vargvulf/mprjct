#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

/****
String argument data structure
***/

struct string {
	char * string;
	struct string * next;
};

void add_string_uniq(struct string ** head, char * string);
void walk_strings(struct string * head);
int strings_list_size(struct string *head);
struct string *get_string(struct string * head, int index);
bool string_list_contains(struct string * head, char * string);
/*****
Integer argument data structure
****/

struct integer {
	int integer;
	struct integer * next;
};

void add_integer_uniq(struct integer ** head, int integer);
void walk_integers(struct integer * head);
int integer_list_size(struct integer * head);
struct integer * get_integer(struct integer * head, int index);
bool integer_list_contains(struct integer * head, int value);


/**
############# Stats & distance ###################
**/

double mean_double(double * data, int size);
int mean_int (int * data, int size);

double variance_double(double * data, int size);
int variance_int(int * data, int size);

int levenshtein_distance(char * str1, char * str2);




/**
############# OPEN syscall data structures ##############
**/

struct open_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
char * flags;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct open_result_entry {
char * syscall;
int length_mean;
int length_variance;
char * flags;
int retValue;
int file_owner_id;
int file_group_id;
int euid;
int egid;
int ruid;
int rgid;
};

struct open_entry * open_load_file(char * filename, int size);

/**
############# CLOSE syscall data structures ##############
**/

struct close_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct close_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct close_entry * close_load_file(char * filename, int size);


/**
############# MMAP syscall data structures ##############
**/

struct mmap_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct mmap_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct mmap_entry * mmap_load_file(char * filename, int size);

/**
############# STAT syscall data structures ##############
**/

struct stat_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct stat_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct stat_entry * stat_load_file(char * filename, int size);

/**
############# ACCESS syscall data structures ##############
**/

struct access_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct access_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct access_entry * access_load_file(char * filename, int size);

/**
############# MUNMAP syscall data structures ##############
**/

struct munmap_entry {
char * syscall;
int  address;
int  length;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct munmap_result_entry {
char * syscall;
int address;
int length;
int retValue;
};

struct munmap_entry * munmap_load_file(char * filename, int size);

/**
############# PUTMSG syscall data structures ##############
**/

struct putmsg_entry {
char * syscall;
int  filedes;
int  flags;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct putmsg_result_entry {
char * syscall;
int filedes;
int flags;
int retValue;
};

struct putmsg_entry * putmsg_load_file(char * filename, int size);

/**
############# SYSINFO syscall data structures ##############
**/

struct sysinfo_entry {
char * syscall;
int  command;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct sysinfo_result_entry {
char * syscall;
int command;
int retValue;
};

struct sysinfo_entry * sysinfo_load_file(char * filename, int size);

/**
#############  CHDIR syscall data structures ##############
**/

struct chdir_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct chdir_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct chdir_entry * chdir_load_file(char * filename, int size);

/**
#############  READLINK syscall data structures ##############
**/

struct readlink_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct readlink_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct readlink_entry * readlink_load_file(char * filename, int size);

/**
#############  UNLINK syscall data structures ##############
**/

struct unlink_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct unlink_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct unlink_entry * unlink_load_file(char * filename, int size);

/**
#############  CREAT syscall data structures ##############
**/

struct creat_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct creat_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct creat_entry * creat_load_file(char * filename, int size);

/**
#############  LSTAT syscall data structures ##############
**/

struct lstat_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct lstat_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct lstat_entry * lstat_load_file(char * filename, int size);

/**
############# SETEUID syscall data structures ##############
**/

struct seteuid_entry {
char * syscall;
int  euid;
int retValue;
int p_euid;
int egid;
int ruid;
int rgid;
};

struct seteuid_result_entry {
char * syscall;
int euid;
int retValue;
};

struct seteuid_entry * seteuid_load_file(char * filename, int size);

/**
############# SETGID syscall data structures ##############
**/

struct setgid_entry {
char * syscall;
int  gid;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct setgid_result_entry {
char * syscall;
int gid;
int retValue;
};

struct setgid_entry * setgid_load_file(char * filename, int size);

/**
############# NGROUPS syscall data structures ##############
**/

struct setgroups_entry {
char * syscall;
int  ngroups;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct setgroups_result_entry {
char * syscall;
int ngroups;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct setgroups_entry * setgroups_load_file(char * filename, int size);


/**
############# SETEGID syscall data structures ##############
**/

struct setegid_entry {
char * syscall;
int  egid;
int retValue;
int euid;
int p_egid;
int ruid;
int rgid;
};

struct setegid_result_entry {
char * syscall;
int egid;
int retValue;
int p_egid;
int ruid;
int rgid;
};

struct setegid_entry * setegid_load_file(char * filename, int size);

/**
############# RENAME syscall data structures ##############
**/

struct rename_entry {
char * syscall;
char * path1;
int filemode1;
int file1_owner_id;
int file1_group_id;
char * path2;
int filemode2;
int file2_owner_id;
int file2_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct rename_result_entry {
char * syscall;
int length_mean1;
int length_variance1;
int length_mean2;
int length_variance2;
int retValue;
};

struct rename_entry * rename_load_file(char * filename, int size);


/**
############# IOCTL syscall data structures ##############
**/

struct ioctl_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int command;
int arg;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct ioctl_result_entry {
char * syscall;
int length_mean;
int length_variance;
int command;
int arg;
int retValue;
};

struct ioctl_entry * ioctl_load_file(char * filename, int size);


/**
############# FCNTL syscall data structures ##############
**/

struct fcntl_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int command;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct fcntl_result_entry {
char * syscall;
int length_mean;
int length_variance;
int command;
int retValue;
};

struct fcntl_entry * fcntl_load_file(char * filename, int size);


/**
############# GETMSG syscall data structures ##############
**/

struct getmsg_entry {
char * syscall;
int  filedes;
int  flags;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct getmsg_result_entry {
char * syscall;
int filedes;
int flags;
int retValue;
};

struct getmsg_entry * getmsg_load_file(char * filename, int size);


/**
############# SETUID syscall data structures ##############
**/

struct setuid_entry {
char * syscall;
int  uid;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct setuid_result_entry {
char * syscall;
int uid;
int retValue;
};

struct setuid_entry * setuid_load_file(char * filename, int size);

/**
############# VFORK syscall data structures ##############
**/

struct vfork_entry {
char * syscall;
int  pid;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct vfork_result_entry {
char * syscall;
int pid;
int retValue;
};

struct vfork_entry * vfork_load_file(char * filename, int size);


/**
############# CHOWN syscall data structures ##############
**/

struct chown_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int owner;
int group;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct chown_result_entry {
char * syscall;
int length_mean;
int length_variance;
int owner;
int group;
int retValue;
};

struct chown_entry * chown_load_file(char * filename, int size);

/**
############# CHROOT syscall data structures ##############
**/

struct chroot_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct chroot_result_entry {
char * syscall;
int length_mean;
int length_variance;
int retValue;
};

struct chroot_entry * chroot_load_file(char * filename, int size);

/**
############# FCHOWN syscall data structures ##############
**/

struct fchown_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int owner;
int group;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct fchown_result_entry {
char * syscall;
int length_mean;
int length_variance;
int owner;
int group;
int retValue;
};

struct fchown_entry * fchown_load_file(char * filename, int size);

/**
############# EXECVE syscall data structures ##############
**/

struct execve_entry {
char * syscall;
char * path;
int filemode;
int file_owner_id;
int file_group_id;
int arguments_nb;
char ** arguments;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct execve_result_entry {
char * syscall;
int length_mean;
int length_variance;
int arguments_nb;
char ** arguments;
int * arguments_length;
int * arguments_mean;
int retValue;
};

struct execve_entry * execve_load_file(char * filename, int size);

/**
############# FCHOWN syscall data structures ##############
**/

struct sockconnect_entry {
char * syscall;
int socket_type;
int port;
int address;
int fd;
int priority;
int retValue;
int euid;
int egid;
int ruid;
int rgid;
};

struct sockconnect_result_entry {
char * syscall;
int socket_type;
int port;
int address;
int fd;
int priority;
int retValue;
};

struct sockconnect_entry * sockconnect_load_file(char * filename, int size);


#endif
