#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "clusterers.h"
#include "converters.h"


int training(char * training_file, int max_clusters);
int matching(char * matching_file);

/********************************************************************************
Usage : ./calcstats -t|-m file [-c] [nb_clusters]
**********************************************************************************/

int main(int argc, char* argv[]){

	/** Argument parsing
	**/
	int c;
	char * training_file = NULL;
	char * matching_file = NULL;
	int max_clusters = 0;

	while( (c= getopt(argc,argv,"t:m:c:")) != -1)
        switch(c){
			case 't':
			    training_file = optarg;
				printf("Training now with file : %s\n", training_file);
		 		break;       
			case 'm':
				matching_file = optarg;
				printf("Matching now with file : %s\n", matching_file);
			    break;
			case 'c':
				max_clusters = atoi(optarg);
				printf("Max nb clusters : %d\n", max_clusters);
				break;
			default:
				printf("Character code : %d\n",c);
		}


	if (training_file == NULL && matching_file == NULL){
		printf("No task specified, aborting.\n");
		return -1;
	}

	if (training_file != NULL)
		return training(training_file, max_clusters);

	else if (matching_file != NULL)
		return matching(matching_file);
}


int training(char * training_file, int max_clusters){

	struct open_entry * open_entries = NULL;
	struct open_transformed_entry * open_tr_entries = NULL;
	struct open_cluster * open_clusters = NULL;
	struct open_cluster open_cl;

	struct close_entry * close_entries = NULL;
	struct close_transformed_entry * close_tr_entries = NULL;
	struct close_cluster * close_clusters = NULL;
	struct close_cluster close_cl;

	struct mmap_entry * mmap_entries = NULL;
	struct mmap_transformed_entry * mmap_tr_entries = NULL;
	struct mmap_cluster * mmap_clusters = NULL;
	struct mmap_cluster mmap_cl;

	struct stat_entry * stat_entries = NULL;
	struct stat_transformed_entry * stat_tr_entries = NULL;
	struct stat_cluster * stat_clusters = NULL;
	struct stat_cluster stat_cl;

	struct access_entry * access_entries = NULL;
	struct access_transformed_entry * access_tr_entries = NULL;
	struct access_cluster * access_clusters = NULL;
	struct access_cluster access_cl;

	struct munmap_entry * munmap_entries = NULL;
	struct munmap_transformed_entry * munmap_tr_entries = NULL;
	struct munmap_cluster * munmap_clusters = NULL;
	struct munmap_cluster munmap_cl;

	struct putmsg_entry * putmsg_entries = NULL;
	struct putmsg_transformed_entry * putmsg_tr_entries = NULL;
	struct putmsg_cluster * putmsg_clusters = NULL;
	struct putmsg_cluster putmsg_cl;

	struct sysinfo_entry * sysinfo_entries = NULL;
	struct sysinfo_transformed_entry * sysinfo_tr_entries = NULL;
	struct sysinfo_cluster * sysinfo_clusters = NULL;
	struct sysinfo_cluster sysinfo_cl;

	struct chdir_entry * chdir_entries = NULL;
	struct chdir_transformed_entry * chdir_tr_entries = NULL;
	struct chdir_cluster * chdir_clusters = NULL;
	struct chdir_cluster chdir_cl;

	struct readlink_entry * readlink_entries = NULL;
	struct readlink_transformed_entry * readlink_tr_entries = NULL;
	struct readlink_cluster * readlink_clusters = NULL;
	struct readlink_cluster readlink_cl;

	struct unlink_entry * unlink_entries = NULL;
	struct unlink_transformed_entry * unlink_tr_entries = NULL;
	struct unlink_cluster * unlink_clusters = NULL;
	struct unlink_cluster unlink_cl;

	struct creat_entry * creat_entries = NULL;
	struct creat_transformed_entry * creat_tr_entries = NULL;
	struct creat_cluster * creat_clusters = NULL;
	struct creat_cluster creat_cl;

	struct lstat_entry * lstat_entries = NULL;
	struct lstat_transformed_entry * lstat_tr_entries = NULL;
	struct lstat_cluster * lstat_clusters = NULL;
	struct lstat_cluster lstat_cl;

	struct seteuid_entry * seteuid_entries = NULL;
	struct seteuid_transformed_entry * seteuid_tr_entries = NULL;
	struct seteuid_cluster * seteuid_clusters = NULL;
	struct seteuid_cluster seteuid_cl;

	struct setgid_entry * setgid_entries = NULL;
	struct setgid_transformed_entry * setgid_tr_entries = NULL;
	struct setgid_cluster * setgid_clusters = NULL;
	struct setgid_cluster setgid_cl;


	struct setgroups_entry * setgroups_entries = NULL;
	struct setgroups_transformed_entry * setgroups_tr_entries = NULL;
	struct setgroups_cluster * setgroups_clusters = NULL;
	struct setgroups_cluster setgroups_cl;

	struct setegid_entry * setegid_entries = NULL;
	struct setegid_transformed_entry * setegid_tr_entries = NULL;
	struct setegid_cluster * setegid_clusters = NULL;
	struct setegid_cluster setegid_cl;

	struct rename_entry * rename_entries = NULL;
	struct rename_transformed_entry * rename_tr_entries = NULL;
	struct rename_cluster * rename_clusters = NULL;
	struct rename_cluster rename_cl;
	
	struct ioctl_entry * ioctl_entries = NULL;
	struct ioctl_transformed_entry * ioctl_tr_entries = NULL;
	struct ioctl_cluster * ioctl_clusters = NULL;
	struct ioctl_cluster ioctl_cl;

	struct fcntl_entry * fcntl_entries = NULL;
	struct fcntl_transformed_entry * fcntl_tr_entries = NULL;
	struct fcntl_cluster * fcntl_clusters = NULL;
	struct fcntl_cluster fcntl_cl;

	struct getmsg_entry * getmsg_entries = NULL;
	struct getmsg_transformed_entry * getmsg_tr_entries = NULL;
	struct getmsg_cluster * getmsg_clusters = NULL;
	struct getmsg_cluster getmsg_cl;

	struct setuid_entry * setuid_entries = NULL;
	struct setuid_transformed_entry * setuid_tr_entries = NULL;
	struct setuid_cluster * setuid_clusters = NULL;
	struct setuid_cluster setuid_cl;

	struct vfork_entry * vfork_entries = NULL;
	struct vfork_transformed_entry * vfork_tr_entries = NULL;
	struct vfork_cluster * vfork_clusters = NULL;
	struct vfork_cluster vfork_cl;

	struct chown_entry * chown_entries = NULL;
	struct chown_transformed_entry * chown_tr_entries = NULL;
	struct chown_cluster * chown_clusters = NULL;
	struct chown_cluster chown_cl;

	struct chroot_entry * chroot_entries = NULL;
	struct chroot_transformed_entry * chroot_tr_entries = NULL;
	struct chroot_cluster * chroot_clusters = NULL;
	struct chroot_cluster chroot_cl;

	struct fchown_entry * fchown_entries = NULL;
	struct fchown_transformed_entry * fchown_tr_entries = NULL;
	struct fchown_cluster * fchown_clusters = NULL;
	struct fchown_cluster fchown_cl;

	struct execve_entry * execve_entries = NULL;
	struct execve_transformed_entry * execve_tr_entries = NULL;
	struct execve_cluster * execve_clusters = NULL;
	struct execve_cluster execve_cl;

	int i,j;
	int file_size;
	FILE * outfile,  * infile, * cluster_records =NULL;
	char * filename = NULL;


	infile = fopen(training_file, "r");
	if (infile == NULL){
		printf("Could not open the file !\n");
		return -1;
	}
	char line[400];
	char * token;
	fgets(line,400,infile);
    fclose(infile);
	token = strtok(line,",");
	printf("%s",token);
	if (strcmp(token,"OPEN") == 0){
   		open_entries = open_load_file(training_file, &file_size);
		printf("###### %s ########\n",open_entries[0].path);
	    open_clusters = open_cluster(open_entries, file_size, &max_clusters);
		// Serialize
		open_clusters_writer("clusters/open.xml", open_clusters, max_clusters);
		open_tr_entries = open_transform_data(open_entries,file_size);
   		for (i=0; i< file_size; i++){
			open_cl = open_match_entry_to_cluster(open_clusters,max_clusters,open_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%s:%d",open_entries[i].path,open_entries[i].flags,open_entries[i].retValue);
			printf("\nCluster : %s \n",open_cl.syscall);
			filename = (char *) malloc(13 + strlen(open_cl.syscall)+1);
			strncpy(filename,"results/open/",13);
			sprintf(filename+13,"%s\0",open_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%s,%d\n",open_entries[i].path,open_entries[i].flags,open_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(open_entries[i].syscall);
			free(open_entries[i].path);
			free(open_entries[i].flags);
		}
		free(open_entries);

		for(i=0; i<max_clusters; i++){
			free(open_clusters[i].syscall);
			free_string(open_clusters[i].flags);
			free_string(open_clusters[i].filenames);
			free_string(open_clusters[i].paths);
			free_integer(open_clusters[i].retValues);
			free_integer(open_clusters[i].filemodes);
			free_integer(open_clusters[i].file_owner_ids);
			free_integer(open_clusters[i].file_group_ids);
			free_integer(open_clusters[i].euids);
			free_integer(open_clusters[i].egids);
			free_integer(open_clusters[i].ruids);
			free_integer(open_clusters[i].rgids);
		}
		free(open_clusters);

		for(i=0; i<file_size; i++){
			free(open_tr_entries[i].syscall);
			free(open_tr_entries[i].path);
			free(open_tr_entries[i].filename);
			free(open_tr_entries[i].flags);
		}
		free(open_tr_entries);

	 }
	 else if (strcmp(token,"CLOSE") == 0){
		printf ("Close !");
		close_entries = close_load_file(training_file, &file_size);
		printf("###### %s ########\n",close_entries[0].path);
	    close_clusters = close_cluster(close_entries, file_size, &max_clusters);
		// Serialize
		close_clusters_writer("clusters/close.xml", close_clusters, max_clusters);

		close_tr_entries = close_transform_data(close_entries,file_size);
   		for (i=0; i< file_size; i++){
			close_cl = close_match_entry_to_cluster(close_clusters,max_clusters,close_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",close_entries[i].path,close_entries[i].retValue);
			printf("\nCluster : %s \n",close_cl.syscall);
			filename = (char *) malloc(14 + strlen(close_cl.syscall)+1);
			strncpy(filename,"results/close/",14);
			sprintf(filename+14,"%s\0",close_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",close_entries[i].path,close_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(close_entries[i].syscall);
			free(close_entries[i].path);
		}
		free(close_entries);

		for(i=0; i<max_clusters; i++){
			free(close_clusters[i].syscall);
			free_string(close_clusters[i].filenames);
			free_string(close_clusters[i].paths);
			free_integer(close_clusters[i].filemodes);
			free_integer(close_clusters[i].file_owner_ids);
			free_integer(close_clusters[i].file_group_ids);
			free_integer(close_clusters[i].retValues);
			free_integer(close_clusters[i].euids);
			free_integer(close_clusters[i].egids);
			free_integer(close_clusters[i].ruids);
			free_integer(close_clusters[i].rgids);
		}
		free(close_clusters);

		for(i=0; i<file_size; i++){
			free(close_tr_entries[i].syscall);
			free(close_tr_entries[i].path);
			free(close_tr_entries[i].filename);
		}
		free(close_tr_entries);

	 }
	 else if (strcmp(token,"MMAP") == 0){
		printf ("Mmap !");
		mmap_entries = mmap_load_file(training_file, &file_size);
		printf("###### %s ########\n",mmap_entries[0].path);
	    mmap_clusters = mmap_cluster(mmap_entries, file_size, &max_clusters);
		// Serialize
		mmap_clusters_writer("clusters/mmap.xml", mmap_clusters, max_clusters);

		mmap_tr_entries = mmap_transform_data(mmap_entries,file_size);
   		for (i=0; i< file_size; i++){
			mmap_cl = mmap_match_entry_to_cluster(mmap_clusters,max_clusters,mmap_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",mmap_entries[i].path,mmap_entries[i].retValue);
			printf("\nCluster : %s \n",mmap_cl.syscall);
			filename = (char *) malloc(13 + strlen(mmap_cl.syscall)+1);
			strncpy(filename,"results/mmap/",13);
			sprintf(filename+13,"%s\0",mmap_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",mmap_entries[i].path,mmap_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}
		
		// Free resources
		for(i=0; i<file_size; i++){
			free(mmap_entries[i].syscall);
			free(mmap_entries[i].path);
		}
		free(mmap_entries);

		for(i=0; i<max_clusters; i++){
			free(mmap_clusters[i].syscall);
			free_string(mmap_clusters[i].filenames);
			free_string(mmap_clusters[i].paths);
			free_integer(mmap_clusters[i].retValues);
			free_integer(mmap_clusters[i].filemodes);
			free_integer(mmap_clusters[i].file_owner_ids);
			free_integer(mmap_clusters[i].file_group_ids);
			free_integer(mmap_clusters[i].ruids);
			free_integer(mmap_clusters[i].rgids);
			free_integer(mmap_clusters[i].euids);
			free_integer(mmap_clusters[i].egids);
		}
		free(mmap_clusters);

		for(i=0; i<file_size; i++){
			free(mmap_tr_entries[i].syscall);
			free(mmap_tr_entries[i].path);
			free(mmap_tr_entries[i].filename);
		}
		free(mmap_tr_entries);

	 }
	 else if (strcmp(token,"STAT") == 0){
		printf ("Stat !");
		stat_entries = stat_load_file(training_file, &file_size);
		printf("###### %s ########\n",stat_entries[0].path);
	    stat_clusters = stat_cluster(stat_entries, file_size, &max_clusters);
		// Serialize
		stat_clusters_writer("clusters/stat.xml", stat_clusters, max_clusters);

		stat_tr_entries = stat_transform_data(stat_entries,file_size);
   		for (i=0; i< file_size; i++){
			stat_cl = stat_match_entry_to_cluster(stat_clusters,max_clusters,stat_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",stat_entries[i].path,stat_entries[i].retValue);
			printf("\nCluster : %s \n",stat_cl.syscall);
			filename = (char *) malloc(13 + strlen(stat_cl.syscall)+1);
			strncpy(filename,"results/stat/",13);
			sprintf(filename+13,"%s\0",stat_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",stat_entries[i].path,stat_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(stat_entries[i].syscall);
			free(stat_entries[i].path);
		}
		free(stat_entries);

		for(i=0; i<max_clusters; i++){
			free(stat_clusters[i].syscall);
			free_integer(stat_clusters[i].retValues);
			free_string(stat_clusters[i].filenames);
			free_string(stat_clusters[i].paths);
			free_integer(stat_clusters[i].filemodes);
			free_integer(stat_clusters[i].file_owner_ids);
			free_integer(stat_clusters[i].file_group_ids);
			free_integer(stat_clusters[i].ruids);
			free_integer(stat_clusters[i].rgids);
			free_integer(stat_clusters[i].euids);
			free_integer(stat_clusters[i].egids);
		}
		free(stat_clusters);

		for(i=0; i<file_size; i++){
			free(stat_tr_entries[i].syscall);
			free(stat_tr_entries[i].path);
			free(stat_tr_entries[i].filename);
		}
		free(stat_tr_entries);

	 }
	
	else if (strcmp(token,"ACCESS") == 0){
		printf ("Access !");
		access_entries = access_load_file(training_file, &file_size);
		printf("###### %s ########\n",access_entries[0].path);
	    access_clusters = access_cluster(access_entries, file_size, &max_clusters);
		// Serialize
		access_clusters_writer("clusters/access.xml", access_clusters, max_clusters);

		access_tr_entries = access_transform_data(access_entries,file_size);
   		for (i=0; i< file_size; i++){
			access_cl = access_match_entry_to_cluster(access_clusters,max_clusters,access_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",access_entries[i].path,access_entries[i].retValue);
			printf("\nCluster : %s \n",access_cl.syscall);
			filename = (char *) malloc(15 + strlen(access_cl.syscall)+1);
			strncpy(filename,"results/access/",15);
			sprintf(filename+15,"%s\0",access_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",access_entries[i].path,access_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(access_entries[i].syscall);
			free(access_entries[i].path);
		}
		free(access_entries);

		for(i=0; i<max_clusters; i++){
			free(access_clusters[i].syscall);
			free_string(access_clusters[i].filenames);
			free_string(access_clusters[i].paths);
			free_integer(access_clusters[i].retValues);
			free_integer(access_clusters[i].filemodes);
			free_integer(access_clusters[i].file_owner_ids);
			free_integer(access_clusters[i].file_group_ids);
			free_integer(access_clusters[i].ruids);
			free_integer(access_clusters[i].rgids);
			free_integer(access_clusters[i].euids);
			free_integer(access_clusters[i].egids);
		}
		free(access_clusters);

		for(i=0; i<file_size; i++){
			free(access_tr_entries[i].syscall);
			free(access_tr_entries[i].path);
			free(access_tr_entries[i].filename);
		}
		free(access_tr_entries);

	 }

	else if (strcmp(token,"MUNMAP") == 0){
		printf ("Munmap !");
		munmap_entries = munmap_load_file(training_file, &file_size);
	    munmap_clusters = munmap_cluster(munmap_entries, file_size, &max_clusters);
		// Serialize
		munmap_clusters_writer("clusters/munmap.xml", munmap_clusters, max_clusters);

		munmap_tr_entries = munmap_transform_data(munmap_entries,file_size);
   		for (i=0; i< file_size; i++){
			munmap_cl = munmap_match_entry_to_cluster(munmap_clusters,max_clusters,munmap_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d:%d",munmap_entries[i].address,munmap_entries[i].length,munmap_entries[i].retValue);
			printf("\nCluster : %s \n",munmap_cl.syscall);
			filename = (char *) malloc(15 + strlen(munmap_cl.syscall)+1);
			strncpy(filename,"results/munmap/",15);
			sprintf(filename+15,"%s\0",munmap_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%x,%d\n",munmap_entries[i].address,munmap_entries[i].length,munmap_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(munmap_entries[i].syscall);
		free(munmap_entries);

		for(i=0; i<max_clusters; i++){
			free(munmap_clusters[i].syscall);
			free_integer(munmap_clusters[i].retValues);
			free_integer(munmap_clusters[i].addresses);
			free_integer(munmap_clusters[i].lengths);
			free_integer(munmap_clusters[i].euids);
			free_integer(munmap_clusters[i].egids);
			free_integer(munmap_clusters[i].ruids);
			free_integer(munmap_clusters[i].rgids);
		}
		free(munmap_clusters);

		for(i=0; i<file_size; i++)
			free(munmap_tr_entries[i].syscall);
		free(munmap_tr_entries);

	 }

	else if (strcmp(token,"PUTMSG") == 0){
		printf ("Putmsg !");
		putmsg_entries = putmsg_load_file(training_file, &file_size);
	    putmsg_clusters = putmsg_cluster(putmsg_entries, file_size, &max_clusters);
		// Serialize
		putmsg_clusters_writer("clusters/putmsg.xml", putmsg_clusters, max_clusters);

		putmsg_tr_entries = putmsg_transform_data(putmsg_entries,file_size);
   		for (i=0; i< file_size; i++){
			putmsg_cl = putmsg_match_entry_to_cluster(putmsg_clusters,max_clusters,putmsg_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d:%d",putmsg_entries[i].filedes,putmsg_entries[i].flags,putmsg_entries[i].retValue);
			printf("\nCluster : %s \n",putmsg_cl.syscall);
			filename = (char *) malloc(15 + strlen(putmsg_cl.syscall)+1);
			strncpy(filename,"results/putmsg/",15);
			sprintf(filename+15,"%s\0",putmsg_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%x,%d\n",putmsg_entries[i].filedes,putmsg_entries[i].flags,putmsg_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(putmsg_entries[i].syscall);
		free(putmsg_entries);

		for(i=0; i<max_clusters; i++){
			free(putmsg_clusters[i].syscall);
			free_integer(putmsg_clusters[i].filedess);
			free_integer(putmsg_clusters[i].flags);
			free_integer(putmsg_clusters[i].retValues);
			free_integer(putmsg_clusters[i].ruids);
			free_integer(putmsg_clusters[i].rgids);
			free_integer(putmsg_clusters[i].euids);
			free_integer(putmsg_clusters[i].egids);
		}
		free(putmsg_clusters);

		for(i=0; i<file_size; i++)
			free(putmsg_tr_entries[i].syscall);
		free(putmsg_tr_entries);

	 }

	else if (strcmp(token,"SYSINFO") == 0){
		printf ("Sysinfo !");
		sysinfo_entries = sysinfo_load_file(training_file, &file_size);
	    sysinfo_clusters = sysinfo_cluster(sysinfo_entries, file_size, &max_clusters);
		// Serialize
		sysinfo_clusters_writer("clusters/sysinfo.xml", sysinfo_clusters, max_clusters);

		sysinfo_tr_entries = sysinfo_transform_data(sysinfo_entries,file_size);
   		for (i=0; i< file_size; i++){
			sysinfo_cl = sysinfo_match_entry_to_cluster(sysinfo_clusters,max_clusters,sysinfo_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d",sysinfo_entries[i].command,sysinfo_entries[i].retValue);
			printf("\nCluster : %s \n",sysinfo_cl.syscall);
			filename = (char *) malloc(16 + strlen(sysinfo_cl.syscall)+1);
			strncpy(filename,"results/sysinfo/",16);
			sprintf(filename+16,"%s\0",sysinfo_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",sysinfo_entries[i].command,sysinfo_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(sysinfo_entries[i].syscall);
		free(sysinfo_entries);

		for(i=0; i<max_clusters; i++){
			free(sysinfo_clusters[i].syscall);
			free_integer(sysinfo_clusters[i].commands);
			free_integer(sysinfo_clusters[i].retValues);
			free_integer(sysinfo_clusters[i].ruids);
			free_integer(sysinfo_clusters[i].rgids);
			free_integer(sysinfo_clusters[i].euids);
			free_integer(sysinfo_clusters[i].egids);
		}
		free(sysinfo_clusters);

		for(i=0; i<file_size; i++)
			free(sysinfo_tr_entries[i].syscall);
		free(sysinfo_tr_entries);
	 }
	else if (strcmp(token,"CHDIR") == 0){
		printf ("Chdir !");
		chdir_entries = chdir_load_file(training_file, &file_size);
		printf("###### %s ########\n",chdir_entries[0].path);
	    chdir_clusters = chdir_cluster(chdir_entries, file_size, &max_clusters);
		// Serialize
		chdir_clusters_writer("clusters/chdir.xml", chdir_clusters, max_clusters);

		chdir_tr_entries = chdir_transform_data(chdir_entries,file_size);
   		for (i=0; i< file_size; i++){
			chdir_cl = chdir_match_entry_to_cluster(chdir_clusters,max_clusters,chdir_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",chdir_entries[i].path,chdir_entries[i].retValue);
			printf("\nCluster : %s \n",chdir_cl.syscall);
			filename = (char *) malloc(14 + strlen(chdir_cl.syscall)+1);
			strncpy(filename,"results/chdir/",14);
			sprintf(filename+14,"%s\0",chdir_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",chdir_entries[i].path,chdir_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(chdir_entries[i].syscall);
			free(chdir_entries[i].path);
		}
		free(chdir_entries);

		for(i=0; i<max_clusters; i++){
			free(chdir_clusters[i].syscall);
			free_string(chdir_clusters[i].filenames);
			free_string(chdir_clusters[i].paths);
			free_integer(chdir_clusters[i].filemodes);
			free_integer(chdir_clusters[i].file_owner_ids);
			free_integer(chdir_clusters[i].file_group_ids);
			free_integer(chdir_clusters[i].retValues);
			free_integer(chdir_clusters[i].ruids);
			free_integer(chdir_clusters[i].rgids);
			free_integer(chdir_clusters[i].euids);
			free_integer(chdir_clusters[i].egids);
		}
		free(chdir_clusters);

		for(i=0; i<file_size; i++){
			free(chdir_tr_entries[i].syscall);
			free(chdir_tr_entries[i].path);
			free(chdir_tr_entries[i].filename);
		}
		free(chdir_tr_entries);

	 }
	
	else if (strcmp(token,"READLINK") == 0){
		printf ("Readlink !");
		readlink_entries = readlink_load_file(training_file, &file_size);
		printf("###### %s ########\n",readlink_entries[0].path);
	    readlink_clusters = readlink_cluster(readlink_entries, file_size, &max_clusters);
		// Serialize
		readlink_clusters_writer("clusters/readlink.xml", readlink_clusters, max_clusters);
	
		readlink_tr_entries = readlink_transform_data(readlink_entries,file_size);
   		for (i=0; i< file_size; i++){
			readlink_cl = readlink_match_entry_to_cluster(readlink_clusters,max_clusters,readlink_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",readlink_entries[i].path,readlink_entries[i].retValue);
			printf("\nCluster : %s \n",readlink_cl.syscall);
			filename = (char *) malloc(15 + strlen(readlink_cl.syscall)+1);
			strncpy(filename,"results/readlink/",15);
			sprintf(filename+15,"%s\0",readlink_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",readlink_entries[i].path,readlink_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(readlink_entries[i].syscall);
			free(readlink_entries[i].path);
		}
		free(readlink_entries);

		for(i=0; i<max_clusters; i++){
			free(readlink_clusters[i].syscall);
			free_string(readlink_clusters[i].filenames);
			free_string(readlink_clusters[i].paths);
			free_integer(readlink_clusters[i].filemodes);
			free_integer(readlink_clusters[i].file_owner_ids);
			free_integer(readlink_clusters[i].file_group_ids);
			free_integer(readlink_clusters[i].retValues);
			free_integer(readlink_clusters[i].ruids);
			free_integer(readlink_clusters[i].rgids);
			free_integer(readlink_clusters[i].euids);
			free_integer(readlink_clusters[i].egids);
		}
		free(readlink_clusters);

		for(i=0; i<file_size; i++){
			free(readlink_tr_entries[i].syscall);
			free(readlink_tr_entries[i].filename);
		}
		free(readlink_tr_entries);

	 }

	else if (strcmp(token,"UNLINK") == 0){
		printf ("Unlink !");
		unlink_entries = unlink_load_file(training_file, &file_size);
		printf("###### %s ########\n",unlink_entries[0].path);
	    unlink_clusters = unlink_cluster(unlink_entries, file_size, &max_clusters);
		// Serialize
		unlink_clusters_writer("clusters/unlink.xml", unlink_clusters, max_clusters);

		unlink_tr_entries = unlink_transform_data(unlink_entries,file_size);
   		for (i=0; i< file_size; i++){
			unlink_cl = unlink_match_entry_to_cluster(unlink_clusters,max_clusters,unlink_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",unlink_entries[i].path,unlink_entries[i].retValue);
			printf("\nCluster : %s \n",unlink_cl.syscall);
			filename = (char *) malloc(15 + strlen(unlink_cl.syscall)+1);
			strncpy(filename,"results/unlink/",15);
			sprintf(filename+15,"%s\0",unlink_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",unlink_entries[i].path,unlink_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(unlink_entries[i].syscall);
			free(unlink_entries[i].path);
		}
		free(unlink_entries);

		for(i=0; i<max_clusters; i++){
			free(unlink_clusters[i].syscall);
			free_integer(unlink_clusters[i].retValues);
			free_string(unlink_clusters[i].filenames);
			free_string(unlink_clusters[i].paths);
			free_integer(unlink_clusters[i].filemodes);
			free_integer(unlink_clusters[i].file_owner_ids);
			free_integer(unlink_clusters[i].file_group_ids);
			free_integer(unlink_clusters[i].ruids);
			free_integer(unlink_clusters[i].rgids);
			free_integer(unlink_clusters[i].euids);
			free_integer(unlink_clusters[i].egids);
		}
		free(unlink_clusters);

		for(i=0; i<file_size; i++){
			free(unlink_tr_entries[i].syscall);
			free(unlink_tr_entries[i].path);
			free(unlink_tr_entries[i].filename);
		}
		free(unlink_tr_entries);

	 }
	else if (strcmp(token,"CREAT") == 0){
		printf ("Creat !");
		creat_entries = creat_load_file(training_file, &file_size);
		printf("###### %s ########\n",creat_entries[0].path);
	    creat_clusters = creat_cluster(creat_entries, file_size, &max_clusters);
		// Serialize
		creat_clusters_writer("clusters/creat.xml", creat_clusters, max_clusters);

		creat_tr_entries = creat_transform_data(creat_entries,file_size);
   		for (i=0; i< file_size; i++){
			creat_cl = creat_match_entry_to_cluster(creat_clusters,max_clusters,creat_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",creat_entries[i].path,creat_entries[i].retValue);
			printf("\nCluster : %s \n",creat_cl.syscall);
			filename = (char *) malloc(15 + strlen(creat_cl.syscall)+1);
			strncpy(filename,"results/creat/",15);
			sprintf(filename+15,"%s\0",creat_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",creat_entries[i].path,creat_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(creat_entries[i].syscall);
			free(creat_entries[i].path);
		}
		free(creat_entries);

		for(i=0; i<max_clusters; i++){
			free(creat_clusters[i].syscall);
			free_integer(creat_clusters[i].retValues);
			free_string(creat_clusters[i].filenames);
			free_string(creat_clusters[i].paths);
			free_integer(creat_clusters[i].filemodes);
			free_integer(creat_clusters[i].file_owner_ids);
			free_integer(creat_clusters[i].file_group_ids);
			free_integer(creat_clusters[i].ruids);
			free_integer(creat_clusters[i].rgids);
			free_integer(creat_clusters[i].euids);
			free_integer(creat_clusters[i].egids);
		}
		free(creat_clusters);

		for(i=0; i<file_size; i++){
			free(creat_tr_entries[i].syscall);
			free(creat_tr_entries[i].path);
			free(creat_tr_entries[i].filename);
		}
		free(creat_tr_entries);

	 }
	
	else if (strcmp(token,"LSTAT") == 0){
		printf ("Lstat !");
		lstat_entries = lstat_load_file(training_file, &file_size);
		printf("###### %s ########\n",lstat_entries[0].path);
	    lstat_clusters = lstat_cluster(lstat_entries, file_size, &max_clusters);
		// Serialize
		lstat_clusters_writer("clusters/lstat.xml", lstat_clusters, max_clusters);

		lstat_tr_entries = lstat_transform_data(lstat_entries,file_size);
   		for (i=0; i< file_size; i++){
			lstat_cl = lstat_match_entry_to_cluster(lstat_clusters,max_clusters,lstat_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",lstat_entries[i].path,lstat_entries[i].retValue);
			printf("\nCluster : %s \n",lstat_cl.syscall);
			filename = (char *) malloc(15 + strlen(lstat_cl.syscall)+1);
			strncpy(filename,"results/lstat/",15);
			sprintf(filename+15,"%s\0",lstat_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",lstat_entries[i].path,lstat_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(lstat_entries[i].syscall);
			free(lstat_entries[i].path);
		}
		free(lstat_entries);

		for(i=0; i<max_clusters; i++){
			free(lstat_clusters[i].syscall);
			free_integer(lstat_clusters[i].retValues);
			free_string(lstat_clusters[i].filenames);
			free_string(lstat_clusters[i].paths);
			free_integer(lstat_clusters[i].filemodes);
			free_integer(lstat_clusters[i].file_owner_ids);
			free_integer(lstat_clusters[i].file_group_ids);
			free_integer(lstat_clusters[i].ruids);
			free_integer(lstat_clusters[i].rgids);
			free_integer(lstat_clusters[i].euids);
			free_integer(lstat_clusters[i].egids);
		}
		free(lstat_clusters);

		for(i=0; i<file_size; i++){
			free(lstat_tr_entries[i].syscall);
			free(lstat_tr_entries[i].path);
			free(lstat_tr_entries[i].filename);
		}
		free(lstat_tr_entries);

	 }

	else if (strcmp(token,"SETEUID") == 0){
		printf ("Seteuid !");
		seteuid_entries = seteuid_load_file(training_file, &file_size);
	    seteuid_clusters = seteuid_cluster(seteuid_entries, file_size, &max_clusters);
		// Serialize
		seteuid_clusters_writer("clusters/seteuid.xml", seteuid_clusters, max_clusters);

		seteuid_tr_entries = seteuid_transform_data(seteuid_entries,file_size);
   		for (i=0; i< file_size; i++){
			seteuid_cl = seteuid_match_entry_to_cluster(seteuid_clusters,max_clusters,seteuid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",seteuid_entries[i].euid,seteuid_entries[i].retValue);
			printf("\nCluster : %s \n",seteuid_cl.syscall);
			filename = (char *) malloc(16 + strlen(seteuid_cl.syscall)+1);
			strncpy(filename,"results/seteuid/",16);
			sprintf(filename+16,"%s\0",seteuid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",seteuid_entries[i].euid,seteuid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(seteuid_entries[i].syscall);
		free(seteuid_entries);

		for(i=0; i<max_clusters; i++){
			free(seteuid_clusters[i].syscall);
			free_integer(seteuid_clusters[i].retValues);
			free_integer(seteuid_clusters[i].p_euids);
			free_integer(seteuid_clusters[i].ruids);
			free_integer(seteuid_clusters[i].rgids);
			free_integer(seteuid_clusters[i].euids);
			free_integer(seteuid_clusters[i].egids);
		}
		free(seteuid_clusters);

		for(i=0; i<file_size; i++)
			free(seteuid_tr_entries[i].syscall);
		free(seteuid_tr_entries);

	 }

	else if (strcmp(token,"SETGID") == 0){
		printf ("Setgid !");
		setgid_entries = setgid_load_file(training_file, &file_size);
	    setgid_clusters = setgid_cluster(setgid_entries, file_size, &max_clusters);
		
		setgid_tr_entries = setgid_transform_data(setgid_entries,file_size);
   		for (i=0; i< file_size; i++){
			setgid_cl = setgid_match_entry_to_cluster(setgid_clusters,max_clusters,setgid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setgid_entries[i].gid,setgid_entries[i].retValue);
			printf("\nCluster : %s \n",setgid_cl.syscall);
			filename = (char *) malloc(15 + strlen(setgid_cl.syscall)+1);
			strncpy(filename,"results/setgid/",15);
			sprintf(filename+15,"%s\0",setgid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setgid_entries[i].gid,setgid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(setgid_entries[i].syscall);
		free(setgid_entries);

		for(i=0; i<max_clusters; i++){
			free(setgid_clusters[i].syscall);
			free_integer(setgid_clusters[i].retValues);
			free_integer(setgid_clusters[i].gids);
			free_integer(setgid_clusters[i].euids);
			free_integer(setgid_clusters[i].egids);
			free_integer(setgid_clusters[i].ruids);
			free_integer(setgid_clusters[i].rgids);
		}
		free(setgid_clusters);

		for(i=0; i<file_size; i++)
			free(setgid_tr_entries[i].syscall);
		free(setgid_tr_entries);

	 }

	else if (strcmp(token,"SETGROUPS") == 0){
		printf ("Setgroups !");
		setgroups_entries = setgroups_load_file(training_file, &file_size);
	    setgroups_clusters = setgroups_cluster(setgroups_entries, file_size, &max_clusters);
		// Serialize
		setgroups_clusters_writer("clusters/setgroups.xml", setgroups_clusters, max_clusters);

		setgroups_tr_entries = setgroups_transform_data(setgroups_entries,file_size);
   		for (i=0; i< file_size; i++){
			setgroups_cl = setgroups_match_entry_to_cluster(setgroups_clusters,max_clusters,setgroups_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setgroups_entries[i].ngroups,setgroups_entries[i].retValue);
			printf("\nCluster : %s \n",setgroups_cl.syscall);
			filename = (char *) malloc(18 + strlen(setgroups_cl.syscall)+1);
			strncpy(filename,"results/setgroups/",18);
			sprintf(filename+18,"%s\0",setgroups_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setgroups_entries[i].ngroups,setgroups_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(setgroups_entries[i].syscall);
		free(setgroups_entries);

		for(i=0; i<max_clusters; i++){
			free(setgroups_clusters[i].syscall);
			free_integer(setgroups_clusters[i].ngroupss);
			free_integer(setgroups_clusters[i].retValues);
			free_integer(setgroups_clusters[i].ruids);
			free_integer(setgroups_clusters[i].rgids);
			free_integer(setgroups_clusters[i].euids);
			free_integer(setgroups_clusters[i].egids);
		}
		free(setgroups_clusters);

		for(i=0; i<file_size; i++)
			free(setgroups_tr_entries[i].syscall);
		free(setgroups_tr_entries);

	 }

	else if (strcmp(token,"SETEGID") == 0){
		printf ("Setegid !");
		setegid_entries = setegid_load_file(training_file, &file_size);
	    setegid_clusters = setegid_cluster(setegid_entries, file_size, &max_clusters);
		// Serialize
		setegid_clusters_writer("clusters/setegid.xml", setegid_clusters, max_clusters);

		setegid_tr_entries = setegid_transform_data(setegid_entries,file_size);
   		for (i=0; i< file_size; i++){
			setegid_cl = setegid_match_entry_to_cluster(setegid_clusters,max_clusters,setegid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setegid_entries[i].egid,setegid_entries[i].retValue);
			printf("\nCluster : %s \n",setegid_cl.syscall);
			filename = (char *) malloc(16 + strlen(setegid_cl.syscall)+1);
			strncpy(filename,"results/setegid/",16);
			sprintf(filename+16,"%s\0",setegid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setegid_entries[i].egid,setegid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(setegid_entries[i].syscall);
		free(setegid_entries);

		for(i=0; i<max_clusters; i++){
			free(setegid_clusters[i].syscall);
			free_integer(setegid_clusters[i].p_egids);
			free_integer(setegid_clusters[i].retValues);
			free_integer(setegid_clusters[i].ruids);
			free_integer(setegid_clusters[i].rgids);
			free_integer(setegid_clusters[i].euids);
			free_integer(setegid_clusters[i].egids);
		}
		free(setegid_clusters);

		for(i=0; i<file_size; i++)
			free(setegid_tr_entries[i].syscall);
		free(setegid_tr_entries);

	 }

	else if (strcmp(token,"RENAME") == 0){
		printf ("Rename !");
		rename_entries = rename_load_file(training_file, &file_size);
	    rename_clusters = rename_cluster(rename_entries, file_size, &max_clusters);
		// Serialize
		rename_clusters_writer("clusters/rename.xml", rename_clusters, max_clusters);

		rename_tr_entries = rename_transform_data(rename_entries,file_size);
   		for (i=0; i< file_size; i++){
			rename_cl = rename_match_entry_to_cluster(rename_clusters,max_clusters,rename_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%s:%d",rename_entries[i].path1, rename_entries[i].path2, rename_entries[i].retValue);
			printf("\nCluster : %s \n",rename_cl.syscall);
			filename = (char *) malloc(15 + strlen(rename_cl.syscall)+1);
			strncpy(filename,"results/rename/",15);
			sprintf(filename+15,"%s\0",rename_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%s,%d\n",rename_entries[i].path1,rename_entries[i].path2,rename_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(rename_entries[i].syscall);
			free(rename_entries[i].path1);
			free(rename_entries[i].path2);
		}
		free(rename_entries);

		for(i=0; i<max_clusters; i++){
			free(rename_clusters[i].syscall);
			free_integer(rename_clusters[i].retValues);
			free_string(rename_clusters[i].filenames1);
			free_string(rename_clusters[i].filenames2);
			free_string(rename_clusters[i].paths1);
			free_string(rename_clusters[i].paths2);
			free_integer(rename_clusters[i].filemodes1);
			free_integer(rename_clusters[i].filemodes2);
			free_integer(rename_clusters[i].file1_owner_ids);
			free_integer(rename_clusters[i].file1_group_ids);
			free_integer(rename_clusters[i].file2_owner_ids);
			free_integer(rename_clusters[i].file2_group_ids);
			free_integer(rename_clusters[i].ruids);
			free_integer(rename_clusters[i].rgids);
			free_integer(rename_clusters[i].euids);
			free_integer(rename_clusters[i].egids);
		}
		free(rename_clusters);

		for(i=0; i<file_size; i++){
			free(rename_tr_entries[i].syscall);
			free(rename_tr_entries[i].path1);
			free(rename_tr_entries[i].path2);
			free(rename_tr_entries[i].filename1);
			free(rename_tr_entries[i].filename2);
		}
		free(rename_tr_entries);

	 }
	 else if (strcmp(token,"IOCTL") == 0){
		printf ("Ioctl !");
		ioctl_entries = ioctl_load_file(training_file, &file_size);
		printf("###### %s ########\n",ioctl_entries[0].path);
	    ioctl_clusters = ioctl_cluster(ioctl_entries, file_size, &max_clusters);
		// Serialize
		ioctl_clusters_writer("clusters/ioctl.xml", ioctl_clusters, max_clusters);

		ioctl_tr_entries = ioctl_transform_data(ioctl_entries,file_size);
   		for (i=0; i< file_size; i++){
			ioctl_cl = ioctl_match_entry_to_cluster(ioctl_clusters,max_clusters,ioctl_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d:%d",ioctl_entries[i].path, ioctl_entries[i].command, ioctl_entries[i].arg, ioctl_entries[i].retValue);
			printf("\nCluster : %s \n",ioctl_cl.syscall);
			filename = (char *) malloc(14 + strlen(ioctl_cl.syscall)+1);
			strncpy(filename,"results/ioctl/",14);
			sprintf(filename+14,"%s\0",ioctl_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d,%d\n",ioctl_entries[i].path, ioctl_entries[i].command, ioctl_entries[i].arg, ioctl_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(ioctl_entries[i].syscall);
			free(ioctl_entries[i].path);
		}
		free(ioctl_entries);

		for(i=0; i<max_clusters; i++){
			free(ioctl_clusters[i].syscall);
			free_integer(ioctl_clusters[i].retValues);
			free_integer(ioctl_clusters[i].commands);
			free_integer(ioctl_clusters[i].args);
			free_string(ioctl_clusters[i].paths);
			free_string(ioctl_clusters[i].filenames);
			free_integer(ioctl_clusters[i].filemodes);
			free_integer(ioctl_clusters[i].file_owner_ids);
			free_integer(ioctl_clusters[i].file_group_ids);
			free_integer(ioctl_clusters[i].ruids);
			free_integer(ioctl_clusters[i].rgids);
			free_integer(ioctl_clusters[i].euids);
			free_integer(ioctl_clusters[i].egids);
		}
		free(ioctl_clusters);

		for(i=0; i<file_size; i++){
			free(ioctl_tr_entries[i].syscall);
			free(ioctl_tr_entries[i].path);
			free(ioctl_tr_entries[i].filename);
		}
		free(ioctl_tr_entries);

	 }

	 else if (strcmp(token,"FCNTL") == 0){
		printf ("Fcntl !");
		fcntl_entries = fcntl_load_file(training_file, &file_size);
		printf("###### %s ########\n",fcntl_entries[0].path);
	    fcntl_clusters = fcntl_cluster(fcntl_entries, file_size, &max_clusters);
		// Serialize
		fcntl_clusters_writer("clusters/fcntl.xml", fcntl_clusters, max_clusters);

		fcntl_tr_entries = fcntl_transform_data(fcntl_entries,file_size);
   		for (i=0; i< file_size; i++){
			fcntl_cl = fcntl_match_entry_to_cluster(fcntl_clusters,max_clusters,fcntl_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d",fcntl_entries[i].path, fcntl_entries[i].command, fcntl_entries[i].retValue);
			printf("\nCluster : %s \n",fcntl_cl.syscall);
			filename = (char *) malloc(14 + strlen(fcntl_cl.syscall)+1);
			strncpy(filename,"results/fcntl/",14);
			sprintf(filename+14,"%s\0",fcntl_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d\n",fcntl_entries[i].path, fcntl_entries[i].command, fcntl_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(fcntl_entries[i].syscall);
			free(fcntl_entries[i].path);
		}
		free(fcntl_entries);

		for(i=0; i<max_clusters; i++){
			free(fcntl_clusters[i].syscall);
			free_integer(fcntl_clusters[i].commands);
			free_integer(fcntl_clusters[i].retValues);
			free_string(fcntl_clusters[i].filenames);
			free_string(fcntl_clusters[i].paths);
			free_integer(fcntl_clusters[i].filemodes);
			free_integer(fcntl_clusters[i].file_owner_ids);
			free_integer(fcntl_clusters[i].file_group_ids);
			free_integer(fcntl_clusters[i].ruids);
			free_integer(fcntl_clusters[i].rgids);
			free_integer(fcntl_clusters[i].euids);
			free_integer(fcntl_clusters[i].egids);
		}
		free(fcntl_clusters);

		for(i=0; i<file_size; i++){
			free(fcntl_tr_entries[i].syscall);
			free(fcntl_tr_entries[i].path);
			free(fcntl_tr_entries[i].filename);
		}
		free(fcntl_tr_entries);

	 }

	else if (strcmp(token,"GETMSG") == 0){
		printf ("Getmsg !");
		getmsg_entries = getmsg_load_file(training_file, &file_size);
	    getmsg_clusters = getmsg_cluster(getmsg_entries, file_size, &max_clusters);
		// Serialize
		getmsg_clusters_writer("clusters/getmsg.xml", getmsg_clusters, max_clusters);

		getmsg_tr_entries = getmsg_transform_data(getmsg_entries,file_size);
   		for (i=0; i< file_size; i++){
			getmsg_cl = getmsg_match_entry_to_cluster(getmsg_clusters,max_clusters,getmsg_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%d:%d:%d",getmsg_entries[i].filedes,getmsg_entries[i].flags,getmsg_entries[i].retValue);
			printf("\nCluster : %s \n",getmsg_cl.syscall);
			filename = (char *) malloc(15 + strlen(getmsg_cl.syscall)+1);
			strncpy(filename,"results/getmsg/",15);
			sprintf(filename+15,"%s\0",getmsg_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%x,%d\n",getmsg_entries[i].filedes,getmsg_entries[i].flags,getmsg_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(getmsg_entries[i].syscall);
		free(getmsg_entries);

		for(i=0; i<max_clusters; i++){
			free(getmsg_clusters[i].syscall);
			free_integer(getmsg_clusters[i].filedess);
			free_integer(getmsg_clusters[i].flags);
			free_integer(getmsg_clusters[i].retValues);
			free_integer(getmsg_clusters[i].ruids);
			free_integer(getmsg_clusters[i].rgids);
			free_integer(getmsg_clusters[i].euids);
			free_integer(getmsg_clusters[i].egids);
		}
		free(getmsg_clusters);

		for(i=0; i<file_size; i++)
			free(getmsg_tr_entries[i].syscall);
		free(getmsg_tr_entries);

	 }

	else if (strcmp(token,"SETUID") == 0){
		printf ("Setuid !");
		setuid_entries = setuid_load_file(training_file, &file_size);
	    setuid_clusters = setuid_cluster(setuid_entries, file_size, &max_clusters);
		// Serialize
		setuid_clusters_writer("clusters/setuid.xml", setuid_clusters, max_clusters);

		setuid_tr_entries = setuid_transform_data(setuid_entries,file_size);
   		for (i=0; i< file_size; i++){
			setuid_cl = setuid_match_entry_to_cluster(setuid_clusters,max_clusters,setuid_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",setuid_entries[i].uid,setuid_entries[i].retValue);
			printf("\nCluster : %s \n",setuid_cl.syscall);
			filename = (char *) malloc(15 + strlen(setuid_cl.syscall)+1);
			strncpy(filename,"results/setuid/",15);
			sprintf(filename+15,"%s\0",setuid_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",setuid_entries[i].uid,setuid_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(setuid_entries[i].syscall);
		free(setuid_entries);

		for(i=0; i<max_clusters; i++){
			free(setuid_clusters[i].syscall);
			free_integer(setuid_clusters[i].uids);
			free_integer(setuid_clusters[i].retValues);
			free_integer(setuid_clusters[i].ruids);
			free_integer(setuid_clusters[i].rgids);
			free_integer(setuid_clusters[i].euids);
			free_integer(setuid_clusters[i].egids);
		}
		free(setuid_clusters);

		for(i=0; i<file_size; i++)
			free(setuid_tr_entries[i].syscall);
		free(setuid_tr_entries);

	 }

	else if (strcmp(token,"VFORK") == 0){
		printf ("Vfork !");
		vfork_entries = vfork_load_file(training_file, &file_size);
	    vfork_clusters = vfork_cluster(vfork_entries, file_size, &max_clusters);
		// Serialize
		vfork_clusters_writer("clusters/vfork.xml", vfork_clusters, max_clusters);

		vfork_tr_entries = vfork_transform_data(vfork_entries,file_size);
   		for (i=0; i< file_size; i++){
			vfork_cl = vfork_match_entry_to_cluster(vfork_clusters,max_clusters,vfork_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%x:%d",vfork_entries[i].pid,vfork_entries[i].retValue);
			printf("\nCluster : %s \n",vfork_cl.syscall);
			filename = (char *) malloc(14 + strlen(vfork_cl.syscall)+1);
			strncpy(filename,"results/vfork/",14);
			sprintf(filename+14,"%s\0",vfork_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%x,%d\n",vfork_entries[i].pid,vfork_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++)
			free(vfork_entries[i].syscall);
		free(vfork_entries);

		for(i=0; i<max_clusters; i++){
			free(vfork_clusters[i].syscall);
			free_integer(vfork_clusters[i].pids);
			free_integer(vfork_clusters[i].retValues);
			free_integer(vfork_clusters[i].ruids);
			free_integer(vfork_clusters[i].rgids);
			free_integer(vfork_clusters[i].euids);
			free_integer(vfork_clusters[i].egids);
		}
		free(vfork_clusters);

		for(i=0; i<file_size; i++)
			free(vfork_tr_entries[i].syscall);
		free(vfork_tr_entries);

	 }

	else if (strcmp(token,"CHOWN") == 0){
		printf ("Chown !");
		chown_entries = chown_load_file(training_file, &file_size);
		printf("###### %s ########\n",chown_entries[0].path);
	    chown_clusters = chown_cluster(chown_entries, file_size, &max_clusters);
		// Serialize
		chown_clusters_writer("clusters/chown.xml", chown_clusters, max_clusters);

		chown_tr_entries = chown_transform_data(chown_entries,file_size);
   		for (i=0; i< file_size; i++){
			chown_cl = chown_match_entry_to_cluster(chown_clusters,max_clusters,chown_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d:%d",chown_entries[i].path, chown_entries[i].owner, chown_entries[i].group, chown_entries[i].retValue);
			printf("\nCluster : %s \n",chown_cl.syscall);
			filename = (char *) malloc(14 + strlen(chown_cl.syscall)+1);
			strncpy(filename,"results/chown/",14);
			sprintf(filename+14,"%s\0",chown_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d,%d\n",chown_entries[i].path, chown_entries[i].owner, chown_entries[i].group, chown_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(chown_entries[i].syscall);
			free(chown_entries[i].path);
		}
		free(chown_entries);

		for(i=0; i<max_clusters; i++){
			free(chown_clusters[i].syscall);
			free_string(chown_clusters[i].filenames);
			free_string(chown_clusters[i].paths);
			free_integer(chown_clusters[i].owners);
			free_integer(chown_clusters[i].groups);
			free_integer(chown_clusters[i].retValues);
			free_integer(chown_clusters[i].filemodes);
			free_integer(chown_clusters[i].file_owner_ids);
			free_integer(chown_clusters[i].file_group_ids);
			free_integer(chown_clusters[i].ruids);
			free_integer(chown_clusters[i].rgids);
			free_integer(chown_clusters[i].euids);
			free_integer(chown_clusters[i].egids);
		}
		free(chown_clusters);

		for(i=0; i<file_size; i++){
			free(chown_tr_entries[i].syscall);
			free(chown_tr_entries[i].path);
			free(chown_tr_entries[i].filename);
		}
		free(chown_tr_entries);

	 }

	else if (strcmp(token,"CHROOT") == 0){
		printf ("Chroot !");
		chroot_entries = chroot_load_file(training_file, &file_size);
		printf("###### %s ########\n",chroot_entries[0].path);
	    chroot_clusters = chroot_cluster(chroot_entries, file_size, &max_clusters);
		// Serialize
		chroot_clusters_writer("clusters/chroot.xml", chroot_clusters, max_clusters);

		chroot_tr_entries = chroot_transform_data(chroot_entries,file_size);
   		for (i=0; i< file_size; i++){
			chroot_cl = chroot_match_entry_to_cluster(chroot_clusters,max_clusters,chroot_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",chroot_entries[i].path,chroot_entries[i].retValue);
			printf("\nCluster : %s \n",chroot_cl.syscall);
			filename = (char *) malloc(15 + strlen(chroot_cl.syscall)+1);
			strncpy(filename,"results/chroot/",15);
			sprintf(filename+15,"%s\0",chroot_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",chroot_entries[i].path,chroot_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(chroot_entries[i].syscall);
			free(chroot_entries[i].path);
		}
		free(chroot_entries);

		for(i=0; i<max_clusters; i++){
			free(chroot_clusters[i].syscall);
			free_integer(chroot_clusters[i].retValues);
			free_string(chroot_clusters[i].filenames);
			free_string(chroot_clusters[i].paths);
			free_integer(chroot_clusters[i].filemodes);
			free_integer(chroot_clusters[i].file_owner_ids);
			free_integer(chroot_clusters[i].file_group_ids);
			free_integer(chroot_clusters[i].ruids);
			free_integer(chroot_clusters[i].rgids);
			free_integer(chroot_clusters[i].euids);
			free_integer(chroot_clusters[i].egids);
		}
		free(chroot_clusters);

		for(i=0; i<file_size; i++){
			free(chroot_tr_entries[i].syscall);
			free(chroot_tr_entries[i].path);
			free(chroot_tr_entries[i].filename);
		}
		free(chroot_tr_entries);

	 }

	else if (strcmp(token,"FCHOWN") == 0){
		printf ("Fchown !");
		fchown_entries = fchown_load_file(training_file, &file_size);
		printf("###### %s ########\n",fchown_entries[0].path);
	    fchown_clusters = fchown_cluster(fchown_entries, file_size, &max_clusters);
		// Serialize
		fchown_clusters_writer("clusters/fchown.xml", fchown_clusters, max_clusters);

		fchown_tr_entries = fchown_transform_data(fchown_entries,file_size);
   		for (i=0; i< file_size; i++){
			fchown_cl = fchown_match_entry_to_cluster(fchown_clusters,max_clusters,fchown_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d:%d:%d",fchown_entries[i].path, fchown_entries[i].owner, fchown_entries[i].group, fchown_entries[i].retValue);
			printf("\nCluster : %s \n",fchown_cl.syscall);
			filename = (char *) malloc(15 + strlen(fchown_cl.syscall)+1);
			strncpy(filename,"results/fchown/",15);
			sprintf(filename+15,"%s\0",fchown_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d,%d,%d\n",fchown_entries[i].path, fchown_entries[i].owner, fchown_entries[i].group, fchown_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}

		// Free resources
		for(i=0; i<file_size; i++){
			free(fchown_entries[i].syscall);
			free(fchown_entries[i].path);
		}
		free(fchown_entries);

		for(i=0; i<max_clusters; i++){
			free(fchown_clusters[i].syscall);
			free_integer(fchown_clusters[i].retValues);
			free_integer(fchown_clusters[i].owners);
			free_integer(fchown_clusters[i].groups);
			free_string(fchown_clusters[i].filenames);
			free_string(fchown_clusters[i].paths);
			free_integer(fchown_clusters[i].filemodes);
			free_integer(fchown_clusters[i].file_owner_ids);
			free_integer(fchown_clusters[i].file_group_ids);
			free_integer(fchown_clusters[i].ruids);
			free_integer(fchown_clusters[i].rgids);
			free_integer(fchown_clusters[i].euids);
			free_integer(fchown_clusters[i].egids);
		}
		free(fchown_clusters);

		for(i=0; i<file_size; i++){
			free(fchown_tr_entries[i].syscall);
			free(fchown_tr_entries[i].path);
			free(fchown_tr_entries[i].filename);
		}
		free(fchown_tr_entries);

	 }
	 else if (strcmp(token,"EXECVE") == 0){
   		execve_entries = execve_load_file(training_file, &file_size);
		for(i=0;i<file_size;i++){
			printf("Syscall : %s\n",execve_entries[i].syscall);
			printf("Path : %s\n",execve_entries[i].path);
			printf("Nbr args : %d\n",execve_entries[i].nbr_args);
			printf("Args : \n");
			for(j=0; j<execve_entries[i].nbr_args; j++)
				printf("\t%s\n",execve_entries[i].args[j]);
			printf("Filemode : %d\n",execve_entries[i].filemode);
			printf("File owner id : %d\n",execve_entries[i].file_owner_id);
			printf("File group id : %d\n",execve_entries[i].file_group_id);
			printf("Ruid : %d\n",execve_entries[i].ruid);
			printf("Rgid : %d\n",execve_entries[i].rgid);
			printf("Euid : %d\n",execve_entries[i].euid);
			printf("Egid : %d\n",execve_entries[i].egid);
		}
		printf("###### %s ########\n",execve_entries[0].path);
	    execve_clusters = execve_cluster(execve_entries, file_size, &max_clusters);
		// Serialize
		execve_clusters_writer("clusters/execve.xml", execve_clusters, max_clusters);
		execve_tr_entries = execve_transform_data(execve_entries,file_size);
   		for (i=0; i< file_size; i++){
			execve_cl = execve_match_entry_to_cluster(execve_clusters,max_clusters,execve_tr_entries[i]);
			printf("\nMatch for : \n");
			printf("\t%s:%d",execve_entries[i].path,execve_entries[i].retValue);
			printf("\nCluster : %s \n",execve_cl.syscall);
			filename = (char *) malloc(13 + strlen(execve_cl.syscall)+1);
			strncpy(filename,"results/execve/",13);
			sprintf(filename+13,"%s\0",execve_cl.syscall);
			outfile = fopen(filename,"a");
			if(outfile != NULL){
				fprintf(outfile,"%s,%d\n",execve_entries[i].path,execve_entries[i].retValue);
				fclose(outfile);
			}
			free(filename);
			printf("##########################################\n");
		}
		
		// Free resources
		for(i=0; i<file_size; i++){
			free(execve_entries[i].syscall);
			free(execve_entries[i].path);
			for(j=0; j<execve_entries[i].nbr_args; j++)
				free(execve_entries[i].args[j]);
		}
		free(execve_entries);
		
		for(i=0; i<max_clusters; i++){
			free(execve_clusters[i].syscall);
			free_string(execve_clusters[i].args);
			free_integer(execve_clusters[i].nbr_args);
			free_string(execve_clusters[i].filenames);
			free_string(execve_clusters[i].paths);
			free_integer(execve_clusters[i].retValues);
			free_integer(execve_clusters[i].filemodes);
			free_integer(execve_clusters[i].file_owner_ids);
			free_integer(execve_clusters[i].file_group_ids);
			free_integer(execve_clusters[i].euids);
			free_integer(execve_clusters[i].egids);
			free_integer(execve_clusters[i].ruids);
			free_integer(execve_clusters[i].rgids);
		}
		free(execve_clusters);

		for(i=0; i<file_size; i++){
			free(execve_tr_entries[i].syscall);
			free(execve_tr_entries[i].path);
			free(execve_tr_entries[i].filename);
			for(j=0; j<execve_tr_entries[i].nbr_args; j++)
				free(execve_tr_entries[i].args[j]);
		}
		free(execve_tr_entries);
	 }


	return 0;
}


int matching(char * matching_file){

	struct open_cluster * open_clusters;
	struct open_entry * open_entries;
	struct open_transformed_entry * open_tr_entries;
	struct open_cluster open_matched_cluster;
	int open_clusters_number;

	struct close_cluster * close_clusters;
	struct close_entry * close_entries;
	struct close_transformed_entry * close_tr_entries;
	struct close_cluster close_matched_cluster;
	int close_clusters_number;

	struct mmap_cluster * mmap_clusters;
	struct mmap_entry * mmap_entries;
	struct mmap_transformed_entry * mmap_tr_entries;
	struct mmap_cluster mmap_matched_cluster;
	int mmap_clusters_number;

	struct stat_cluster * stat_clusters;
	struct stat_entry * stat_entries;
	struct stat_transformed_entry * stat_tr_entries;
	struct stat_cluster stat_matched_cluster;
	int stat_clusters_number;

	struct access_cluster * access_clusters;
	struct access_entry * access_entries;
	struct access_transformed_entry * access_tr_entries;
	struct access_cluster access_matched_cluster;
	int access_clusters_number;

	struct munmap_cluster * munmap_clusters;
	struct munmap_entry * munmap_entries;
	struct munmap_transformed_entry * munmap_tr_entries;
	struct munmap_cluster munmap_matched_cluster;
	int munmap_clusters_number;

	struct putmsg_cluster * putmsg_clusters;
	struct putmsg_entry * putmsg_entries;
	struct putmsg_transformed_entry * putmsg_tr_entries;
	struct putmsg_cluster putmsg_matched_cluster;
	int putmsg_clusters_number;

	struct sysinfo_cluster * sysinfo_clusters;
	struct sysinfo_entry * sysinfo_entries;
	struct sysinfo_transformed_entry * sysinfo_tr_entries;
	struct sysinfo_cluster sysinfo_matched_cluster;
	int sysinfo_clusters_number;

	struct chdir_cluster * chdir_clusters;
	struct chdir_entry * chdir_entries;
	struct chdir_transformed_entry * chdir_tr_entries;
	struct chdir_cluster chdir_matched_cluster;
	int chdir_clusters_number;

	struct readlink_cluster * readlink_clusters;
	struct readlink_entry * readlink_entries;
	struct readlink_transformed_entry * readlink_tr_entries;
	struct readlink_cluster readlink_matched_cluster;
	int readlink_clusters_number;

	struct unlink_cluster * unlink_clusters;
	struct unlink_entry * unlink_entries;
	struct unlink_transformed_entry * unlink_tr_entries;
	struct unlink_cluster unlink_matched_cluster;
	int unlink_clusters_number;

	struct creat_cluster * creat_clusters;
	struct creat_entry * creat_entries;
	struct creat_transformed_entry * creat_tr_entries;
	struct creat_cluster creat_matched_cluster;
	int creat_clusters_number;

	struct lstat_cluster * lstat_clusters;
	struct lstat_entry * lstat_entries;
	struct lstat_transformed_entry * lstat_tr_entries;
	struct lstat_cluster lstat_matched_cluster;
	int lstat_clusters_number;

	struct seteuid_cluster * seteuid_clusters;
	struct seteuid_entry * seteuid_entries;
	struct seteuid_transformed_entry * seteuid_tr_entries;
	struct seteuid_cluster seteuid_matched_cluster;
	int seteuid_clusters_number;

	struct setgid_cluster * setgid_clusters;
	struct setgid_entry * setgid_entries;
	struct setgid_transformed_entry * setgid_tr_entries;
	struct setgid_cluster setgid_matched_cluster;
	int setgid_clusters_number;

	struct setgroups_cluster * setgroups_clusters;
	struct setgroups_entry * setgroups_entries;
	struct setgroups_transformed_entry * setgroups_tr_entries;
	struct setgroups_cluster setgroups_matched_cluster;
	int setgroups_clusters_number;

	struct setegid_cluster * setegid_clusters;
	struct setegid_entry * setegid_entries;
	struct setegid_transformed_entry * setegid_tr_entries;
	struct setegid_cluster setegid_matched_cluster;
	int setegid_clusters_number;

	struct rename_cluster * rename_clusters;
	struct rename_entry * rename_entries;
	struct rename_transformed_entry * rename_tr_entries;
	struct rename_cluster rename_matched_cluster;
	int rename_clusters_number;

	struct ioctl_cluster * ioctl_clusters;
	struct ioctl_entry * ioctl_entries;
	struct ioctl_transformed_entry * ioctl_tr_entries;
	struct ioctl_cluster ioctl_matched_cluster;
	int ioctl_clusters_number;

	struct fcntl_cluster * fcntl_clusters;
	struct fcntl_entry * fcntl_entries;
	struct fcntl_transformed_entry * fcntl_tr_entries;
	struct fcntl_cluster fcntl_matched_cluster;
	int fcntl_clusters_number;

	struct getmsg_cluster * getmsg_clusters;
	struct getmsg_entry * getmsg_entries;
	struct getmsg_transformed_entry * getmsg_tr_entries;
	struct getmsg_cluster getmsg_matched_cluster;
	int getmsg_clusters_number;

	struct setuid_cluster * setuid_clusters;
	struct setuid_entry * setuid_entries;
	struct setuid_transformed_entry * setuid_tr_entries;
	struct setuid_cluster setuid_matched_cluster;
	int setuid_clusters_number;

	struct vfork_cluster * vfork_clusters;
	struct vfork_entry * vfork_entries;
	struct vfork_transformed_entry * vfork_tr_entries;
	struct vfork_cluster vfork_matched_cluster;
	int vfork_clusters_number;

	struct chown_cluster * chown_clusters;
	struct chown_entry * chown_entries;
	struct chown_transformed_entry * chown_tr_entries;
	struct chown_cluster chown_matched_cluster;
	int chown_clusters_number;

	struct chroot_cluster * chroot_clusters;
	struct chroot_entry * chroot_entries;
	struct chroot_transformed_entry * chroot_tr_entries;
	struct chroot_cluster chroot_matched_cluster;
	int chroot_clusters_number;

	struct fchown_cluster * fchown_clusters;
	struct fchown_entry * fchown_entries;
	struct fchown_transformed_entry * fchown_tr_entries;
	struct fchown_cluster fchown_matched_cluster;
	int fchown_clusters_number;

	struct sockconnect_cluster * sockconnect_clusters;
	struct sockconnect_entry * sockconnect_entries;
	struct sockconnect_transformed_entry * sockconnect_tr_entries;
	struct sockconnect_cluster sockconnect_matched_cluster;
	int sockconnect_clusters_number;

	struct execve_cluster * execve_clusters;
	struct execve_entry * execve_entries;
	struct execve_transformed_entry * execve_tr_entries;
	struct execve_cluster execve_matched_cluster;
	int execve_clusters_number;

	int i,j,k, size;
	FILE * infile, *outfile, *tmpfile;
	char line[400], tmpline[400];
	char * token, * tmpfilename, * outfilename;

	printf("Loading clusters ! \n");	

	open_clusters = open_clusters_parser("clusters/open.xml", &open_clusters_number);
	close_clusters = close_clusters_parser("clusters/close.xml", &close_clusters_number);
	mmap_clusters = mmap_clusters_parser("clusters/mmap.xml", &mmap_clusters_number);
	stat_clusters = stat_clusters_parser("clusters/stat.xml", &stat_clusters_number);
	access_clusters = access_clusters_parser("clusters/access.xml", &access_clusters_number);
	munmap_clusters = munmap_clusters_parser("clusters/munmap.xml", &munmap_clusters_number);
	putmsg_clusters = putmsg_clusters_parser("clusters/putmsg.xml", &putmsg_clusters_number);
	sysinfo_clusters = sysinfo_clusters_parser("clusters/sysinfo.xml", &sysinfo_clusters_number);
	chdir_clusters = chdir_clusters_parser("clusters/chdir.xml", &chdir_clusters_number);
	readlink_clusters = readlink_clusters_parser("clusters/readlink.xml", &readlink_clusters_number);
	unlink_clusters = unlink_clusters_parser("clusters/unlink.xml", &unlink_clusters_number);
	creat_clusters = creat_clusters_parser("clusters/creat.xml", &creat_clusters_number);
	lstat_clusters = lstat_clusters_parser("clusters/lstat.xml", &lstat_clusters_number);
	seteuid_clusters = seteuid_clusters_parser("clusters/seteuid.xml", &seteuid_clusters_number);
	setgid_clusters = setgid_clusters_parser("clusters/setgid.xml", &setgid_clusters_number);
	setgroups_clusters = setgroups_clusters_parser("clusters/setgroups.xml", &setgroups_clusters_number);
	setegid_clusters = setegid_clusters_parser("clusters/setegid.xml", &setegid_clusters_number);
	rename_clusters = rename_clusters_parser("clusters/rename.xml", &rename_clusters_number);
	ioctl_clusters = ioctl_clusters_parser("clusters/ioctl.xml", &ioctl_clusters_number);
	fcntl_clusters = fcntl_clusters_parser("clusters/fcntl.xml", &fcntl_clusters_number);
	getmsg_clusters = getmsg_clusters_parser("clusters/getmsg.xml", &getmsg_clusters_number);
	setuid_clusters = setuid_clusters_parser("clusters/setuid.xml", &setuid_clusters_number);
	vfork_clusters = vfork_clusters_parser("clusters/vfork.xml", &vfork_clusters_number);
	chown_clusters = chown_clusters_parser("clusters/chown.xml", &chown_clusters_number);
	chroot_clusters = chroot_clusters_parser("clusters/chroot.xml", &chroot_clusters_number);
	fchown_clusters = fchown_clusters_parser("clusters/fchown.xml", &fchown_clusters_number);
	sockconnect_clusters = sockconnect_clusters_parser("clusters/sockconnect.xml", &sockconnect_clusters_number);
	execve_clusters = execve_clusters_parser("clusters/execve.xml", &execve_clusters_number);

	infile = fopen(matching_file, "r");
	if (infile == NULL){
		printf("Could not open the file !\n");
		return -1;
	}

	outfilename = (char *) malloc(strlen(matching_file) + 12);
	sprintf(outfilename,"%s%s%s","output/",matching_file,".out\0");
/**
	strncpy(outfilename, matching_file, strlen(matching_file)+1);
	outfilename = strncat(outfilename,".out\0",5);
**/
	printf("Output file : %s\n", outfilename);

	if (NULL == (outfile = fopen(outfilename, "w"))){
		printf("Could not open output file !\n");
		return;
	}

	while(fgets(line,400,infile) != NULL){
		printf("Line read : %s\n", line);
		strncpy(tmpline,line,strlen(line));
		tmpline[strlen(line)] = '\0';
		token = strtok(tmpline,",");
		printf("%s",token);
		if (strcmp(token,"OPEN") == 0){
			printf("open");
			if(open_clusters == NULL){
				fprintf(outfile,"OPEN \n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			printf("Temp filename : %s\n", tmpfilename);
			tmpfile = fopen(tmpfilename, "w");
			printf("Writing : %s\n",line);
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			open_entries = open_load_file(tmpfilename, &size);
			open_tr_entries = open_transform_data(open_entries,size);
			open_matched_cluster = open_match_entry_to_cluster(open_clusters, open_clusters_number, open_tr_entries[0]);
			fprintf(outfile,"%s\n",open_matched_cluster.syscall);
			for(j=0; j<size; j++){
				free(open_entries[j].syscall);
				free(open_entries[j].path);
				free(open_entries[j].flags);
			}
			free(open_entries);

			for(j=0; j<size; j++){
				free(open_tr_entries[j].syscall);
				free(open_tr_entries[j].path);
				free(open_tr_entries[j].filename);
				free(open_tr_entries[j].flags);
			}
			free(open_tr_entries);
		}
		else if (strcmp(token,"CLOSE") == 0){
			printf("Close !\n");
			if(close_clusters == NULL){
				fprintf(outfile,"CLOSE\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			close_entries = close_load_file(tmpfilename, &size);
			close_tr_entries = close_transform_data(close_entries,size);
			close_matched_cluster = close_match_entry_to_cluster(close_clusters, close_clusters_number, close_tr_entries[0]);
			fprintf(outfile,"%s\n", close_matched_cluster.syscall);

			for(j=0; j<size; j++){
				free(close_entries[i].syscall);
				free(close_entries[i].path);
			}
			free(close_entries);
	
			for(j=0; j<size; j++){
				free(close_tr_entries[i].syscall);
				free(close_tr_entries[i].path);
				free(close_tr_entries[i].filename);
			}
			free(close_tr_entries);
		}
		else if (strcmp(token,"MMAP") == 0){
			if(mmap_clusters == NULL){
				fprintf(outfile,"MMAP\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			mmap_entries = mmap_load_file(tmpfilename, &size);
			mmap_tr_entries = mmap_transform_data(mmap_entries,size);
			mmap_matched_cluster = mmap_match_entry_to_cluster(mmap_clusters, mmap_clusters_number, mmap_tr_entries[0]);
			fprintf(outfile,"%s\n", mmap_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(mmap_entries[i].syscall);
				free(mmap_entries[i].path);
			}
			free(mmap_entries);

			for(i=0; i<size; i++){
				free(mmap_tr_entries[i].syscall);
				free(mmap_tr_entries[i].path);
				free(mmap_tr_entries[i].filename);
			}
			free(mmap_tr_entries);

		}else if (strcmp(token,"STAT") == 0){
			if(stat_clusters == NULL){
				fprintf(outfile,"STAT\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			stat_entries = stat_load_file(tmpfilename, &size);
			stat_tr_entries = stat_transform_data(stat_entries,size);
			stat_matched_cluster = stat_match_entry_to_cluster(stat_clusters, stat_clusters_number, stat_tr_entries[0]);
			fprintf(outfile,"%s\n", stat_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(stat_entries[i].syscall);
				free(stat_entries[i].path);
			}
			free(stat_entries);

			for(i=0; i<size; i++){
				free(stat_tr_entries[i].syscall);
				free(stat_tr_entries[i].path);
				free(stat_tr_entries[i].filename);
			}
			free(stat_tr_entries);
		}
		else if (strcmp(token,"ACCESS") == 0){
			if(access_clusters == NULL){
				fprintf(outfile,"ACCESS\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			access_entries = access_load_file(tmpfilename, &size);
			access_tr_entries = access_transform_data(access_entries,size);
			access_matched_cluster = access_match_entry_to_cluster(access_clusters, access_clusters_number, access_tr_entries[0]);
			fprintf(outfile,"%s\n", access_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(access_entries[i].syscall);
				free(access_entries[i].path);
			}
			free(access_entries);
	
			for(i=0; i<size; i++){
				free(access_tr_entries[i].syscall);
				free(access_tr_entries[i].path);
				free(access_tr_entries[i].filename);
			}
			free(access_tr_entries);
		}

		else if (strcmp(token,"MUNMAP") == 0){
			if(munmap_clusters == NULL){
				fprintf(outfile,"MUNMAP\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			munmap_entries = munmap_load_file(tmpfilename, &size);
			munmap_tr_entries = munmap_transform_data(munmap_entries,size);
			munmap_matched_cluster = munmap_match_entry_to_cluster(munmap_clusters, munmap_clusters_number, munmap_tr_entries[0]);
			fprintf(outfile,"%s\n", munmap_matched_cluster.syscall);

			for(i=0; i<size; i++)
				free(munmap_entries[i].syscall);
			free(munmap_entries);

			for(i=0; i<size; i++)
				free(munmap_tr_entries[i].syscall);
			free(munmap_tr_entries);

		}
		else if (strcmp(token,"PUTMSG") == 0){
			if(putmsg_clusters == NULL){
				fprintf(outfile,"PUTMSG\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			putmsg_entries = putmsg_load_file(tmpfilename, &size);
			putmsg_tr_entries = putmsg_transform_data(putmsg_entries,size);
			putmsg_matched_cluster = putmsg_match_entry_to_cluster(putmsg_clusters, putmsg_clusters_number, putmsg_tr_entries[0]);
			fprintf(outfile,"%s\n", putmsg_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(putmsg_entries[i].syscall);
			free(putmsg_entries);
	
			for(i=0; i<size; i++)
				free(putmsg_tr_entries[i].syscall);
			free(putmsg_tr_entries);

		}
		else if (strcmp(token,"SYSINFO") == 0){
			if(sysinfo_clusters == NULL){
				fprintf(outfile,"SYSINFO\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			sysinfo_entries = sysinfo_load_file(tmpfilename, &size);
			sysinfo_tr_entries = sysinfo_transform_data(sysinfo_entries,size);
			sysinfo_matched_cluster = sysinfo_match_entry_to_cluster(sysinfo_clusters, sysinfo_clusters_number, sysinfo_tr_entries[0]);
			fprintf(outfile,"%s\n", sysinfo_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(sysinfo_entries[i].syscall);
			free(sysinfo_entries);
			
			for(i=0; i<size; i++)
				free(sysinfo_tr_entries[i].syscall);
			free(sysinfo_tr_entries);
		}
		else if (strcmp(token,"CHDIR") == 0){
			if(chdir_clusters == NULL){
				fprintf(outfile,"CHDIR \n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			chdir_entries = chdir_load_file(tmpfilename, &size);
			chdir_tr_entries = chdir_transform_data(chdir_entries,size);
			chdir_matched_cluster = chdir_match_entry_to_cluster(chdir_clusters, chdir_clusters_number, chdir_tr_entries[0]);
			fprintf(outfile,"%s\n", chdir_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(chdir_entries[i].syscall);
				free(chdir_entries[i].path);
			}
			free(chdir_entries);

			for(i=0; i<size; i++){
				free(chdir_tr_entries[i].syscall);
				free(chdir_tr_entries[i].path);
				free(chdir_tr_entries[i].filename);
			}
			free(chdir_tr_entries);
		}
		else if (strcmp(token,"READLINK") == 0){
			if(readlink_clusters == NULL){
				fprintf(outfile,"READLINK\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			readlink_entries = readlink_load_file(tmpfilename, &size);
			readlink_tr_entries = readlink_transform_data(readlink_entries,size);
			readlink_matched_cluster = readlink_match_entry_to_cluster(readlink_clusters, readlink_clusters_number, readlink_tr_entries[0]);
			fprintf(outfile,"%s\n", readlink_matched_cluster.syscall);

			for(i=0; i<size; i++){
				free(readlink_entries[i].syscall);
				free(readlink_entries[i].path);
			}
			free(readlink_entries);

			for(i=0; i<size; i++){
				free(readlink_tr_entries[i].syscall);
				free(readlink_tr_entries[i].filename);
			}
			free(readlink_tr_entries);
		}
		else if (strcmp(token,"UNLINK") == 0){
			if(unlink_clusters == NULL){
				fprintf(outfile,"UNLINK\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			unlink_entries = unlink_load_file(tmpfilename, &size);
			unlink_tr_entries = unlink_transform_data(unlink_entries,size);
			unlink_matched_cluster = unlink_match_entry_to_cluster(unlink_clusters, unlink_clusters_number, unlink_tr_entries[0]);
			fprintf(outfile,"%s\n", unlink_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(unlink_entries[i].syscall);
				free(unlink_entries[i].path);
			}
			free(unlink_entries);

			for(i=0; i<size; i++){
				free(unlink_tr_entries[i].syscall);
				free(unlink_tr_entries[i].path);
				free(unlink_tr_entries[i].filename);
			}
			free(unlink_tr_entries);
		}
		else if (strcmp(token,"CREAT") == 0){
			if(creat_clusters == NULL){
				fprintf(outfile,"CREAT\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			creat_entries = creat_load_file(tmpfilename, &size);
			creat_tr_entries = creat_transform_data(creat_entries,size);
			creat_matched_cluster = creat_match_entry_to_cluster(creat_clusters, creat_clusters_number, creat_tr_entries[0]);
			fprintf(outfile,"%s\n", creat_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(creat_entries[i].syscall);
				free(creat_entries[i].path);
			}
			free(creat_entries);
	
			for(i=0; i<size; i++){
				free(creat_tr_entries[i].syscall);
				free(creat_tr_entries[i].path);
				free(creat_tr_entries[i].filename);
			}
			free(creat_tr_entries);
		}
		else if (strcmp(token,"LSTAT") == 0){
			if(lstat_clusters == NULL){
				fprintf(outfile,"LSTAT\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			lstat_entries = lstat_load_file(tmpfilename, &size);
			lstat_tr_entries = lstat_transform_data(lstat_entries,size);
			lstat_matched_cluster = lstat_match_entry_to_cluster(lstat_clusters, lstat_clusters_number, lstat_tr_entries[0]);
			fprintf(outfile,"%s\n", lstat_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(lstat_entries[i].syscall);
				free(lstat_entries[i].path);
			}
			free(lstat_entries);

			for(i=0; i<size; i++){
				free(lstat_tr_entries[i].syscall);
				free(lstat_tr_entries[i].path);
				free(lstat_tr_entries[i].filename);
			}
		free(lstat_tr_entries);
		}
		else if (strcmp(token,"SETEUID") == 0){
			if(seteuid_clusters == NULL){
				fprintf(outfile,"SETEUID \n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			seteuid_entries = seteuid_load_file(tmpfilename, &size);
			seteuid_tr_entries = seteuid_transform_data(seteuid_entries,size);
			seteuid_matched_cluster = seteuid_match_entry_to_cluster(seteuid_clusters, seteuid_clusters_number, seteuid_tr_entries[0]);
			fprintf(outfile,"%s\n", seteuid_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(seteuid_entries[i].syscall);
			free(seteuid_entries);

			for(i=0; i<size; i++)
				free(seteuid_tr_entries[i].syscall);
			free(seteuid_tr_entries);
		}
		else if (strcmp(token,"SETGID") == 0){
			if(setgid_clusters == NULL){
				fprintf(outfile,"SETGID\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			setgid_entries = setgid_load_file(tmpfilename, &size);
			setgid_tr_entries = setgid_transform_data(setgid_entries,size);
			setgid_matched_cluster = setgid_match_entry_to_cluster(setgid_clusters, setgid_clusters_number, setgid_tr_entries[0]);
			fprintf(outfile,"%s\n", setgid_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(setgid_entries[i].syscall);
			free(setgid_entries);
			
			for(i=0; i<size; i++)
				free(setgid_tr_entries[i].syscall);
			free(setgid_tr_entries);
		}
		else if (strcmp(token,"SETGROUPS") == 0){
			if(setgroups_clusters == NULL){
				fprintf(outfile,"SETGROUPS\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			setgroups_entries = setgroups_load_file(tmpfilename, &size);
			setgroups_tr_entries = setgroups_transform_data(setgroups_entries,size);
			setgroups_matched_cluster = setgroups_match_entry_to_cluster(setgroups_clusters, setgroups_clusters_number, setgroups_tr_entries[0]);
			fprintf(outfile,"%s\n", setgroups_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(setgroups_entries[i].syscall);
			free(setgroups_entries);
	
			for(i=0; i<size; i++)
				free(setgroups_tr_entries[i].syscall);
			free(setgroups_tr_entries);
		}else if (strcmp(token,"SETEGID") == 0){
			if(setegid_clusters == NULL){
				fprintf(outfile,"SETEGID\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			setegid_entries = setegid_load_file(tmpfilename, &size);
			setegid_tr_entries = setegid_transform_data(setegid_entries,size);
			setegid_matched_cluster = setegid_match_entry_to_cluster(setegid_clusters, setegid_clusters_number, setegid_tr_entries[0]);
			fprintf(outfile,"%s\n", setegid_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(setegid_entries[i].syscall);
			free(setegid_entries);

			for(i=0; i<size; i++)
				free(setegid_tr_entries[i].syscall);
			free(setegid_tr_entries);
		}else if (strcmp(token,"RENAME") == 0){
			if(rename_clusters == NULL){
				fprintf(outfile,"RENAME\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			rename_entries = rename_load_file(tmpfilename, &size);
			rename_tr_entries = rename_transform_data(rename_entries,size);
			rename_matched_cluster = rename_match_entry_to_cluster(rename_clusters, rename_clusters_number, rename_tr_entries[0]);
			fprintf(outfile,"%s\n", rename_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(rename_entries[i].syscall);
				free(rename_entries[i].path1);
				free(rename_entries[i].path2);
			}
			free(rename_entries);
	
			for(i=0; i<size; i++){
				free(rename_tr_entries[i].syscall);
				free(rename_tr_entries[i].path1);
				free(rename_tr_entries[i].path2);
				free(rename_tr_entries[i].filename1);
				free(rename_tr_entries[i].filename2);
			}
			free(rename_tr_entries);
		}else if (strcmp(token,"IOCTL") == 0){
			if(ioctl_clusters == NULL){
				fprintf(outfile,"IOCTL\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			ioctl_entries = ioctl_load_file(tmpfilename, &size);
			ioctl_tr_entries = ioctl_transform_data(ioctl_entries,size);
			ioctl_matched_cluster = ioctl_match_entry_to_cluster(ioctl_clusters, ioctl_clusters_number, ioctl_tr_entries[0]);
			fprintf(outfile,"%s\n", ioctl_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(ioctl_entries[i].syscall);
				free(ioctl_entries[i].path);
			}
			free(ioctl_entries);

			for(i=0; i<size; i++){
				free(ioctl_tr_entries[i].syscall);
				free(ioctl_tr_entries[i].path);
				free(ioctl_tr_entries[i].filename);
			}
			free(ioctl_tr_entries);
		}else if (strcmp(token,"FCNTL") == 0){
			if(fcntl_clusters == NULL){
				fprintf(outfile,"FCNTL\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			fcntl_entries = fcntl_load_file(tmpfilename, &size);
			fcntl_tr_entries = fcntl_transform_data(fcntl_entries,size);
			fcntl_matched_cluster = fcntl_match_entry_to_cluster(fcntl_clusters, fcntl_clusters_number, fcntl_tr_entries[0]);
			fprintf(outfile,"%s\n", fcntl_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(fcntl_entries[i].syscall);
				free(fcntl_entries[i].path);
			}
			free(fcntl_entries);

			for(i=0; i<size; i++){
				free(fcntl_tr_entries[i].syscall);
				free(fcntl_tr_entries[i].path);
				free(fcntl_tr_entries[i].filename);
			}
			free(fcntl_tr_entries);
		}else if (strcmp(token,"GETMSG") == 0){
			if(getmsg_clusters == NULL){
				fprintf(outfile,"GETMSG\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			getmsg_entries = getmsg_load_file(tmpfilename, &size);
			getmsg_tr_entries = getmsg_transform_data(getmsg_entries,size);
			getmsg_matched_cluster = getmsg_match_entry_to_cluster(getmsg_clusters, getmsg_clusters_number, getmsg_tr_entries[0]);
			fprintf(outfile,"%s\n", getmsg_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(getmsg_entries[i].syscall);
			free(getmsg_entries);

			for(i=0; i<size; i++)
				free(getmsg_tr_entries[i].syscall);
			free(getmsg_tr_entries);

		}else if (strcmp(token,"SETUID") == 0){
			if(setuid_clusters == NULL){
				fprintf(outfile,"SETUID\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			setuid_entries = setuid_load_file(tmpfilename, &size);
			setuid_tr_entries = setuid_transform_data(setuid_entries,size);
			setuid_matched_cluster = setuid_match_entry_to_cluster(setuid_clusters, setuid_clusters_number, setuid_tr_entries[0]);
			fprintf(outfile,"%s\n", setuid_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(setuid_entries[i].syscall);
			free(setuid_entries);

			for(i=0; i<size; i++)
				free(setuid_tr_entries[i].syscall);
			free(setuid_tr_entries);
		}else if (strcmp(token,"VFORK") == 0){
			if (vfork_clusters == NULL){
				fprintf(outfile,"VFORK\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			vfork_entries = vfork_load_file(tmpfilename, &size);
			vfork_tr_entries = vfork_transform_data(vfork_entries,size);
			vfork_matched_cluster = vfork_match_entry_to_cluster(vfork_clusters, vfork_clusters_number, vfork_tr_entries[0]);
			fprintf(outfile,"%s\n", vfork_matched_cluster.syscall);
			for(i=0; i<size; i++)
				free(vfork_entries[i].syscall);
			free(vfork_entries);

			for(i=0; i<size; i++)
				free(vfork_tr_entries[i].syscall);
			free(vfork_tr_entries);
		}else if (strcmp(token,"CHOWN") == 0){
			if(chown_clusters == NULL){
				fprintf(outfile,"CHOWN\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			chown_entries = chown_load_file(tmpfilename, &size);
			chown_tr_entries = chown_transform_data(chown_entries,size);
			chown_matched_cluster = chown_match_entry_to_cluster(chown_clusters, chown_clusters_number, chown_tr_entries[0]);
			fprintf(outfile,"%s\n", chown_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(chown_entries[i].syscall);
				free(chown_entries[i].path);
			}
			free(chown_entries);

			for(i=0; i<size; i++){
				free(chown_tr_entries[i].syscall);
				free(chown_tr_entries[i].path);
				free(chown_tr_entries[i].filename);
			}
			free(chown_tr_entries);

		}else if (strcmp(token,"CHROOT") == 0){
			if( chroot_clusters == NULL){
				fprintf(outfile,"CHROOT\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			chroot_entries = chroot_load_file(tmpfilename, &size);
			chroot_tr_entries = chroot_transform_data(chroot_entries,size);
			chroot_matched_cluster = chroot_match_entry_to_cluster(chroot_clusters, chroot_clusters_number, chroot_tr_entries[0]);
			fprintf(outfile,"%s\n", chroot_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(chroot_entries[i].syscall);
				free(chroot_entries[i].path);
			}
			free(chroot_entries);

			for(i=0; i<size; i++){
				free(chroot_tr_entries[i].syscall);
				free(chroot_tr_entries[i].path);
				free(chroot_tr_entries[i].filename);
			}
			free(chroot_tr_entries);
		}
		else if (strcmp(token,"FCHOWN") == 0){
			if( fchown_clusters == NULL){
				fprintf(outfile,"FCHOWN\n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			fchown_entries = fchown_load_file(tmpfilename, &size);
			fchown_tr_entries = fchown_transform_data(fchown_entries,size);
			fchown_matched_cluster = fchown_match_entry_to_cluster(fchown_clusters, fchown_clusters_number, fchown_tr_entries[0]);
			fprintf(outfile,"%s\n", fchown_matched_cluster.syscall);
			for(i=0; i<size; i++){
				free(fchown_entries[i].syscall);
				free(fchown_entries[i].path);
			}
			free(fchown_entries);

			for(i=0; i<size; i++){
				free(fchown_tr_entries[i].syscall);
				free(fchown_tr_entries[i].path);
				free(fchown_tr_entries[i].filename);
			}
			free(fchown_tr_entries);
		}
		else if (strcmp(token,"EXECVE") == 0){
			printf("execve");
			if(execve_clusters == NULL){
				fprintf(outfile,"EXECVE \n");
				continue;
			}
			tmpfilename = tmpnam(NULL);
			printf("Temp filename : %s\n", tmpfilename);
			tmpfile = fopen(tmpfilename, "w");
			printf("Writing : %s\n",line);
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not execve temporary file !\n");
				return;
			}
			fclose(tmpfile);
			execve_entries = execve_load_file(tmpfilename, &size);
			execve_tr_entries = execve_transform_data(execve_entries,size);
			execve_matched_cluster = execve_match_entry_to_cluster(execve_clusters, execve_clusters_number, execve_tr_entries[0]);
			fprintf(outfile,"%s\n",execve_matched_cluster.syscall);
			for(j=0; j<size; j++){
				free(execve_entries[j].syscall);
				free(execve_entries[j].path);
				for(k=0; k<execve_entries[j].nbr_args; k++)
					free(execve_entries[j].args[k]);
			}
			free(execve_entries);

			for(j=0; j<size; j++){
				free(execve_tr_entries[j].syscall);
				free(execve_tr_entries[j].path);
				free(execve_tr_entries[j].filename);
				for(k=0; k<execve_tr_entries[j].nbr_args; k++)
					free(execve_tr_entries[j].args[k]);
			}
			free(execve_tr_entries);
		}/**
		else if (strcmp(token,"SOCKCONNECT") == 0){
			tmpfilename = tmpnam(NULL);
			tmpfile = fopen(tmpfilename, "w");
			if (tmpfile != NULL)
				fwrite(line, strlen(line), 1, tmpfile);
			else{
				printf("Could not open temporary file !\n");
				return;
			}
			fclose(tmpfile);
			sockconnect_entries = sockconnect_load_file(tmpfilename, &size);
			sockconnect_tr_entries = sockconnect_transform_data(sockconnect_entries,size);
			sockconnect_matched_cluster = sockconnect_match_entry_to_cluster(sockconnect_clusters, sockconnect_clusters_number, sockconnect_tr_entries[0]);
			printf("Syscall : %s\n", sockconnect_matched_cluster.syscall);
		}**/
		else
			printf("Not yet implemented : %s \n",line);
	}

	fclose(outfile);

	if (open_clusters != NULL){
		for(i=0; i<open_clusters_number; i++){
				free(open_clusters[i].syscall);
				free_string(open_clusters[i].flags);
				free_string(open_clusters[i].filenames);
				free_string(open_clusters[i].paths);
				free_integer(open_clusters[i].retValues);
				free_integer(open_clusters[i].filemodes);
				free_integer(open_clusters[i].file_owner_ids);
				free_integer(open_clusters[i].file_group_ids);
				free_integer(open_clusters[i].euids);
				free_integer(open_clusters[i].egids);
				free_integer(open_clusters[i].ruids);
				free_integer(open_clusters[i].rgids);
			}
		free(open_clusters);
	}

	if(close_clusters != NULL){
		for(i=0; i<close_clusters_number; i++){
					free(close_clusters[i].syscall);
					free_string(close_clusters[i].filenames);
					free_string(close_clusters[i].paths);
					free_integer(close_clusters[i].filemodes);
					free_integer(close_clusters[i].file_owner_ids);
					free_integer(close_clusters[i].file_group_ids);
					free_integer(close_clusters[i].retValues);
					free_integer(close_clusters[i].euids);
					free_integer(close_clusters[i].egids);
					free_integer(close_clusters[i].ruids);
					free_integer(close_clusters[i].rgids);
				}
		free(close_clusters);
	}

	if(mmap_clusters != NULL){
		for(i=0; i<mmap_clusters_number; i++){
				free(mmap_clusters[i].syscall);
				free_string(mmap_clusters[i].filenames);
				free_string(mmap_clusters[i].paths);
				free_integer(mmap_clusters[i].retValues);
				free_integer(mmap_clusters[i].filemodes);
				free_integer(mmap_clusters[i].file_owner_ids);
				free_integer(mmap_clusters[i].file_group_ids);
				free_integer(mmap_clusters[i].ruids);
				free_integer(mmap_clusters[i].rgids);
				free_integer(mmap_clusters[i].euids);
				free_integer(mmap_clusters[i].egids);
			}
			free(mmap_clusters);
	}

	if(stat_clusters != NULL){
		for(i=0; i<stat_clusters_number; i++){
				free(stat_clusters[i].syscall);
				free_integer(stat_clusters[i].retValues);
				free_string(stat_clusters[i].filenames);
				free_string(stat_clusters[i].paths);
				free_integer(stat_clusters[i].filemodes);
				free_integer(stat_clusters[i].file_owner_ids);
				free_integer(stat_clusters[i].file_group_ids);
				free_integer(stat_clusters[i].ruids);
				free_integer(stat_clusters[i].rgids);
				free_integer(stat_clusters[i].euids);
				free_integer(stat_clusters[i].egids);
			}
			free(stat_clusters);
	}

	if(access_clusters != NULL){
		for(i=0; i<access_clusters_number; i++){
				free(access_clusters[i].syscall);
				free_string(access_clusters[i].filenames);
				free_string(access_clusters[i].paths);
				free_integer(access_clusters[i].retValues);
				free_integer(access_clusters[i].filemodes);
				free_integer(access_clusters[i].file_owner_ids);
				free_integer(access_clusters[i].file_group_ids);
				free_integer(access_clusters[i].ruids);
				free_integer(access_clusters[i].rgids);
				free_integer(access_clusters[i].euids);
				free_integer(access_clusters[i].egids);
			}
			free(access_clusters);
	}

	if(munmap_clusters != NULL){
			for(i=0; i<munmap_clusters_number; i++){
				free(munmap_clusters[i].syscall);
				free_integer(munmap_clusters[i].retValues);
				free_integer(munmap_clusters[i].addresses);
				free_integer(munmap_clusters[i].lengths);
				free_integer(munmap_clusters[i].euids);
				free_integer(munmap_clusters[i].egids);
				free_integer(munmap_clusters[i].ruids);
				free_integer(munmap_clusters[i].rgids);
			}
			free(munmap_clusters);
	}

	if(putmsg_clusters != NULL){
			for(i=0; i<putmsg_clusters_number; i++){
				free(putmsg_clusters[i].syscall);
				free_integer(putmsg_clusters[i].filedess);
				free_integer(putmsg_clusters[i].flags);
				free_integer(putmsg_clusters[i].retValues);
				free_integer(putmsg_clusters[i].ruids);
				free_integer(putmsg_clusters[i].rgids);
				free_integer(putmsg_clusters[i].euids);
				free_integer(putmsg_clusters[i].egids);
			}
			free(putmsg_clusters);
	}

	if(sysinfo_clusters != NULL){
		for(i=0; i<sysinfo_clusters_number; i++){
			free(sysinfo_clusters[i].syscall);
			free_integer(sysinfo_clusters[i].commands);
			free_integer(sysinfo_clusters[i].retValues);
			free_integer(sysinfo_clusters[i].ruids);
			free_integer(sysinfo_clusters[i].rgids);
			free_integer(sysinfo_clusters[i].euids);
			free_integer(sysinfo_clusters[i].egids);
		}
		free(sysinfo_clusters);
	}

	if(chdir_clusters != NULL){
		for(i=0; i<chdir_clusters_number; i++){
			free(chdir_clusters[i].syscall);
			free_string(chdir_clusters[i].filenames);
			free_string(chdir_clusters[i].paths);
			free_integer(chdir_clusters[i].filemodes);
			free_integer(chdir_clusters[i].file_owner_ids);
			free_integer(chdir_clusters[i].file_group_ids);
			free_integer(chdir_clusters[i].retValues);
			free_integer(chdir_clusters[i].ruids);
			free_integer(chdir_clusters[i].rgids);
			free_integer(chdir_clusters[i].euids);
			free_integer(chdir_clusters[i].egids);
		}
		free(chdir_clusters);
	}

	if(readlink_clusters != NULL){
		for(i=0; i<readlink_clusters_number; i++){
			free(readlink_clusters[i].syscall);
			free_string(readlink_clusters[i].filenames);
			free_string(readlink_clusters[i].paths);
			free_integer(readlink_clusters[i].filemodes);
			free_integer(readlink_clusters[i].file_owner_ids);
			free_integer(readlink_clusters[i].file_group_ids);
			free_integer(readlink_clusters[i].retValues);
			free_integer(readlink_clusters[i].ruids);
			free_integer(readlink_clusters[i].rgids);
			free_integer(readlink_clusters[i].euids);
			free_integer(readlink_clusters[i].egids);
		}
		free(readlink_clusters);
	}

	if(unlink_clusters != NULL){
		for(i=0; i<unlink_clusters_number; i++){
			free(unlink_clusters[i].syscall);
			free_integer(unlink_clusters[i].retValues);
			free_string(unlink_clusters[i].filenames);
			free_string(unlink_clusters[i].paths);
			free_integer(unlink_clusters[i].filemodes);
			free_integer(unlink_clusters[i].file_owner_ids);
			free_integer(unlink_clusters[i].file_group_ids);
			free_integer(unlink_clusters[i].ruids);
			free_integer(unlink_clusters[i].rgids);
			free_integer(unlink_clusters[i].euids);
			free_integer(unlink_clusters[i].egids);
		}
		free(unlink_clusters);
	}

	if(creat_clusters != NULL){
		for(i=0; i<creat_clusters_number; i++){
			free(creat_clusters[i].syscall);
			free_integer(creat_clusters[i].retValues);
			free_string(creat_clusters[i].filenames);
			free_string(creat_clusters[i].paths);
			free_integer(creat_clusters[i].filemodes);
			free_integer(creat_clusters[i].file_owner_ids);
			free_integer(creat_clusters[i].file_group_ids);
			free_integer(creat_clusters[i].ruids);
			free_integer(creat_clusters[i].rgids);
			free_integer(creat_clusters[i].euids);
			free_integer(creat_clusters[i].egids);
		}
		free(creat_clusters);
	}

	if(lstat_clusters != NULL){
		for(i=0; i<lstat_clusters_number; i++){
			free(lstat_clusters[i].syscall);
			free_integer(lstat_clusters[i].retValues);
			free_string(lstat_clusters[i].filenames);
			free_string(lstat_clusters[i].paths);
			free_integer(lstat_clusters[i].filemodes);
			free_integer(lstat_clusters[i].file_owner_ids);
			free_integer(lstat_clusters[i].file_group_ids);
			free_integer(lstat_clusters[i].ruids);
			free_integer(lstat_clusters[i].rgids);
			free_integer(lstat_clusters[i].euids);
			free_integer(lstat_clusters[i].egids);
		}
		free(lstat_clusters);
	}

	if(seteuid_clusters != NULL){
		for(i=0; i<seteuid_clusters_number; i++){
			free(seteuid_clusters[i].syscall);
			free_integer(seteuid_clusters[i].retValues);
			free_integer(seteuid_clusters[i].p_euids);
			free_integer(seteuid_clusters[i].ruids);
			free_integer(seteuid_clusters[i].rgids);
			free_integer(seteuid_clusters[i].euids);
			free_integer(seteuid_clusters[i].egids);
		}
		free(seteuid_clusters);
	}

	if(setgid_clusters != NULL){
		for(i=0; i<setgid_clusters_number; i++){
			free(setgid_clusters[i].syscall);
			free_integer(setgid_clusters[i].retValues);
			free_integer(setgid_clusters[i].gids);
			free_integer(setgid_clusters[i].euids);
			free_integer(setgid_clusters[i].egids);
			free_integer(setgid_clusters[i].ruids);
			free_integer(setgid_clusters[i].rgids);
		}
		free(setgid_clusters);
	}

	if(setgroups_clusters != NULL){
		for(i=0; i<setgroups_clusters_number; i++){
			free(setgroups_clusters[i].syscall);
			free_integer(setgroups_clusters[i].ngroupss);
			free_integer(setgroups_clusters[i].retValues);
			free_integer(setgroups_clusters[i].ruids);
			free_integer(setgroups_clusters[i].rgids);
			free_integer(setgroups_clusters[i].euids);
			free_integer(setgroups_clusters[i].egids);
		}
		free(setgroups_clusters);
	}

	if(setegid_clusters != NULL){
		for(i=0; i<setegid_clusters_number; i++){
			free(setegid_clusters[i].syscall);
			free_integer(setegid_clusters[i].p_egids);
			free_integer(setegid_clusters[i].retValues);
			free_integer(setegid_clusters[i].ruids);
			free_integer(setegid_clusters[i].rgids);
			free_integer(setegid_clusters[i].euids);
			free_integer(setegid_clusters[i].egids);
		}
		free(setegid_clusters);
	}

	if(rename_clusters != NULL){
		for(i=0; i<rename_clusters_number; i++){
			free(rename_clusters[i].syscall);
			free_integer(rename_clusters[i].retValues);
			free_string(rename_clusters[i].filenames1);
			free_string(rename_clusters[i].filenames2);
			free_string(rename_clusters[i].paths1);
			free_string(rename_clusters[i].paths2);
			free_integer(rename_clusters[i].filemodes1);
			free_integer(rename_clusters[i].filemodes2);
			free_integer(rename_clusters[i].file1_owner_ids);
			free_integer(rename_clusters[i].file1_group_ids);
			free_integer(rename_clusters[i].file2_owner_ids);
			free_integer(rename_clusters[i].file2_group_ids);
			free_integer(rename_clusters[i].ruids);
			free_integer(rename_clusters[i].rgids);
			free_integer(rename_clusters[i].euids);
			free_integer(rename_clusters[i].egids);
		}
		free(rename_clusters);
	}

	if(ioctl_clusters != NULL){
		for(i=0; i<ioctl_clusters_number; i++){
			free(ioctl_clusters[i].syscall);
			free_integer(ioctl_clusters[i].retValues);
			free_integer(ioctl_clusters[i].commands);
			free_integer(ioctl_clusters[i].args);
			free_string(ioctl_clusters[i].paths);
			free_string(ioctl_clusters[i].filenames);
			free_integer(ioctl_clusters[i].filemodes);
			free_integer(ioctl_clusters[i].file_owner_ids);
			free_integer(ioctl_clusters[i].file_group_ids);
			free_integer(ioctl_clusters[i].ruids);
			free_integer(ioctl_clusters[i].rgids);
			free_integer(ioctl_clusters[i].euids);
			free_integer(ioctl_clusters[i].egids);
		}
		free(ioctl_clusters);
	}


	if(fcntl_clusters != NULL){
		for(i=0; i<fcntl_clusters_number; i++){
			free(fcntl_clusters[i].syscall);
			free_integer(fcntl_clusters[i].commands);
			free_integer(fcntl_clusters[i].retValues);
			free_string(fcntl_clusters[i].filenames);
			free_string(fcntl_clusters[i].paths);
			free_integer(fcntl_clusters[i].filemodes);
			free_integer(fcntl_clusters[i].file_owner_ids);
			free_integer(fcntl_clusters[i].file_group_ids);
			free_integer(fcntl_clusters[i].ruids);
			free_integer(fcntl_clusters[i].rgids);
			free_integer(fcntl_clusters[i].euids);
			free_integer(fcntl_clusters[i].egids);
		}
		free(fcntl_clusters);
	}

	if(getmsg_clusters != NULL){		
		for(i=0; i<getmsg_clusters_number; i++){
			free(getmsg_clusters[i].syscall);
			free_integer(getmsg_clusters[i].filedess);
			free_integer(getmsg_clusters[i].flags);
			free_integer(getmsg_clusters[i].retValues);
			free_integer(getmsg_clusters[i].ruids);
			free_integer(getmsg_clusters[i].rgids);
			free_integer(getmsg_clusters[i].euids);
			free_integer(getmsg_clusters[i].egids);
		}
		free(getmsg_clusters);
	}	

	if(setuid_clusters != NULL){
		for(i=0; i<setuid_clusters_number; i++){
			free(setuid_clusters[i].syscall);
			free_integer(setuid_clusters[i].uids);
			free_integer(setuid_clusters[i].retValues);
			free_integer(setuid_clusters[i].ruids);
			free_integer(setuid_clusters[i].rgids);
			free_integer(setuid_clusters[i].euids);
			free_integer(setuid_clusters[i].egids);
		}
		free(setuid_clusters);
	}

	if(vfork_clusters != NULL){
		for(i=0; i<vfork_clusters_number; i++){
			free(vfork_clusters[i].syscall);
			free_integer(vfork_clusters[i].pids);
			free_integer(vfork_clusters[i].retValues);
			free_integer(vfork_clusters[i].ruids);
			free_integer(vfork_clusters[i].rgids);
			free_integer(vfork_clusters[i].euids);
			free_integer(vfork_clusters[i].egids);
		}
		free(vfork_clusters);
	}

	if(chown_clusters != NULL){
		for(i=0; i<chown_clusters_number; i++){
			free(chown_clusters[i].syscall);
			free_string(chown_clusters[i].filenames);
			free_string(chown_clusters[i].paths);
			free_integer(chown_clusters[i].owners);
			free_integer(chown_clusters[i].groups);
			free_integer(chown_clusters[i].retValues);
			free_integer(chown_clusters[i].filemodes);
			free_integer(chown_clusters[i].file_owner_ids);
			free_integer(chown_clusters[i].file_group_ids);
			free_integer(chown_clusters[i].ruids);
			free_integer(chown_clusters[i].rgids);
			free_integer(chown_clusters[i].euids);
			free_integer(chown_clusters[i].egids);
		}
		free(chown_clusters);
	}

	if(chroot_clusters != NULL){
		for(i=0; i<chroot_clusters_number; i++){
			free(chroot_clusters[i].syscall);
			free_integer(chroot_clusters[i].retValues);
			free_string(chroot_clusters[i].filenames);
			free_string(chroot_clusters[i].paths);
			free_integer(chroot_clusters[i].filemodes);
			free_integer(chroot_clusters[i].file_owner_ids);
			free_integer(chroot_clusters[i].file_group_ids);
			free_integer(chroot_clusters[i].ruids);
			free_integer(chroot_clusters[i].rgids);
			free_integer(chroot_clusters[i].euids);
			free_integer(chroot_clusters[i].egids);
		}
		free(chroot_clusters);
	}

	if(fchown_clusters != NULL){
		for(i=0; i<fchown_clusters_number; i++){
			free(fchown_clusters[i].syscall);
			free_integer(fchown_clusters[i].retValues);
			free_integer(fchown_clusters[i].owners);
			free_integer(fchown_clusters[i].groups);
			free_string(fchown_clusters[i].filenames);
			free_string(fchown_clusters[i].paths);
			free_integer(fchown_clusters[i].filemodes);
			free_integer(fchown_clusters[i].file_owner_ids);
			free_integer(fchown_clusters[i].file_group_ids);
			free_integer(fchown_clusters[i].ruids);
			free_integer(fchown_clusters[i].rgids);
			free_integer(fchown_clusters[i].euids);
			free_integer(fchown_clusters[i].egids);
		}
		free(fchown_clusters);
	}

	if(execve_clusters != NULL){
		for(i=0; i<execve_clusters_number; i++){
				free(execve_clusters[i].syscall);
				free_string(execve_clusters[i].args);
				free_integer(execve_clusters[i].nbr_args);
				free_string(execve_clusters[i].filenames);
				free_string(execve_clusters[i].paths);
				free_integer(execve_clusters[i].retValues);
				free_integer(execve_clusters[i].filemodes);
				free_integer(execve_clusters[i].file_owner_ids);
				free_integer(execve_clusters[i].file_group_ids);
				free_integer(execve_clusters[i].euids);
				free_integer(execve_clusters[i].egids);
				free_integer(execve_clusters[i].ruids);
				free_integer(execve_clusters[i].rgids);
			}
			free(execve_clusters);
	}

	return 0;
}
