#include "clusterers.h"

/**
########################################################################################
# Performs Hierarchical clustering
# Returns a 2-dimensional array of booleans which size is the number of clusters and 
# each row denotes one cluster where the elements set to true correspond to the members of the cluster
# The distance between two clusters is defined as the average of the 
# distances between any of their members
#########################################################################################
**/

bool ** hierarchical_clustering(double ** distance_matrix, int size, int max_clusters_number){

	int i,j,k,l,count = 0;
	double smallest_distance,temp = 0;
	int smallest_distance_clusters;
	int number_of_clusters = size;
	double  * cluster_distances = NULL;
	bool * (* clusters) = (bool **) calloc(size,sizeof(bool *));
	for (i=0; i<size; i++){
		clusters[i] = (bool *) calloc(size,sizeof(bool));
		if (clusters[i] == NULL)
			printf("Could not allocate memory for cluster !");
	}
	bool * (* new_clusters) = NULL;
	

    // Initialize the clusters : each entry is in one cluster	
	for (i=0; i<size; i++)
		for(j=0; j<size; j++){
			if (i==j)
				clusters[i][j] = true;
			else 
				clusters[i][j] = false;
		}

    if (VERBOSE){
		printf("Size : %d", size);
		printf("######### CLUSTERS #########\n");
		for (i=0; i<size; i++){
			printf("i : %d \n",i);
			for (j=0; j<size; j++)
				printf("%d ",clusters[i][j]);
		}
		printf("\n###########################\n");
	}

	while(number_of_clusters >  max_clusters_number){

		// Compute the distances between the clusters
		// Uses average for now
		// Linear mapping : d(i,j) = cluster_distances[i*n + j]

		// Note : There will be some unused positions in the cluster distances since we don't need
        //        number_of_clusters*number_of_clusters distances.
		//        Allocating only number_of_clusters*(number_of_clusters-1)/2 saves space but makes
		//        it hard to find the clusters given a position in the cluster_distances array. 
    	cluster_distances = (double *) calloc(number_of_clusters*number_of_clusters,sizeof(double));
		for (i=0; i < number_of_clusters*number_of_clusters; i++)
			cluster_distances[i] = 999;
		for (i=0; i<number_of_clusters; i++)
			for(j=i+1; j<number_of_clusters; j++){
				temp = compute_cluster_distances(clusters[i], clusters[j], distance_matrix, size);
				cluster_distances[i*number_of_clusters + j] = temp;
				cluster_distances[j*number_of_clusters + i] = temp;
			}

		/**
		printf ("Distance between the clusters : \n");
		for (i=0; i<number_of_clusters; i++){
			printf("\n");
			for(j=0; j<number_of_clusters; j++)
				if (i !=j)
					printf("%d:%d => %f ",i,j, cluster_distances[i*size +j]);
		}
		**/
			
		// Pick smallest distance
		smallest_distance = cluster_distances[0];
		k = 0;
		l = 0;
		smallest_distance_clusters = 0;
		for (i=0; i<number_of_clusters; i++){
			for(j=i+1; j<number_of_clusters; j++)
			    if(cluster_distances[i*number_of_clusters + j] < smallest_distance){
					smallest_distance = cluster_distances[i*number_of_clusters + j];
					k = i;
					l = j;
				}
		}
	
		// Merge clusters
		if (VERBOSE){	
			printf("\nSmallest distance : %f", smallest_distance);
			printf("\nChosen clusters %d : %d - %d\n", smallest_distance_clusters, k,l);

			printf("Cluster 1 :\n");
			for (i=0; i<size; i++)
				printf("%d",clusters[k][i]);
			printf("\nCluster 2:\n");
			for (i=0; i<size; i++)
				printf("%d",clusters[l][i]);
		}
	
		// XOR the two clusters to merge
		for (i=0; i<size; i++)
			clusters[k][i] ^= clusters[l][i];
	
		// Generate new set of clusters
	
		new_clusters = (bool **) calloc(number_of_clusters-1,sizeof(bool *));
		for (i=0; i<number_of_clusters-1; i++)
			new_clusters[i] = (bool *) calloc(size,sizeof(bool));

		count = 0;	
		for (i=0; i<number_of_clusters; i++){
			if (i != l){
				for(j=0; j<size; j++)
					new_clusters[count][j] = clusters[i][j];
				count++;
			}
		}

		// Freeing the old clusters
	    for (i=0; i<number_of_clusters; i++)
			free(clusters[i]);
		free(clusters);

		clusters = new_clusters;
		number_of_clusters--;
					
		// Redo while number of clusters not sufficient
		if (VERBOSE){
			printf("######### CLUSTERS ###########\n");	
			for (i=0; i<number_of_clusters; i++){
				printf("\n");
				for (j=0; j<size; j++)
					printf("%d ",clusters[i][j]);
			}
			printf("\n#############################\n");
		}

	// Free old cluster distances
	free(cluster_distances);
	}

	if (VERBOSE){
    	printf("######### Final CLUSTERS ###########\n");	
		for (i=0; i<number_of_clusters; i++){
			printf("\n");
			for (j=0; j<size; j++)
				printf("%d ",clusters[i][j]);
		}
		printf("\n#############################\n");
	}
		for(i=0;i<number_of_clusters;i++)
			for(j=i+1; j<number_of_clusters;j++)
				printf("Cluster distance %d-%d : %f\n",i,j,compute_cluster_distances(clusters[i],clusters[j],distance_matrix,size));


	return clusters;
}

/**
########################################################################################
# Performs hierarchical clustering with stopping criterion based on distance
# Returns a 2-dimensional array of booleans which size is the number of clusters and 
# each row denotes one cluster where the elements set to true correspond to the members of the cluster
# The distance between two clusters is defined as the average of the 
# distances between any of their members
#########################################################################################
**/

bool ** hierarchical_clustering_2(double ** distance_matrix, int size, int * clusters_number){

	int i,j,k,l,count = 0;
	double smallest_distance,temp = 0;
	int smallest_distance_clusters;
	int number_of_clusters = size;
	bool stop = false;
	double  * cluster_distances = NULL;
	bool * (* clusters) = (bool **) calloc(size,sizeof(bool *));
	for (i=0; i<size; i++){
		clusters[i] = (bool *) calloc(size,sizeof(bool));
		if (clusters[i] == NULL)
			printf("Could not allocate memory for cluster !");
	}
	bool * (* new_clusters) = NULL;
	

    // Initialize the clusters : each entry is in one cluster	
	for (i=0; i<size; i++)
		for(j=0; j<size; j++){
			if (i==j)
				clusters[i][j] = true;
			else 
				clusters[i][j] = false;
		}

    if (VERBOSE){
		printf("Size : %d", size);
		printf("######### CLUSTERS #########\n");
		for (i=0; i<size; i++){
			printf("i : %d \n",i);
			for (j=0; j<size; j++)
				printf("%d ",clusters[i][j]);
		}
		printf("\n###########################\n");
	}

	while(!stop){

		// Compute the distances between the clusters
		// Uses average for now
		// Linear mapping : d(i,j) = cluster_distances[i*n + j]

		// Note : There will be some unused positions in the cluster distances since we don't need
        //        number_of_clusters*number_of_clusters distances.
		//        Allocating only number_of_clusters*(number_of_clusters-1)/2 saves space but makes
		//        it hard to find the clusters given a position in the cluster_distances array. 
    	cluster_distances = (double *) calloc(number_of_clusters*number_of_clusters,sizeof(double));
		for (i=0; i < number_of_clusters*number_of_clusters; i++)
			cluster_distances[i] = 999;
		for (i=0; i<number_of_clusters; i++)
			for(j=i+1; j<number_of_clusters; j++){
				temp = compute_cluster_distances(clusters[i], clusters[j], distance_matrix, size);
				cluster_distances[i*number_of_clusters + j] = temp;
				cluster_distances[j*number_of_clusters + i] = temp;
			}

		/**
		printf ("Distance between the clusters : \n");
		for (i=0; i<number_of_clusters; i++){
			printf("\n");
			for(j=0; j<number_of_clusters; j++)
				if (i !=j)
					printf("%d:%d => %f ",i,j, cluster_distances[i*size +j]);
		}
		**/
			
		// Pick smallest distance
		smallest_distance = cluster_distances[0];
		k = 0;
		l = 0;
		smallest_distance_clusters = 0;
		for (i=0; i<number_of_clusters; i++){
			for(j=i+1; j<number_of_clusters; j++)
			    if(cluster_distances[i*number_of_clusters + j] < smallest_distance){
					smallest_distance = cluster_distances[i*number_of_clusters + j];
					k = i;
					l = j;
				}
		}

		if(smallest_distance > MAX_DISTANCE_CLUSTERING){
			free(cluster_distances);
			stop = true;
		}
		else{
		    // Merge clusters
			if (VERBOSE){	
				printf("\nSmallest distance : %f", smallest_distance);
				printf("\nChosen clusters %d : %d - %d\n", smallest_distance_clusters, k,l);

				printf("Cluster 1 :\n");
				for (i=0; i<size; i++)
					printf("%d",clusters[k][i]);
				printf("\nCluster 2:\n");
				for (i=0; i<size; i++)
					printf("%d",clusters[l][i]);
			}
	
			// XOR the two clusters to merge
			for (i=0; i<size; i++)
				clusters[k][i] ^= clusters[l][i];
	
			// Generate new set of clusters
	
			new_clusters = (bool **) calloc(number_of_clusters-1,sizeof(bool *));
			for (i=0; i<number_of_clusters-1; i++)
				new_clusters[i] = (bool *) calloc(size,sizeof(bool));

			count = 0;	
			for (i=0; i<number_of_clusters; i++){
				if (i != l){
					for(j=0; j<size; j++)
						new_clusters[count][j] = clusters[i][j];
					count++;
				}
			}

			// Freeing the old clusters
		    for (i=0; i<number_of_clusters; i++)
				free(clusters[i]);

			free(clusters);

			clusters = new_clusters;
			number_of_clusters--;
					
			// Redo while number of clusters not sufficient
			if (VERBOSE){
				printf("######### CLUSTERS ###########\n");	
				for (i=0; i<number_of_clusters; i++){
					printf("\n");
					for (j=0; j<size; j++)
						printf("%d ",clusters[i][j]);
				}
				printf("\n#############################\n");
			}

		// Free old cluster distances
		free(cluster_distances);
		}
	}
	if (VERBOSE){
    	printf("######### Final CLUSTERS ###########\n");	
		for (i=0; i<number_of_clusters; i++){
			printf("\n");
			for (j=0; j<size; j++)
				printf("%d ",clusters[i][j]);
		}
		printf("\n#############################\n");
	}
		for(i=0;i<number_of_clusters;i++)
			for(j=i+1; j<number_of_clusters;j++)
				printf("Cluster distance %d-%d : %f\n",i,j,compute_cluster_distances(clusters[i],clusters[j],distance_matrix,size));

	*clusters_number = number_of_clusters;
	return clusters;
}

double compute_cluster_distances(bool * cluster1, bool * cluster2, double ** distance_matrix, int size){

	int i,j;
	double total_distance = 0;
    double max_distance = 0;
	int size1,size2 = 0;

	for (i=0; i<size; i++){
		if(cluster1[i] == true)
			size1++;
		if(cluster2[i] == true)
			size2++;
	}

	for(i=0; i<size; i++)
		if (cluster1[i] == true)
			for(j=0; j<size; j++)
				if (cluster2[j] == true){
					total_distance += distance_matrix[i][j];
					if (distance_matrix[i][j] > max_distance)
						max_distance = distance_matrix[i][j];
				}

    /** Average linkage
    printf("\nTotal distance/size*size : %f/%d", total_distance,size1*size2);				
	return total_distance/(size1*size2);
	**/

	// Complete linkage
	return max_distance;
}


double min_max_double(double * values, int size, bool min_max){

	int i;
	double result = values[0];

    for (i = 1; i <size; i++){
		if (!min_max){
			if (values[i] < result)
				result = values[i];
		}
		else if (min_max){
			if (values[i] > result)
				result = values[i];
		}
	}
	return result;

}

double min_max_string(char * filenames[], int size, bool min_max){

	int i,j;
	double result=0;
	double * distance_matrix[size];
	double temp;
	
	for (i=0; i<size; i++)
		distance_matrix[i] = (double *) calloc(size,sizeof(double));
	// Compute levenshtein matrix

	for (i = 0; i < size; i++){
		distance_matrix[i][i] = 0;
		for (j = i +1 ; j < size; j++){
			temp = levenshtein_distance(filenames[i], filenames[j]);
			distance_matrix[i][j] = temp;
			distance_matrix[j][i] = temp;
		}
	}

	for (i = 0; i < size; i++)
		for (j = 0; j < size; j++){
			if (i != j) {
				if (!min_max){
					if (distance_matrix[i][j] < result)
						result = distance_matrix[i][j];
				}
				else if (min_max){
					if (distance_matrix[i][j] > result)
						result = distance_matrix[i][j];
				}
			}
		}

	for (i=0; i<size; i++)
		free(distance_matrix[i]);

	return result;
}

/**
#########################################################################################
# Clustering methods for CLOSE system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct close_cluster* close_cluster(struct close_entry * entries, int size, int *max_clusters_number){

	struct close_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_close_clusters = NULL;
	struct close_cluster * close_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = close_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("dPathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = close_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_close_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
	    raw_close_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		close_clusters = model_close_clusters(results, size, raw_close_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",close_clusters[i].syscall);
			printf("Path length mean : %f \n", close_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", close_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", close_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", close_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(close_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(close_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(close_clusters[i].retValues);
			printf("########################################\n");
		}


		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_close_clusters[i]);
		free(raw_close_clusters);


        return close_clusters;
	}
}

struct close_cluster * model_close_clusters(struct close_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct close_cluster * close_clusters = (struct close_cluster *) calloc(clusters_number, sizeof(struct close_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		close_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(close_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(close_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		close_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", close_clusters[i].path_length_mean);
		close_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", close_clusters[i].path_length_variance);
		close_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", close_clusters[i].path_depth_mean);
		close_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", close_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&close_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&close_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&close_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&close_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&close_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&close_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&close_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&close_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&close_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&close_clusters[i].egids, cluster_egids[j]);
		}
		close_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return close_clusters;
}
	
struct close_transformed_entry * close_transform_data(struct close_entry * entries, int size){
	
	struct close_transformed_entry * results = (struct close_transformed_entry *) calloc(size, sizeof(struct close_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = 0;
	    char * token=NULL;
        char * prev_token=NULL;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = close_normalize_data(results, size);
	return results;
}

/**
struct close_transformed_entry * close_normalize_data(struct close_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double close_entries_distance(struct close_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct close_transformed_entry entry1 = entries[index1];
	struct close_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";

	// Compute the components of the distance 

	// Path length component
	if (max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if (max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if (max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);
/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

	printf("Path exclusion component : %f \n", path_exclusion_distance);

	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct close_cluster close_match_entry_to_cluster(struct close_cluster * clusters, int clusters_number, struct close_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

		// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

		// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


		// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

		// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

		// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

		// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

		// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}
/**
#########################################################################################
# Clustering methods for OPEN system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Flags | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Flags : Simple matching | Return_value : Manhattan
#########################################################################################
**/

struct open_transformed_entry * open_transform_data(struct open_entry * entries, int size){
	
	struct open_transformed_entry * results = (struct open_transformed_entry *) calloc(size, sizeof(struct open_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		results[i].path = (char *) malloc(results[i].path_length+1);
		strncpy(results[i].path,entries[i].path,strlen(entries[i].path)+1);
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
			if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].flags = (char *) malloc(strlen(entries[i].flags)+1);
		strncpy(results[i].flags, entries[i].flags, strlen(entries[i].flags) +1);
		//results[i].flags[strlen(entries[i].flags)] = '\0';
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
	}

    //results = open_normalize_data(results, size);

	return results;
}

struct open_cluster * open_cluster(struct open_entry * entries, int size, int  *max_clusters_number){
	struct open_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_open_clusters = NULL;
	struct open_cluster * open_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = open_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %f\n", results[i].z_score_path_length);
				printf("PathDepth : %f\n", results[i].z_score_path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("Flags : %s\n", results[i].flags);
				printf("RetValue : %f\n", results[i].z_score_retValue);
			}
		}

		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}

		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		//params[6] = open_min_max_filename(results, size, false);
		//params[7] = open_min_max_filename(results, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = open_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		 //raw_open_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		 raw_open_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		 printf("CLUSTER NUMBER : %d",*max_clusters_number);

		open_clusters = model_open_clusters(results, size, raw_open_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",open_clusters[i].syscall);
			printf("Path length mean : %f \n", open_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", open_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", open_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", open_clusters[i].path_depth_variance);
			//printf("Filenames : \n");
			//walk_strings(open_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(open_clusters[i].paths);
			printf("Flags : \n");
			walk_strings(open_clusters[i].flags);
			printf("RetValues : \n");
			walk_integers(open_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
			free(results[i].flags);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_open_clusters[i]);
		free(raw_open_clusters);

        return open_clusters;
    }
}



struct open_cluster * model_open_clusters(struct open_transformed_entry * entries, int size, bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	char ** cluster_flags = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct open_cluster * open_clusters = (struct open_cluster *) calloc(clusters_number, sizeof(struct open_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_flags = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_flags[k] = entries[j].flags;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		open_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(open_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(open_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		printf("\nLength mean : %f", open_clusters[i].path_length_mean);
		open_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variane : %f", open_clusters[i].path_length_variance);
		open_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", open_clusters[i].path_depth_mean);
		open_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", open_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&open_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&open_clusters[i].paths,cluster_paths[j]);
			add_string_uniq(&open_clusters[i].flags,cluster_flags[j]);
			add_integer_uniq(&open_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&open_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&open_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&open_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&open_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&open_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&open_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&open_clusters[i].egids, cluster_egids[j]);
		}
		open_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_flags);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return open_clusters;
				
}
/**
Computes the z-score for the path length, the path depth and the return value of the OPEN syscall
entries
**/

struct open_transformed_entry * open_normalize_data(struct open_transformed_entry * entries, int size) {

	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}

double open_entries_distance(struct open_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct open_transformed_entry entry1 = entries[index1];
	struct open_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double flags_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";



	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if (max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// Flags component
	if (strcmp(entries[index1].flags,entries[index2].flags))
		flags_distance = 1;
	else
		flags_distance = 0;

	printf("\nFlags component : %f", flags_distance);

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + PATH_EXCLUSION_WEIGHT); 
	return distance;

}

double open_min_max_path_length(struct open_transformed_entry * entries, int size, bool min_max){

	int i;
	double result = entries[0].path_length;

    for (i = 1; i <size; i++){
		if (!min_max){
			if (entries[i].path_length < result)
				result = entries[i].path_length;
		}
		else if (min_max){
			if (entries[i].path_length > result)
				result = entries[i].path_length;
		}
	}
	return result;

}

double open_min_max_path_depth(struct open_transformed_entry * entries, int size, bool min_max){
	
	int i;
	double result = entries[0].path_depth;
	
	for(i=1; i<size; i++){
		if (!min_max){
			if (entries[i].path_depth < result)
				result = entries[i].path_depth;
		}
		else if (min_max){
			if (entries[i].path_depth > result)
				result = entries[i].path_depth;
		}
	}
	return result;
}

double open_min_max_retValue(struct open_transformed_entry * entries, int size, bool min_max){

	int i;
	double result = entries[0].retValue;

	for(i=1; i<size; i++){
		if(!min_max){
			if (entries[i].retValue < result)
				result = entries[i].retValue;
		}
		else if (min_max){
			if(entries[i].retValue > result)
				result = entries[i].retValue;
		}
	}
	return result;
}

double open_min_max_filename(struct open_transformed_entry * entries, int size, bool min_max){

	int i,j;
	double result=0;
	double distance_matrix[size][size];
	double temp;
	// Compute levenshtein matrix

	for (i = 0; i < size; i++){
		distance_matrix[i][i] = 0;
		for (j = i +1 ; j < size; j++){
			temp = levenshtein_distance(entries[i].filename, entries[j].filename);
			distance_matrix[i][j] = temp;
			distance_matrix[j][i] = temp;
		}
	}

    /**
	printf("\n Levenshtein distance matrix :\n");
	for (i = 0; i < size ; i++){
		for(j=0; j < size ; j++)
			printf("%f-",distance_matrix[i][j]);
		printf("\n");
	}
	**/

	for (i = 0; i < size; i++)
		for (j = 0; j < size; j++){
			if (i != j) {
				if (!min_max){
					if (distance_matrix[i][j] < result)
						result = distance_matrix[i][j];
				}
				else if (min_max){
					if (distance_matrix[i][j] > result)
						result = distance_matrix[i][j];
				}
			}
		}

	return result;
}

double open_min_max_path(struct open_transformed_entry * entries, int size, bool min_max){

	int i,j;
	double result=0;
	double distance_matrix[size][size];
	double temp;
	// Compute levenshtein matrix

	for (i = 0; i < size; i++){
		distance_matrix[i][i] = 0;
		for (j = i +1 ; j < size; j++){
			temp = levenshtein_distance(entries[i].path, entries[j].path);
			distance_matrix[i][j] = temp;
			distance_matrix[j][i] = temp;
		}
	}

    /**
	printf("\n Levenshtein distance matrix :\n");
	for (i = 0; i < size ; i++){
		for(j=0; j < size ; j++)
			printf("%f-",distance_matrix[i][j]);
		printf("\n");
	}
	**/

	for (i = 0; i < size; i++)
		for (j = 0; j < size; j++){
			if (i != j) {
				if (!min_max){
					if (distance_matrix[i][j] < result)
						result = distance_matrix[i][j];
				}
				else if (min_max){
					if (distance_matrix[i][j] > result)
						result = distance_matrix[i][j];
				}
			}
		}

	return result;
}

struct open_cluster open_match_entry_to_cluster(struct open_cluster * clusters, int clusters_number, struct open_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		printf("Matching cluster : %d\n",i);
		//coeffs = get_open_cluster_matching_coefficients(clusters[i]);
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// Flags : 1 if not present, 0 otherwise
		if (!string_list_contains(clusters[i].flags,entry.flags))
			distances[i] += FLAGS_WEIGHT*1;
		
		printf("\nCurrent distance (flags) : %f", distances[i]);	

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);
					

		// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

		// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


		// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

		// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

		// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

		// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

		// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}

	return clusters[result];

}

double * get_open_cluster_matching_coefficients(struct open_cluster cluster){

	double * coeffs = (double *) malloc(3*sizeof(double));
	int max_levenshtein_distance = 0;
	int i,j,temp = 0;

	coeffs[0] = 1/(1+exp(-cluster.path_length_variance));
	coeffs[1] = 1/(1+exp(-cluster.path_depth_variance));
	
	for(i=0; i<strings_list_size(cluster.filenames); i++)
		for(j=i+1; j<strings_list_size(cluster.filenames);j++){
			temp = levenshtein_distance(get_string(cluster.filenames,i)->string, get_string(cluster.filenames,j)->string);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
		}
		

	coeffs[2] =  1/(1+exp(-max_levenshtein_distance));

	return coeffs;
}

/**
#########################################################################################
# Clustering methods for MMAP system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct mmap_cluster* mmap_cluster(struct mmap_entry * entries, int size, int *max_clusters_number){

	struct mmap_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_mmap_clusters = NULL;
	struct mmap_cluster * mmap_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = mmap_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = mmap_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_mmap_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_mmap_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		mmap_clusters = model_mmap_clusters(results, size, raw_mmap_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",mmap_clusters[i].syscall);
			printf("Path length mean : %f \n", mmap_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", mmap_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", mmap_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", mmap_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(mmap_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(mmap_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(mmap_clusters[i].retValues);
			printf("########################################\n");
		}
		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_mmap_clusters[i]);
		free(raw_mmap_clusters);

		return mmap_clusters;
	}
}

struct mmap_cluster * model_mmap_clusters(struct mmap_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct mmap_cluster * mmap_clusters = (struct mmap_cluster *) calloc(clusters_number, sizeof(struct mmap_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		mmap_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(mmap_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(mmap_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		mmap_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", mmap_clusters[i].path_length_mean);
		mmap_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", mmap_clusters[i].path_length_variance);
		mmap_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", mmap_clusters[i].path_depth_mean);
		mmap_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", mmap_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&mmap_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&mmap_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&mmap_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&mmap_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&mmap_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&mmap_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&mmap_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&mmap_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&mmap_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&mmap_clusters[i].egids, cluster_egids[j]);

		}
		mmap_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return mmap_clusters;
}
	
struct mmap_transformed_entry * mmap_transform_data(struct mmap_entry * entries, int size){
	
	struct mmap_transformed_entry * results = (struct mmap_transformed_entry *) calloc(size, sizeof(struct mmap_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}

		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
	}

    //results = mmap_normalize_data(results, size);
	return results;
}

/**
struct mmap_transformed_entry * mmap_normalize_data(struct mmap_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double mmap_entries_distance(struct mmap_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct mmap_transformed_entry entry1 = entries[index1];
	struct mmap_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;	
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";

	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct mmap_cluster mmap_match_entry_to_cluster(struct mmap_cluster * clusters, int clusters_number, struct mmap_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

		// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


		// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

		// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

		// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

		// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

		// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);
		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for STAT system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct stat_cluster* stat_cluster(struct stat_entry * entries, int size, int *max_clusters_number){

	struct stat_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_stat_clusters = NULL;
	struct stat_cluster * stat_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = stat_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = stat_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_stat_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_stat_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		stat_clusters = model_stat_clusters(results, size, raw_stat_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",stat_clusters[i].syscall);
			printf("Path length mean : %f \n", stat_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", stat_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", stat_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", stat_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(stat_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(stat_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(stat_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_stat_clusters[i]);
		free(raw_stat_clusters);
        return stat_clusters;
	}
}

struct stat_cluster * model_stat_clusters(struct stat_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct stat_cluster * stat_clusters = (struct stat_cluster *) calloc(clusters_number, sizeof(struct stat_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		stat_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(stat_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(stat_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		stat_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", stat_clusters[i].path_length_mean);
		stat_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", stat_clusters[i].path_length_variance);
		stat_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", stat_clusters[i].path_depth_mean);
		stat_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", stat_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&stat_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&stat_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&stat_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&stat_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&stat_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&stat_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&stat_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&stat_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&stat_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&stat_clusters[i].egids, cluster_egids[j]);
		}
		stat_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return stat_clusters;
}
	
struct stat_transformed_entry * stat_transform_data(struct stat_entry * entries, int size){
	
	struct stat_transformed_entry * results = (struct stat_transformed_entry *) calloc(size, sizeof(struct stat_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}

		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = stat_normalize_data(results, size);
	return results;
}

/**
struct stat_transformed_entry * stat_normalize_data(struct stat_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double stat_entries_distance(struct stat_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct stat_transformed_entry entry1 = entries[index1];
	struct stat_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";


	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);



/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct stat_cluster stat_match_entry_to_cluster(struct stat_cluster * clusters, int clusters_number, struct stat_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}


/**
#########################################################################################
# Clustering methods for ACCESS system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct access_cluster* access_cluster(struct access_entry * entries, int size, int *max_clusters_number){

	struct access_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_access_clusters = NULL;
	struct access_cluster * access_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = access_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = access_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_access_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_access_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		access_clusters = model_access_clusters(results, size, raw_access_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",access_clusters[i].syscall);
			printf("Path length mean : %f \n", access_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", access_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", access_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", access_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(access_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(access_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(access_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_access_clusters[i]);
		free(raw_access_clusters);
        
		return access_clusters;
	}
}

struct access_cluster * model_access_clusters(struct access_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct access_cluster * access_clusters = (struct access_cluster *) calloc(clusters_number, sizeof(struct access_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		access_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(access_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(access_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		access_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", access_clusters[i].path_length_mean);
		access_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", access_clusters[i].path_length_variance);
		access_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", access_clusters[i].path_depth_mean);
		access_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", access_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&access_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&access_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&access_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&access_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&access_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&access_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&access_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&access_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&access_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&access_clusters[i].egids, cluster_egids[j]);
		}
		access_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return access_clusters;
}
	
struct access_transformed_entry * access_transform_data(struct access_entry * entries, int size){
	
	struct access_transformed_entry * results = (struct access_transformed_entry *) calloc(size, sizeof(struct access_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}

		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
	}

    //results = access_normalize_data(results, size);
	return results;
}

/**
struct access_transformed_entry * access_normalize_data(struct access_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_accesss_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_accesss_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_accesss_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_accesss_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_accesss_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_accesss_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double access_entries_distance(struct access_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct access_transformed_entry entry1 = entries[index1];
	struct access_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";


	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);


/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct access_cluster access_match_entry_to_cluster(struct access_cluster * clusters, int clusters_number, struct access_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}


/**
#########################################################################################
# Clustering methods for MUNMAP system call
# Sample format : Sycall | Address | Length | Return_value
# Distances : Syscall : x ; Address : Custom ; Length : Custom ; Return_value : Custom
#########################################################################################
**/


struct munmap_cluster* munmap_cluster(struct munmap_entry * entries, int size, int * max_clusters_number){

	struct munmap_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[6];
	double addresses[size];
	double lengths[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_munmap_clusters = NULL;
	struct munmap_cluster * munmap_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = munmap_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Address : %d\n", results[i].address);
				printf("Length : %d\n", results[i].length);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			addresses[i] = results[i].address;
			lengths[i] = results[i].length;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(addresses, size, false);
		params[1] = min_max_double(addresses, size, true);
		params[2] = min_max_double(lengths, size, false);
		params[3] = min_max_double(lengths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = munmap_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_munmap_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_munmap_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		munmap_clusters = model_munmap_clusters(results, size, raw_munmap_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",munmap_clusters[i].syscall);
			printf("Addresses : \n");
			walk_integers(munmap_clusters[i].addresses);
			printf("Lengths : \n");
			walk_integers(munmap_clusters[i].lengths);
			printf("RetValues : \n");
			walk_integers(munmap_clusters[i].retValues);
			printf("########################################\n");
		}

		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_munmap_clusters[i]);
		free(raw_munmap_clusters);
        
        return munmap_clusters;
	}
}

struct munmap_cluster * model_munmap_clusters(struct munmap_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_addresses = NULL;
	int * cluster_lengths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct munmap_cluster * munmap_clusters = (struct munmap_cluster *) calloc(clusters_number, sizeof(struct munmap_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_addresses = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_lengths = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_addresses[k] = entries[j].address;
				cluster_lengths[k] = entries[j].length;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		munmap_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(munmap_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(munmap_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&munmap_clusters[i].addresses,cluster_addresses[j]);
			add_integer_uniq(&munmap_clusters[i].lengths,cluster_lengths[j]);
			add_integer_uniq(&munmap_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&munmap_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&munmap_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&munmap_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&munmap_clusters[i].egids, cluster_egids[j]);

		}
		munmap_clusters[i].cluster_size = cluster_sizes[i];

		free(cluster_addresses);
		free(cluster_lengths);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_egids);
		free(cluster_euids);
	}

	return munmap_clusters;
}
	
struct munmap_transformed_entry * munmap_transform_data(struct munmap_entry * entries, int size){
	
	struct munmap_transformed_entry * results = (struct munmap_transformed_entry *) calloc(size, sizeof(struct munmap_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].address = entries[i].address;
		results[i].length = entries[i].length;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;
	}

    //results = munmap_normalize_data(results, size);
	return results;
}

/**
struct munmap_transformed_entry * munmap_normalize_data(struct munmap_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_munmaps_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_munmaps_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_munmaps_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_munmaps_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_munmaps_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_munmaps_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double munmap_entries_distance(struct munmap_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct munmap_transformed_entry entry1 = entries[index1];
	struct munmap_transformed_entry entry2 = entries[index2];
	double min_address = params[0];
	double max_address = params[1];
	double min_length = params[2];
	double max_length = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	double address_distance = 0;
	double length_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;



	// Compute the components of the distance 

	// RetValue component
	if(max_address != min_address){
		address_distance = abs(entries[index1].address - entries[index2].address)/(max_address - min_address);
		printf("\n Max Address : %f",max_address);
		printf("\n Min Address : %f", min_address);
		printf("\n Address component : %f", address_distance);
	}

	// Length component
	if(max_length != min_length){
		length_distance = abs(entries[index1].length - entries[index2].length)/(max_length - min_length);
		printf("\n Max Length : %f",max_length);
		printf("\n Min Length : %f", min_length);
		printf("\n Length component : %f", length_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);


/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (ADDRESS_WEIGHT*address_distance + LENGTH_WEIGHT*length_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance)/(ADDRESS_WEIGHT + LENGTH_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct munmap_cluster munmap_match_entry_to_cluster(struct munmap_cluster * clusters, int clusters_number, struct munmap_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Address : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].addresses,entry.address))
			distances[i] += ADDRESS_WEIGHT*1;

		printf("\nCurrent distance (address) : %f", distances[i]);

	// Length : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].lengths,entry.length))
			distances[i] += LENGTH_WEIGHT*1;

		printf("\nCurrent distance (length) : %f", distances[i]);

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for PUTMSG system call
# Sample format : Sycall | Filedes | Flags | Return_value
# Distances : Syscall : x ; Address : Custom ; Length : Custom ; Return_value : Custom
#########################################################################################
**/


struct putmsg_cluster* putmsg_cluster(struct putmsg_entry * entries, int size, int *max_clusters_number){

	struct putmsg_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[6];
	double filedess[size];
	double flags[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_putmsg_clusters = NULL;
	struct putmsg_cluster * putmsg_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = putmsg_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Filedes : %d\n", results[i].filedes);
				printf("Flags : %d\n", results[i].flags);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			filedess[i] = results[i].filedes;
			flags[i] = results[i].flags;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(filedess, size, false);
		params[1] = min_max_double(filedess, size, true);
		params[2] = min_max_double(flags, size, false);
		params[3] = min_max_double(flags, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = putmsg_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_putmsg_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_putmsg_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		putmsg_clusters = model_putmsg_clusters(results, size, raw_putmsg_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",putmsg_clusters[i].syscall);
			printf("Filedess : \n");
			walk_integers(putmsg_clusters[i].filedess);
			printf("Flags : \n");
			walk_integers(putmsg_clusters[i].flags);
			printf("RetValues : \n");
			walk_integers(putmsg_clusters[i].retValues);
			printf("########################################\n");
		}
		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_putmsg_clusters[i]);
		free(raw_putmsg_clusters);
   

         return putmsg_clusters;
	}
}

struct putmsg_cluster * model_putmsg_clusters(struct putmsg_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_filedess = NULL;
	int * cluster_flags = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct putmsg_cluster * putmsg_clusters = (struct putmsg_cluster *) calloc(clusters_number, sizeof(struct putmsg_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_filedess = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_flags = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_filedess[k] = entries[j].filedes;
				cluster_flags[k] = entries[j].flags;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		putmsg_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(putmsg_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(putmsg_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&putmsg_clusters[i].filedess,cluster_filedess[j]);
			add_integer_uniq(&putmsg_clusters[i].flags,cluster_flags[j]);
			add_integer_uniq(&putmsg_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&putmsg_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&putmsg_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&putmsg_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&putmsg_clusters[i].egids, cluster_egids[j]);
		}
		putmsg_clusters[i].cluster_size = cluster_sizes[i];

		free(cluster_filedess);
		free(cluster_flags);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return putmsg_clusters;
}
	
struct putmsg_transformed_entry * putmsg_transform_data(struct putmsg_entry * entries, int size){
	
	struct putmsg_transformed_entry * results = (struct putmsg_transformed_entry *) calloc(size, sizeof(struct putmsg_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].filedes = entries[i].filedes;
		results[i].flags = entries[i].flags;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;
	}

    //results = putmsg_normalize_data(results, size);
	return results;
}

/**
struct putmsg_transformed_entry * putmsg_normalize_data(struct putmsg_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_putmsgs_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_putmsgs_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_putmsgs_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_putmsgs_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_putmsgs_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_putmsgs_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double putmsg_entries_distance(struct putmsg_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct putmsg_transformed_entry entry1 = entries[index1];
	struct putmsg_transformed_entry entry2 = entries[index2];
	double min_filedes = params[0];
	double max_filedes = params[1];
	double min_flags = params[2];
	double max_flags = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	double filedes_distance = 0;
	double flags_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;

	// Compute the components of the distance 

	// Filedes component
	if(max_filedes != min_filedes){
		filedes_distance = abs(entries[index1].filedes - entries[index2].filedes)/(max_filedes - min_filedes);
		printf("\n Max Filedes : %f",max_filedes);
		printf("\n Min Filedes : %f", min_filedes);
		printf("\n Filedes component : %f", filedes_distance);
	}

	// Flags component
	if(max_flags != min_flags){
		flags_distance = abs(entries[index1].flags - entries[index2].flags)/(max_flags - min_flags);
		printf("\n Max Flags : %f",max_flags);
		printf("\n Min Flags : %f", min_flags);
		printf("\n Flags component : %f", flags_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);


/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (FILEDES_WEIGHT*filedes_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT);

	return distance;
}

struct putmsg_cluster putmsg_match_entry_to_cluster(struct putmsg_cluster * clusters, int clusters_number, struct putmsg_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Filedes : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filedess,entry.filedes))
			distances[i] += FILEDES_WEIGHT*1;

		printf("\nCurrent distance (filedes) : %f", distances[i]);

	// Length : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].flags,entry.flags))
			distances[i] += FLAGS_WEIGHT*1;

		printf("\nCurrent distance (flag) : %f", distances[i]);

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for SYSINFO system call
# Sample format : Sycall | Command | Return_value
# Distances : Syscall : x ; Command : Custom ; Return_value : Custom
#########################################################################################
**/


struct sysinfo_cluster* sysinfo_cluster(struct sysinfo_entry * entries, int size, int *max_clusters_number){

	struct sysinfo_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[4];
	double commands[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_sysinfo_clusters = NULL;
	struct sysinfo_cluster * sysinfo_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = sysinfo_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Command : %d\n", results[i].command);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			commands[i] = results[i].command;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(commands, size, false);
		params[1] = min_max_double(commands, size, true);
		params[2] = min_max_double(retVals, size, false);
		params[3] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = sysinfo_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_sysinfo_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_sysinfo_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		sysinfo_clusters = model_sysinfo_clusters(results, size, raw_sysinfo_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",sysinfo_clusters[i].syscall);
			printf("Commands : \n");
			walk_integers(sysinfo_clusters[i].commands);
			printf("RetValues : \n");
			walk_integers(sysinfo_clusters[i].retValues);
			printf("########################################\n");
		}

		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_sysinfo_clusters[i]);
		free(raw_sysinfo_clusters);

        return sysinfo_clusters;
	}
}

struct sysinfo_cluster * model_sysinfo_clusters(struct sysinfo_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_commands = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct sysinfo_cluster * sysinfo_clusters = (struct sysinfo_cluster *) calloc(clusters_number, sizeof(struct sysinfo_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_commands = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_commands[k] = entries[j].command;
				cluster_retvals[k++] = entries[j].retValue;
			}
		sysinfo_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(sysinfo_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(sysinfo_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&sysinfo_clusters[i].commands,cluster_commands[j]);
			add_integer_uniq(&sysinfo_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&sysinfo_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&sysinfo_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&sysinfo_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&sysinfo_clusters[i].egids, cluster_egids[j]);

		}
		sysinfo_clusters[i].cluster_size = cluster_sizes[i];

	free(cluster_commands);
	free(cluster_retvals);
	free(cluster_ruids);
	free(cluster_rgids);
	free(cluster_euids);
	free(cluster_egids);

	}

	return sysinfo_clusters;
}
	
struct sysinfo_transformed_entry * sysinfo_transform_data(struct sysinfo_entry * entries, int size){
	
	struct sysinfo_transformed_entry * results = (struct sysinfo_transformed_entry *) calloc(size, sizeof(struct sysinfo_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].command = entries[i].command;
		results[i].retValue = entries[i].retValue;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
	}

    //results = sysinfo_normalize_data(results, size);
	return results;
}

/**
struct sysinfo_transformed_entry * sysinfo_normalize_data(struct sysinfo_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_sysinfos_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_sysinfos_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_sysinfos_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_sysinfos_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_sysinfos_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_sysinfos_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double sysinfo_entries_distance(struct sysinfo_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct sysinfo_transformed_entry entry1 = entries[index1];
	struct sysinfo_transformed_entry entry2 = entries[index2];
	double min_command = params[0];
	double max_command = params[1];
	double min_retValue = params[2];
	double max_retValue = params[3];
	double command_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Filedes component
	if(max_command != min_command){
		command_distance = abs(entries[index1].command - entries[index2].command)/(max_command - min_command);
		printf("\n Max Command : %f",max_command);
		printf("\n Min Command : %f", min_command);
		printf("\n Command component : %f", command_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);


/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (COMMAND_WEIGHT*command_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct sysinfo_cluster sysinfo_match_entry_to_cluster(struct sysinfo_cluster * clusters, int clusters_number, struct sysinfo_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Command : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].commands,entry.command))
			distances[i] += COMMAND_WEIGHT*1;

		printf("\nCurrent distance (command) : %f", distances[i]);


	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for CHDIR system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct chdir_cluster* chdir_cluster(struct chdir_entry * entries, int size, int *max_clusters_number){

	struct chdir_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_chdir_clusters = NULL;
	struct chdir_cluster * chdir_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = chdir_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = chdir_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_chdir_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_chdir_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		chdir_clusters = model_chdir_clusters(results, size, raw_chdir_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",chdir_clusters[i].syscall);
			printf("Path length mean : %f \n", chdir_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", chdir_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", chdir_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", chdir_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(chdir_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(chdir_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(chdir_clusters[i].retValues);
			printf("########################################\n");
		}

 			// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_chdir_clusters[i]);
		free(raw_chdir_clusters);
   

        return chdir_clusters;
	}
}

struct chdir_cluster * model_chdir_clusters(struct chdir_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct chdir_cluster * chdir_clusters = (struct chdir_cluster *) calloc(clusters_number, sizeof(struct chdir_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		chdir_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(chdir_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(chdir_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		chdir_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", chdir_clusters[i].path_length_mean);
		chdir_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", chdir_clusters[i].path_length_variance);
		chdir_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", chdir_clusters[i].path_depth_mean);
		chdir_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", chdir_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&chdir_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&chdir_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&chdir_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&chdir_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&chdir_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&chdir_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&chdir_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&chdir_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&chdir_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&chdir_clusters[i].egids, cluster_egids[j]);
		}
		chdir_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return chdir_clusters;
}
	
struct chdir_transformed_entry * chdir_transform_data(struct chdir_entry * entries, int size){
	
	struct chdir_transformed_entry * results = (struct chdir_transformed_entry *) calloc(size, sizeof(struct chdir_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
	}

    //results = chdir_normalize_data(results, size);
	return results;
}

/**
struct chdir_transformed_entry * chdir_normalize_data(struct chdir_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_chdirs_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_chdirs_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_chdirs_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_chdirs_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_chdirs_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_chdirs_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double chdir_entries_distance(struct chdir_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct chdir_transformed_entry entry1 = entries[index1];
	struct chdir_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";


	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct chdir_cluster chdir_match_entry_to_cluster(struct chdir_cluster * clusters, int clusters_number, struct chdir_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);



		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}


/**
#########################################################################################
# Clustering methods for READLINK system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct readlink_cluster* readlink_cluster(struct readlink_entry * entries, int size, int *max_clusters_number){

	struct readlink_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_readlink_clusters = NULL;
	struct readlink_cluster * readlink_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = readlink_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = readlink_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_readlink_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_readlink_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		readlink_clusters = model_readlink_clusters(results, size, raw_readlink_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",readlink_clusters[i].syscall);
			printf("Path length mean : %f \n", readlink_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", readlink_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", readlink_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", readlink_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(readlink_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(readlink_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(readlink_clusters[i].retValues);
			printf("########################################\n");
		}

 			// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_readlink_clusters[i]);
		free(raw_readlink_clusters);
   
        return readlink_clusters;
	}
}

struct readlink_cluster * model_readlink_clusters(struct readlink_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct readlink_cluster * readlink_clusters = (struct readlink_cluster *) calloc(clusters_number, sizeof(struct readlink_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		readlink_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(readlink_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(readlink_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		readlink_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", readlink_clusters[i].path_length_mean);
		readlink_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", readlink_clusters[i].path_length_variance);
		readlink_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", readlink_clusters[i].path_depth_mean);
		readlink_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", readlink_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&readlink_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&readlink_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&readlink_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&readlink_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&readlink_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&readlink_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&readlink_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&readlink_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&readlink_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&readlink_clusters[i].egids, cluster_egids[j]);

		}
		readlink_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return readlink_clusters;
}
	
struct readlink_transformed_entry * readlink_transform_data(struct readlink_entry * entries, int size){
	
	struct readlink_transformed_entry * results = (struct readlink_transformed_entry *) calloc(size, sizeof(struct readlink_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}

		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = readlink_normalize_data(results, size);
	return results;
}

/**
struct readlink_transformed_entry * readlink_normalize_data(struct readlink_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_readlinks_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_readlinks_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_readlinks_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_readlinks_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_readlinks_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_readlinks_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double readlink_entries_distance(struct readlink_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct readlink_transformed_entry entry1 = entries[index1];
	struct readlink_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";


	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_GROUP_ID_WEIGHT + FILE_OWNER_ID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct readlink_cluster readlink_match_entry_to_cluster(struct readlink_cluster * clusters, int clusters_number, struct readlink_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for UNLINK system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct unlink_cluster* unlink_cluster(struct unlink_entry * entries, int size, int *max_clusters_number){

	struct unlink_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_unlink_clusters = NULL;
	struct unlink_cluster * unlink_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = unlink_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = unlink_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_unlink_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_unlink_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		unlink_clusters = model_unlink_clusters(results, size, raw_unlink_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",unlink_clusters[i].syscall);
			printf("Path length mean : %f \n", unlink_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", unlink_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", unlink_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", unlink_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(unlink_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(unlink_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(unlink_clusters[i].retValues);
			printf("########################################\n");
		}

 			// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_unlink_clusters[i]);
		free(raw_unlink_clusters);
   
        return unlink_clusters;
	}
}

struct unlink_cluster * model_unlink_clusters(struct unlink_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct unlink_cluster * unlink_clusters = (struct unlink_cluster *) calloc(clusters_number, sizeof(struct unlink_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		unlink_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(unlink_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(unlink_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		unlink_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", unlink_clusters[i].path_length_mean);
		unlink_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", unlink_clusters[i].path_length_variance);
		unlink_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", unlink_clusters[i].path_depth_mean);
		unlink_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", unlink_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&unlink_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&unlink_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&unlink_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&unlink_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&unlink_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&unlink_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&unlink_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&unlink_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&unlink_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&unlink_clusters[i].egids, cluster_egids[j]);

		}
		unlink_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return unlink_clusters;
}
	
struct unlink_transformed_entry * unlink_transform_data(struct unlink_entry * entries, int size){
	
	struct unlink_transformed_entry * results = (struct unlink_transformed_entry *) calloc(size, sizeof(struct unlink_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}

		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
	}

    //results = unlink_normalize_data(results, size);
	return results;
}

/**
struct unlink_transformed_entry * unlink_normalize_data(struct unlink_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_unlinks_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_unlinks_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_unlinks_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_unlinks_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_unlinks_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_unlinks_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double unlink_entries_distance(struct unlink_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct unlink_transformed_entry entry1 = entries[index1];
	struct unlink_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";


	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct unlink_cluster unlink_match_entry_to_cluster(struct unlink_cluster * clusters, int clusters_number, struct unlink_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for CREAT system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct creat_cluster* creat_cluster(struct creat_entry * entries, int size, int *max_clusters_number){

	struct creat_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_creat_clusters = NULL;
	struct creat_cluster * creat_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = creat_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = creat_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_creat_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_creat_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		creat_clusters = model_creat_clusters(results, size, raw_creat_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",creat_clusters[i].syscall);
			printf("Path length mean : %f \n", creat_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", creat_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", creat_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", creat_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(creat_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(creat_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(creat_clusters[i].retValues);
			printf("########################################\n");
		}

 			// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_creat_clusters[i]);
		free(raw_creat_clusters);
   
        return creat_clusters;
	}
}

struct creat_cluster * model_creat_clusters(struct creat_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct creat_cluster * creat_clusters = (struct creat_cluster *) calloc(clusters_number, sizeof(struct creat_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		creat_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(creat_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(creat_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		creat_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", creat_clusters[i].path_length_mean);
		creat_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", creat_clusters[i].path_length_variance);
		creat_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", creat_clusters[i].path_depth_mean);
		creat_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", creat_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&creat_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&creat_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&creat_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&creat_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&creat_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&creat_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&creat_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&creat_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&creat_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&creat_clusters[i].egids, cluster_egids[j]);
		}
		creat_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return creat_clusters;
}
	
struct creat_transformed_entry * creat_transform_data(struct creat_entry * entries, int size){
	
	struct creat_transformed_entry * results = (struct creat_transformed_entry *) calloc(size, sizeof(struct creat_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}

		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;


	}

    //results = creat_normalize_data(results, size);
	return results;
}

/**
struct creat_transformed_entry * creat_normalize_data(struct creat_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_creats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_creats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_creats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_creats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_creats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_creats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double creat_entries_distance(struct creat_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct creat_transformed_entry entry1 = entries[index1];
	struct creat_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";



	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct creat_cluster creat_match_entry_to_cluster(struct creat_cluster * clusters, int clusters_number, struct creat_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for LSTAT system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct lstat_cluster* lstat_cluster(struct lstat_entry * entries, int size, int *max_clusters_number){

	struct lstat_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_lstat_clusters = NULL;
	struct lstat_cluster * lstat_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = lstat_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = lstat_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_lstat_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_lstat_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		lstat_clusters = model_lstat_clusters(results, size, raw_lstat_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",lstat_clusters[i].syscall);
			printf("Path length mean : %f \n", lstat_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", lstat_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", lstat_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", lstat_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(lstat_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(lstat_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(lstat_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_lstat_clusters[i]);
		free(raw_lstat_clusters);

        return lstat_clusters;
	}
}

struct lstat_cluster * model_lstat_clusters(struct lstat_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct lstat_cluster * lstat_clusters = (struct lstat_cluster *) calloc(clusters_number, sizeof(struct lstat_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		lstat_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(lstat_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(lstat_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		lstat_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", lstat_clusters[i].path_length_mean);
		lstat_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", lstat_clusters[i].path_length_variance);
		lstat_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", lstat_clusters[i].path_depth_mean);
		lstat_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", lstat_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&lstat_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&lstat_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&lstat_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&lstat_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&lstat_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&lstat_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&lstat_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&lstat_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&lstat_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&lstat_clusters[i].egids, cluster_egids[j]);
		}
		lstat_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return lstat_clusters;
}
	
struct lstat_transformed_entry * lstat_transform_data(struct lstat_entry * entries, int size){
	
	struct lstat_transformed_entry * results = (struct lstat_transformed_entry *) calloc(size, sizeof(struct lstat_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = lstat_normalize_data(results, size);
	return results;
}

/**
struct lstat_transformed_entry * lstat_normalize_data(struct lstat_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_lstats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_lstats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_lstats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_lstats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_lstats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_lstats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double lstat_entries_distance(struct lstat_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct lstat_transformed_entry entry1 = entries[index1];
	struct lstat_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";



	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct lstat_cluster lstat_match_entry_to_cluster(struct lstat_cluster * clusters, int clusters_number, struct lstat_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for SETEUID system call
# Sample format : Sycall | Euid | Return_value
# Distances : Syscall : x ; Euid : Custom ; Return_value : Custom
#########################################################################################
**/


struct seteuid_cluster* seteuid_cluster(struct seteuid_entry * entries, int size, int *max_clusters_number){

	struct seteuid_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[4];
	double euids[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_seteuid_clusters = NULL;
	struct seteuid_cluster * seteuid_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = seteuid_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Euid : %d\n", results[i].euid);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			euids[i] = results[i].euid;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(euids, size, false);
		params[1] = min_max_double(euids, size, true);
		params[2] = min_max_double(retVals, size, false);
		params[3] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = seteuid_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_seteuid_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_seteuid_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		seteuid_clusters = model_seteuid_clusters(results, size, raw_seteuid_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",seteuid_clusters[i].syscall);
			printf("Euids : \n");
			walk_integers(seteuid_clusters[i].euids);
			printf("RetValues : \n");
			walk_integers(seteuid_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_seteuid_clusters[i]);
		free(raw_seteuid_clusters);

        return seteuid_clusters;
	}
}

struct seteuid_cluster * model_seteuid_clusters(struct seteuid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_euids = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_p_euids = NULL;
	int * cluster_egids = NULL;


	struct seteuid_cluster * seteuid_clusters = (struct seteuid_cluster *) calloc(clusters_number, sizeof(struct seteuid_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i],sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i],sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i],sizeof(int));
		cluster_p_euids = (int *) calloc(cluster_sizes[i],sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_euids[k] = entries[j].euid;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_p_euids[k] = entries[j].p_euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		seteuid_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(seteuid_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(seteuid_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&seteuid_clusters[i].euids,cluster_euids[j]);
			add_integer_uniq(&seteuid_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&seteuid_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&seteuid_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&seteuid_clusters[i].p_euids, cluster_p_euids[j]);
			add_integer_uniq(&seteuid_clusters[i].egids, cluster_egids[j]);

		}
		seteuid_clusters[i].cluster_size = cluster_sizes[i];

		free(cluster_euids);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_p_euids);
		free(cluster_egids);
	}

	return seteuid_clusters;
}
	
struct seteuid_transformed_entry * seteuid_transform_data(struct seteuid_entry * entries, int size){
	
	struct seteuid_transformed_entry * results = (struct seteuid_transformed_entry *) calloc(size, sizeof(struct seteuid_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].euid = entries[i].euid;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].p_euid = entries[i].p_euid;
	}

    //results = seteuid_normalize_data(results, size);
	return results;
}

/**
struct seteuid_transformed_entry * seteuid_normalize_data(struct seteuid_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_seteuids_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_seteuids_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_seteuids_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_seteuids_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_seteuids_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_seteuids_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double seteuid_entries_distance(struct seteuid_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct seteuid_transformed_entry entry1 = entries[index1];
	struct seteuid_transformed_entry entry2 = entries[index2];
	double min_euid = params[0];
	double max_euid = params[1];
	double min_retValue = params[2];
	double max_retValue = params[3];
	double euid_distance = 0;
	double retvalue_distance = 0;
	double p_euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Euid component
	if(max_euid != min_euid){
		euid_distance = abs(entries[index1].euid - entries[index2].euid)/(max_euid - min_euid);
		printf("\n Max Euid : %f",max_euid);
		printf("\n Min Euid : %f", min_euid);
		printf("\n Euid component : %f", euid_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Process Euid component
	p_euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (EUID_WEIGHT*euid_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*p_euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct seteuid_cluster seteuid_match_entry_to_cluster(struct seteuid_cluster * clusters, int clusters_number, struct seteuid_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].p_euids,entry.p_euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);


	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for SETGID system call
# Sample format : Sycall | Gid | Return_value
# Distances : Syscall : x ; Gid : Custom ; Return_value : Custom
#########################################################################################
**/


struct setgid_cluster* setgid_cluster(struct setgid_entry * entries, int size, int *max_clusters_number){

	struct setgid_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[4];
	double gids[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_setgid_clusters = NULL;
	struct setgid_cluster * setgid_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = setgid_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Gid : %d\n", results[i].gid);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			gids[i] = results[i].gid;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(gids, size, false);
		params[1] = min_max_double(gids, size, true);
		params[2] = min_max_double(retVals, size, false);
		params[3] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = setgid_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_setgid_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_setgid_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		setgid_clusters = model_setgid_clusters(results, size, raw_setgid_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",setgid_clusters[i].syscall);
			printf("Gids : \n");
			walk_integers(setgid_clusters[i].gids);
			printf("RetValues : \n");
			walk_integers(setgid_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_setgid_clusters[i]);
		free(raw_setgid_clusters);

        return setgid_clusters;
	}
}

struct setgid_cluster * model_setgid_clusters(struct setgid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_gids = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;


	struct setgid_cluster * setgid_clusters = (struct setgid_cluster *) calloc(clusters_number, sizeof(struct setgid_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_gids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_gids[k] = entries[j].gid;
				cluster_euids[k] = entries[j].euid;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;

				cluster_retvals[k++] = entries[j].retValue;
			}
		setgid_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(setgid_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(setgid_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&setgid_clusters[i].gids,cluster_gids[j]);
			add_integer_uniq(&setgid_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&setgid_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&setgid_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&setgid_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&setgid_clusters[i].egids, cluster_egids[j]);
		}
		setgid_clusters[i].cluster_size = cluster_sizes[i];
	}

	return setgid_clusters;
}
	
struct setgid_transformed_entry * setgid_transform_data(struct setgid_entry * entries, int size){
	
	struct setgid_transformed_entry * results = (struct setgid_transformed_entry *) calloc(size, sizeof(struct setgid_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].gid = entries[i].gid;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;
	}

    //results = setgid_normalize_data(results, size);
	return results;
}

/**
struct setgid_transformed_entry * setgid_normalize_data(struct setgid_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_setgids_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_setgids_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_setgids_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_setgids_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_setgids_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_setgids_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double setgid_entries_distance(struct setgid_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct setgid_transformed_entry entry1 = entries[index1];
	struct setgid_transformed_entry entry2 = entries[index2];
	double min_gid = params[0];
	double max_gid = params[1];
	double min_retValue = params[2];
	double max_retValue = params[3];
	double gid_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Filedes component
	if(max_gid != min_gid){
		gid_distance = abs(entries[index1].gid - entries[index2].gid)/(max_gid - min_gid);
		printf("\n Max Gid : %f",max_gid);
		printf("\n Min Gid : %f", min_gid);
		printf("\n Gid component : %f", gid_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (GID_WEIGHT*gid_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct setgid_cluster setgid_match_entry_to_cluster(struct setgid_cluster * clusters, int clusters_number, struct setgid_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Gid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].gids,entry.gid))
			distances[i] += GID_WEIGHT*1;

		printf("\nCurrent distance (gid) : %f", distances[i]);


	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for SETGROUPS system call
# Sample format : Sycall | Ngroups | Return_value
# Distances : Syscall : x ; Ngroups : Custom ; Return_value : Custom
#########################################################################################
**/


struct setgroups_cluster* setgroups_cluster(struct setgroups_entry * entries, int size, int *max_clusters_number){

	struct setgroups_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[4];
	double ngroupss[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_setgroups_clusters = NULL;
	struct setgroups_cluster * setgroups_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = setgroups_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Ngroups : %d\n", results[i].ngroups);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			ngroupss[i] = results[i].ngroups;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(ngroupss, size, false);
		params[1] = min_max_double(ngroupss, size, true);
		params[2] = min_max_double(retVals, size, false);
		params[3] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = setgroups_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_setgroups_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_setgroups_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		setgroups_clusters = model_setgroups_clusters(results, size, raw_setgroups_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",setgroups_clusters[i].syscall);
			printf("Ngroupss : \n");
			walk_integers(setgroups_clusters[i].ngroupss);
			printf("RetValues : \n");
			walk_integers(setgroups_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_setgroups_clusters[i]);
		free(raw_setgroups_clusters);

        return setgroups_clusters;
	}
}

struct setgroups_cluster * model_setgroups_clusters(struct setgroups_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_ngroupss = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;


	struct setgroups_cluster * setgroups_clusters = (struct setgroups_cluster *) calloc(clusters_number, sizeof(struct setgroups_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_ngroupss = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_ngroupss[k] = entries[j].ngroups;
				cluster_euids[k] = entries[j].euid;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;

				cluster_retvals[k++] = entries[j].retValue;
			}
		setgroups_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(setgroups_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(setgroups_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&setgroups_clusters[i].ngroupss,cluster_ngroupss[j]);
			add_integer_uniq(&setgroups_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&setgroups_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&setgroups_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&setgroups_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&setgroups_clusters[i].egids, cluster_egids[j]);
		}
		setgroups_clusters[i].cluster_size = cluster_sizes[i];

		free(cluster_ngroupss);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_euids);
		free(cluster_egids);
		free(cluster_rgids);
	}

	return setgroups_clusters;
}
	
struct setgroups_transformed_entry * setgroups_transform_data(struct setgroups_entry * entries, int size){
	
	struct setgroups_transformed_entry * results = (struct setgroups_transformed_entry *) calloc(size, sizeof(struct setgroups_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].ngroups = entries[i].ngroups;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;
	}

    //results = setgroups_normalize_data(results, size);
	return results;
}

/**
struct setgroups_transformed_entry * setgroups_normalize_data(struct setgroups_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_setgroupss_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_setgroupss_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_setgroupss_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_setgroupss_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_setgroupss_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_setgroupss_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double setgroups_entries_distance(struct setgroups_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct setgroups_transformed_entry entry1 = entries[index1];
	struct setgroups_transformed_entry entry2 = entries[index2];
	double min_ngroups = params[0];
	double max_ngroups = params[1];
	double min_retValue = params[2];
	double max_retValue = params[3];
	double ngroups_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Filedes component
	if(max_ngroups != min_ngroups){
		ngroups_distance = abs(entries[index1].ngroups - entries[index2].ngroups)/(max_ngroups - min_ngroups);
		printf("\n Max Ngroups : %f",max_ngroups);
		printf("\n Min Ngroups : %f", min_ngroups);
		printf("\n Ngroups component : %f", ngroups_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (NGROUPS_WEIGHT*ngroups_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct setgroups_cluster setgroups_match_entry_to_cluster(struct setgroups_cluster * clusters, int clusters_number, struct setgroups_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Ngroups : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ngroupss,entry.ngroups))
			distances[i] += NGROUPS_WEIGHT*1;

		printf("\nCurrent distance (ngroups) : %f", distances[i]);


	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for SETEGID system call
# Sample format : Sycall | Egid | Return_value
# Distances : Syscall : x ; Egid : Custom ; Return_value : Custom
#########################################################################################
**/


struct setegid_cluster* setegid_cluster(struct setegid_entry * entries, int size, int *max_clusters_number){

	struct setegid_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[4];
	double egids[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_setegid_clusters = NULL;
	struct setegid_cluster * setegid_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = setegid_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Egid : %d\n", results[i].egid);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			egids[i] = results[i].egid;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(egids, size, false);
		params[1] = min_max_double(egids, size, true);
		params[2] = min_max_double(retVals, size, false);
		params[3] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = setegid_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_setegid_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_setegid_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		setegid_clusters = model_setegid_clusters(results, size, raw_setegid_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",setegid_clusters[i].syscall);
			printf("Egids : \n");
			walk_integers(setegid_clusters[i].egids);
			printf("RetValues : \n");
			walk_integers(setegid_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_setegid_clusters[i]);
		free(raw_setegid_clusters);

        return setegid_clusters;
	}
}

struct setegid_cluster * model_setegid_clusters(struct setegid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_egids = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_p_egids = NULL;


	struct setegid_cluster * setegid_clusters = (struct setegid_cluster *) calloc(clusters_number, sizeof(struct setegid_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_p_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_egids[k] = entries[j].egid;
				cluster_euids[k] = entries[j].euid;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_p_egids[k] = entries[j].p_egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		setegid_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(setegid_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(setegid_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&setegid_clusters[i].egids,cluster_egids[j]);
			add_integer_uniq(&setegid_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&setegid_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&setegid_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&setegid_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&setegid_clusters[i].p_egids, cluster_p_egids[j]);

		}
		setegid_clusters[i].cluster_size = cluster_sizes[i];

		free(cluster_egids);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_p_egids);
	}

	return setegid_clusters;
}
	
struct setegid_transformed_entry * setegid_transform_data(struct setegid_entry * entries, int size){
	
	struct setegid_transformed_entry * results = (struct setegid_transformed_entry *) calloc(size, sizeof(struct setegid_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].egid = entries[i].egid;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].p_egid = entries[i].p_egid;
		results[i].euid = entries[i].euid;
	}

    //results = setegid_normalize_data(results, size);
	return results;
}

/**
struct setegid_transformed_entry * setegid_normalize_data(struct setegid_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_setegids_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_setegids_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_setegids_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_setegids_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_setegids_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_setegids_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double setegid_entries_distance(struct setegid_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct setegid_transformed_entry entry1 = entries[index1];
	struct setegid_transformed_entry entry2 = entries[index2];
	double min_egid = params[0];
	double max_egid = params[1];
	double min_retValue = params[2];
	double max_retValue = params[3];
	double egid_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double p_egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Filedes component
	if(max_egid != min_egid){
		egid_distance = abs(entries[index1].egid - entries[index2].egid)/(max_egid - min_egid);
		printf("\n Max Egid : %f",max_egid);
		printf("\n Min Egid : %f", min_egid);
		printf("\n Egid component : %f", egid_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	p_egid_distance = compute_egid_distance(entries[index1].p_egid, entries[index2].p_egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (EGID_WEIGHT*egid_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*p_egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct setegid_cluster setegid_match_entry_to_cluster(struct setegid_cluster * clusters, int clusters_number, struct setegid_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Egid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids,entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].p_egids, entry.p_egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}


/**
#########################################################################################
# Clustering methods for RENAME system call
# Sample format : Sycall | Path_length1 | Path_depth1 |  Path_length2 | Path_depth2 | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct rename_cluster* rename_cluster(struct rename_entry * entries, int size, int *max_clusters_number){

	struct rename_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[14];
	double lengths1[size];
	double depths1[size];
	double lengths2[size];
	double depths2[size];
	double retVals[size];
	char * paths1[size];
	char * paths2[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_rename_clusters = NULL;
	struct rename_cluster * rename_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = rename_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength1 : %d\n", results[i].path_length1);
				printf("PathDepth1 : %d\n", results[i].path_depth1);
				printf("PathLength2 : %d\n", results[i].path_length2);
				printf("PathDepth2 : %d\n", results[i].path_depth2);
				printf("Filename : %s\n", results[i].filename1);
				printf("Filename : %s\n", results[i].filename2);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths1[i] = results[i].path_length1;
			depths1[i] = results[i].path_depth1;
			paths1[i] = results[i].path1;
			lengths2[i] = results[i].path_length2;
			depths2[i] = results[i].path_depth2;
			paths2[i] = results[i].path2;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(lengths1, size, false);
		params[1] = min_max_double(lengths1, size, true);
		params[2] = min_max_double(depths1, size, false);
		params[3] = min_max_double(depths1, size, true);
		params[4] = min_max_double(lengths2, size, false);
		params[5] = min_max_double(lengths2, size, true);
		params[6] = min_max_double(depths2, size, false);
		params[7] = min_max_double(depths2, size, true);
		params[8] = min_max_double(retVals, size, false);
		params[9] = min_max_double(retVals, size, true);
		params[10] = min_max_string(paths1, size, false);
		params[11] = min_max_string(paths1, size, true);
		params[12] = min_max_string(paths2, size, false);
		params[13] = min_max_string(paths2, size, true);



		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = rename_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_rename_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_rename_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		rename_clusters = model_rename_clusters(results, size, raw_rename_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",rename_clusters[i].syscall);
			printf("Path 1 length mean : %f \n", rename_clusters[i].path_length_mean1);
			printf("Path 1 length variance : %f \n", rename_clusters[i].path_length_variance1);
			printf("Path 1 depth mean : %f \n", rename_clusters[i].path_depth_mean1);
			printf("Path 1 depth variance : %f \n", rename_clusters[i].path_depth_variance1);
			printf("Path 2 length mean : %f \n", rename_clusters[i].path_length_mean2);
			printf("Path 2 length variance : %f \n", rename_clusters[i].path_length_variance2);
			printf("Path 2 depth mean : %f \n", rename_clusters[i].path_depth_mean2);
			printf("Path 2 depth variance : %f \n", rename_clusters[i].path_depth_variance2);
			printf("Filenames1 : \n");
			walk_strings(rename_clusters[i].filenames1);
			printf("Filenames2 : \n");
			walk_strings(rename_clusters[i].filenames2);
			printf("Paths 1: \n");
			walk_strings(rename_clusters[i].paths1);
			printf("Paths 2: \n");
			walk_strings(rename_clusters[i].paths2);
			printf("RetValues : \n");
			walk_integers(rename_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path1);
			free(results[i].path2);
			free(results[i].filename1);
			free(results[i].filename2);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_rename_clusters[i]);
		free(raw_rename_clusters);

        return rename_clusters;
	}
}

struct rename_cluster * model_rename_clusters(struct rename_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths1 = NULL;
	double * cluster_path_depths1  = NULL;
	char ** cluster_filenames1 = NULL;
	char ** cluster_paths1 = NULL;
	double * cluster_path_lengths2 = NULL;
	double * cluster_path_depths2  = NULL;
	char ** cluster_filenames2 = NULL;
	char ** cluster_paths2 = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes1 = NULL;
	int * cluster_file1_owner_ids = NULL;
	int * cluster_file1_group_ids = NULL;
	int * cluster_filemodes2 = NULL;
	int * cluster_file2_owner_ids = NULL;
	int * cluster_file2_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct rename_cluster * rename_clusters = (struct rename_cluster *) calloc(clusters_number, sizeof(struct rename_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths1 = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths1 = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames1 = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths1 = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_path_lengths2 = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths2 = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames2 = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths2 = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes1 = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file1_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file1_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes2 = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file2_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file2_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths1[k] = entries[j].path_length1;
				cluster_path_depths1[k] = entries[j].path_depth1;
				cluster_filenames1[k] = entries[j].filename1;
				cluster_paths1[k] = entries[j].path1;
				cluster_path_lengths2[k] = entries[j].path_length2;
				cluster_path_depths2[k] = entries[j].path_depth2;
				cluster_filenames2[k] = entries[j].filename2;
				cluster_paths2[k] = entries[j].path2;
				cluster_filemodes1[k] = entries[j].filemode1;
				cluster_file1_owner_ids[k] = entries[j].file1_owner_id;
				cluster_file1_group_ids[k] = entries[j].file1_group_id;
				cluster_filemodes2[k] = entries[j].filemode2;
				cluster_file2_owner_ids[k] = entries[j].file2_owner_id;
				cluster_file2_group_ids[k] = entries[j].file2_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths 1:\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths1[j]);
		printf("\nCluster path lengths 1: \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths1[j]);
		rename_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(rename_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(rename_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		rename_clusters[i].path_length_mean1 = mean_double(cluster_path_lengths1, cluster_sizes[i]);
		printf("\nLength mean 1: %f", rename_clusters[i].path_length_mean1);
		rename_clusters[i].path_length_variance1 = variance_double(cluster_path_lengths1, cluster_sizes[i]);
		printf("\nLength variance 1: %f", rename_clusters[i].path_length_variance1);
		rename_clusters[i].path_depth_mean1 = mean_double(cluster_path_depths1, cluster_sizes[i]);
		printf("\nDepth mean 1: %f", rename_clusters[i].path_depth_mean1);
		rename_clusters[i].path_depth_variance1 = variance_double(cluster_path_depths1, cluster_sizes[i]);
		printf("\nDepth variance 1: %f", rename_clusters[i].path_depth_variance1);
		rename_clusters[i].path_length_mean2 = mean_double(cluster_path_lengths2, cluster_sizes[i]);
		printf("\nLength mean2 : %f", rename_clusters[i].path_length_mean2);
		rename_clusters[i].path_length_variance2 = variance_double(cluster_path_lengths2, cluster_sizes[i]);
		printf("\nLength variance2 : %f", rename_clusters[i].path_length_variance2);
		rename_clusters[i].path_depth_mean2 = mean_double(cluster_path_depths2, cluster_sizes[i]);
		printf("\nDepth mean2 : %f", rename_clusters[i].path_depth_mean2);
		rename_clusters[i].path_depth_variance2 = variance_double(cluster_path_depths2, cluster_sizes[i]);
		printf("\nDepth variance2 : %f", rename_clusters[i].path_depth_variance2);

		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&rename_clusters[i].filenames1,cluster_filenames1[j]);
			add_string_uniq(&rename_clusters[i].paths1,cluster_paths1[j]);
			add_string_uniq(&rename_clusters[i].filenames2,cluster_filenames2[j]);
			add_string_uniq(&rename_clusters[i].paths2,cluster_paths2[j]);
			add_integer_uniq(&rename_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&rename_clusters[i].filemodes1, cluster_filemodes1[j]);
			add_integer_uniq(&rename_clusters[i].file1_owner_ids, cluster_file1_owner_ids[j]);
			add_integer_uniq(&rename_clusters[i].file1_group_ids, cluster_file1_group_ids[j]);
			add_integer_uniq(&rename_clusters[i].filemodes2, cluster_filemodes2[j]);
			add_integer_uniq(&rename_clusters[i].file2_owner_ids, cluster_file2_owner_ids[j]);
			add_integer_uniq(&rename_clusters[i].file2_group_ids, cluster_file2_group_ids[j]);
			add_integer_uniq(&rename_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&rename_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&rename_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&rename_clusters[i].egids, cluster_egids[j]);
		}

		rename_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths1);
		free(cluster_path_depths1);
		free(cluster_path_lengths2);
		free(cluster_path_depths2);
		free(cluster_filenames1);
		free(cluster_filenames2);
		free(cluster_paths1);
		free(cluster_paths2);
		free(cluster_retvals);
		free(cluster_filemodes1);
		free(cluster_filemodes2);
		free(cluster_file1_owner_ids);
		free(cluster_file1_group_ids);
		free(cluster_file2_owner_ids);
		free(cluster_file2_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}
	return rename_clusters;
}
	
struct rename_transformed_entry * rename_transform_data(struct rename_entry * entries, int size){
	
	struct rename_transformed_entry * results = (struct rename_transformed_entry *) calloc(size, sizeof(struct rename_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		// Path 1 
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length1+1);
		strncpy(path,entries[i].path1,strlen(entries[i].path1)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth1 = depth;
		if(prev_token != NULL){
				results[i].filename1 = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename1, prev_token, strlen(prev_token));
				results[i].filename1[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename1 = (char *) malloc(1);
			results[i].filename1[0] = '\0';
		}
		free(path);
		// Path 2 	
		results[i].path_length2 = strlen(entries[i].path2);
		path = (char *) malloc(results[i].path_length2+1);
		strncpy(path,entries[i].path2,strlen(entries[i].path2)+1);
		results[i].path2 = path;
		depth = -1;
		path = (char *) malloc(results[i].path_length2+1);
		strncpy(path,entries[i].path2,strlen(entries[i].path2)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth2 = depth;
		if(prev_token != NULL){
				results[i].filename2 = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename2, prev_token, strlen(prev_token));
				results[i].filename2[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename2 = (char *) malloc(1);
			results[i].filename2[0] = '\0';
		}
		free(path);
		results[i].filename2 = prev_token;
		results[i].retValue = entries[i].retValue;
		results[i].filemode1 = entries[i].filemode1;
		results[i].file1_owner_id = entries[i].file1_owner_id;
		results[i].file1_group_id = entries[i].file1_group_id;
		results[i].filemode2 = entries[i].filemode2;
		results[i].file2_owner_id = entries[i].file2_owner_id;
		results[i].file2_group_id = entries[i].file2_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = rename_normalize_data(results, size);
	return results;
}

/**
struct rename_transformed_entry * rename_normalize_data(struct rename_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double rename_entries_distance(struct rename_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct rename_transformed_entry entry1 = entries[index1];
	struct rename_transformed_entry entry2 = entries[index2];
	double min_path_length1 = params[0];
	double max_path_length1 = params[1];
	double min_path_depth1 = params[2];
	double max_path_depth1 = params[3];
	double min_path_distance1 = params[4];
	double max_path_distance1 = params[5];
	double min_path_length2 = params[6];
	double max_path_length2 = params[7];
	double min_path_depth2 = params[8];
	double max_path_depth2 = params[9];
	double min_path_distance2 = params[10];
	double max_path_distance2 = params[11];
	double min_retValue = params[12];
	double max_retValue = params[13];

	double path_length_distance1=0;
	double path_depth_distance1=0;
	double path_distance1=0;
	double path_length_distance2=0;
	double path_depth_distance2=0;
	double path_distance2=0;
	double retvalue_distance=0;
	double filemode1_distance=0;
	double file1_owner_id_distance=0;
	double file1_group_id_distance=0;
	double filemode2_distance=0;
	double file2_owner_id_distance=0;
	double file2_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance1=0;
	double path_exclusion_distance2=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";


	// Compute the components of the distance 

	// Path length component
	if(max_path_length1 != min_path_length1)
		path_length_distance1 = abs(entries[index1].path_length1 - entries[index2].path_length1)/(max_path_length1 - min_path_length1);
	printf("\n Path length 1:1 : %d",entries[index1].path_length1);
	printf("\n Path length 1:2 : %d",entries[index2].path_length1);
	printf("\n Max Path length 1: %f",max_path_length1);
	printf("\n Min Path length 1: %f",min_path_length1);
	printf("\nPath length component 1: %f", path_length_distance1);

	// Path depth component
	if(max_path_depth1 != min_path_depth1)
		path_depth_distance1 = abs(entries[index1].path_depth1 - entries[index2].path_depth1)/(max_path_depth1 - min_path_depth1);
    printf("\n Path depth 1:1 : %d",entries[index1].path_depth1);
	printf("\n Path depth 1:2 : %d",entries[index2].path_depth1);
	printf("\n Max Path depth 1: %f", max_path_depth1);
	printf("\n Min Path depth 1: %f", min_path_depth1);	
	printf("\nDepth component 1: %f", path_depth_distance1);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance1 != min_path_distance1)
		path_distance1 = levenshtein_distance(entries[index1].path1, entries[index2].path1) / (max_path_distance1 - min_path_distance1);
	printf("\n Levenshtein distance 1: %d", levenshtein_distance(entries[index1].path1, entries[index2].path1));
	printf("\n Max path : %f",max_path_distance1);
	printf("\n Min path : %f",min_path_distance1);
	printf("\nPath component : %f", path_distance1);

	// Path length component
	if(max_path_length2 != min_path_length2)
		path_length_distance2 = abs(entries[index1].path_length2 - entries[index2].path_length2)/(max_path_length2 - min_path_length2);
	printf("\n Path length 2:1 : %d",entries[index1].path_length2);
	printf("\n Path length 2:2 : %d",entries[index2].path_length2);
	printf("\n Max Path length 2: %f",max_path_length2);
	printf("\n Min Path length 2: %f",min_path_length2);
	printf("\nPath length component 2: %f", path_length_distance2);

	// Path depth component
	if(max_path_depth2 != min_path_depth2)
		path_depth_distance2 = abs(entries[index1].path_depth2 - entries[index2].path_depth2)/(max_path_depth2 - min_path_depth2);
    printf("\n Path depth 2:1 : %d",entries[index1].path_depth2);
	printf("\n Path depth 2:2 : %d",entries[index2].path_depth2);
	printf("\n Max Path depth 2: %f", max_path_depth2);
	printf("\n Min Path depth 2: %f", min_path_depth2);	
	printf("\nDepth component 2: %f", path_depth_distance2);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance2 != min_path_distance2)
		path_distance2 = levenshtein_distance(entries[index1].path2, entries[index2].path2) / (max_path_distance2 - min_path_distance2);
	printf("\n Levenshtein distance 2: %d", levenshtein_distance(entries[index1].path2, entries[index2].path2));
	printf("\n Max path 2: %f",max_path_distance2);
	printf("\n Min path 2: %f",min_path_distance2);
	printf("\nPath component 2: %f", path_distance2);

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);


    // File 1 mode component
	filemode1_distance = compute_filemode_distance(entries[index1].filemode1, entries[index2].filemode1); 

	// File 1 owner id component
	file1_owner_id_distance = compute_file_owner_id_distance(entries[index1].file1_owner_id, entries[index2].file1_owner_id);

	// File 1 group id component
	file1_group_id_distance = compute_file_group_id_distance(entries[index1].file1_group_id, entries[index2].file1_group_id);

	// File 2 mode component
	filemode2_distance = compute_filemode_distance(entries[index1].filemode2, entries[index2].filemode2); 

	// File 2 owner id component
	file2_owner_id_distance = compute_file_owner_id_distance(entries[index1].file2_owner_id, entries[index2].file2_owner_id);

	// File 2 group id component
	file2_group_id_distance = compute_file_group_id_distance(entries[index1].file2_group_id, entries[index2].file2_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance1 = compute_path_exclusion_distance(entries[index1].path1, entries[index2].path1, exclusion_regexps, nbr_regexps);

	// Path exclusion component
	path_exclusion_distance2 = compute_path_exclusion_distance(entries[index1].path2, entries[index2].path2, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH1_WEIGHT*path_length_distance1 + DEPTH1_WEIGHT*path_depth_distance1 + FILENAME1_WEIGHT*path_distance1 + LENGTH2_WEIGHT*path_length_distance2 + DEPTH2_WEIGHT*path_depth_distance2 + FILENAME2_WEIGHT*path_distance2 + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode1_distance + FILE_OWNER_ID_WEIGHT*file1_owner_id_distance + FILE_GROUP_ID_WEIGHT*file1_group_id_distance + FILEMODE_WEIGHT*filemode2_distance + FILE_OWNER_ID_WEIGHT*file2_owner_id_distance + FILE_GROUP_ID_WEIGHT*file2_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance1 + PATH_EXCLUSION_WEIGHT*path_exclusion_distance2) / (LENGTH1_WEIGHT + DEPTH1_WEIGHT + FILENAME1_WEIGHT + LENGTH2_WEIGHT + DEPTH2_WEIGHT + FILENAME2_WEIGHT + RETVALUE_WEIGHT + 2*FILEMODE_WEIGHT + 2*FILE_OWNER_ID_WEIGHT + 2*FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + 2*PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct rename_cluster rename_match_entry_to_cluster(struct rename_cluster * clusters, int clusters_number, struct rename_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length 1 : Chebyshev's inequality for upper bound
		if (entry.path_length1 != clusters[i].path_length_mean1){
			if(clusters[i].path_length_variance1 != 0){
				temp = 1 - (clusters[i].path_length_variance1/pow((entry.path_length1 - clusters[i].path_length_mean1),2));
				if (temp > 0){
					distances[i] += LENGTH1_WEIGHT*temp;
					printf("\nPath1 length component : %f",LENGTH1_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length1 - clusters[i].path_length_mean1)*99;
				printf("\nPath1 length component : %f",fabs(entry.path_length1 - clusters[i].path_length_mean1)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth 1 : Chebyshev's inequality for upper bound
		if (entry.path_depth1 != clusters[i].path_depth_mean1){
			if(clusters[i].path_length_variance1 != 0){
				temp = 1 - (clusters[i].path_depth_variance1/pow((entry.path_depth1 - clusters[i].path_depth_mean1),2));
				if (temp > 0){
					distances[i] += DEPTH1_WEIGHT*temp; 
					printf("\nPath 1 depth component : %f",DEPTH1_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth1 - clusters[i].path_depth_mean1)*99;
				printf("\nPath 1 depth component : %f",fabs(entry.path_depth1 - clusters[i].path_depth_mean1)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths1,0)->string, entry.path1);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths1); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths1,j)->string, entry.path1);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath 1 component : %f",FILENAME1_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME1_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
	
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length2 != clusters[i].path_length_mean2){
			if(clusters[i].path_length_variance2 != 0){
				temp = 1 - (clusters[i].path_length_variance2/pow((entry.path_length2 - clusters[i].path_length_mean2),2));
				if (temp > 0){
					distances[i] += LENGTH2_WEIGHT*temp;
					printf("\nPath 2 length component : %f",LENGTH2_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length2 - clusters[i].path_length_mean2)*99;
				printf("\nPath 2 length component : %f",fabs(entry.path_length2 - clusters[i].path_length_mean2)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth2 != clusters[i].path_depth_mean2){
			if(clusters[i].path_length_variance2 != 0){
				temp = 1 - (clusters[i].path_depth_variance2/pow((entry.path_depth2 - clusters[i].path_depth_mean2),2));
				if (temp > 0){
					distances[i] += DEPTH2_WEIGHT*temp; 
					printf("\nPath 2 depth component : %f",DEPTH2_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth2 - clusters[i].path_depth_mean2)*99;
				printf("\nPath 2 depth component : %f",fabs(entry.path_depth2 - clusters[i].path_depth_mean2)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths2,0)->string, entry.path2);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths2); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths2,j)->string, entry.path2);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath 2 component : %f",FILENAME2_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME2_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File 1 owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file1_owner_ids,entry.file1_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File 1 group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file1_group_ids,entry.file1_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File 1 mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes1,entry.filemode1))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// File 2 owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file2_owner_ids,entry.file2_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File 2 group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file2_group_ids,entry.file2_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File 2 mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes2,entry.filemode2))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);


	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for IOCTL system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Command | Arg | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Command , Arg , Return_value : Custom distance
#########################################################################################
**/


struct ioctl_cluster* ioctl_cluster(struct ioctl_entry * entries, int size, int *max_clusters_number){

	struct ioctl_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[12];
	double lengths[size];
	double depths[size];
	double commands[size];
	double args[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_ioctl_clusters = NULL;
	struct ioctl_cluster * ioctl_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = ioctl_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("Command : %d\n", results[i].command);
				printf("Args : %d\n",results[i].arg);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			commands[i] = results[i].command;
			args[i] = results[i].arg;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(commands, size, false);
		params[5] = min_max_double(commands, size, true);
		params[6] = min_max_double(args, size, false);
		params[7] = min_max_double(args, size, true);
		params[8] = min_max_double(retVals, size, false);
		params[9] = min_max_double(retVals, size, true);
		params[10] = min_max_string(paths, size, false);
		params[11] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = ioctl_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_ioctl_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_ioctl_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		ioctl_clusters = model_ioctl_clusters(results, size, raw_ioctl_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",ioctl_clusters[i].syscall);
			printf("Path length mean : %f \n", ioctl_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", ioctl_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", ioctl_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", ioctl_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(ioctl_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(ioctl_clusters[i].paths);
			printf("Commands : \n");
			walk_integers(ioctl_clusters[i].commands);
			printf("Args : \n");
			walk_integers(ioctl_clusters[i].args);
			printf("RetValues : \n");
			walk_integers(ioctl_clusters[i].retValues);
			printf("########################################\n");
		}

		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_ioctl_clusters[i]);
		free(raw_ioctl_clusters);

        return ioctl_clusters;
	}
}

struct ioctl_cluster * model_ioctl_clusters(struct ioctl_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_commands = NULL;
	int * cluster_args = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct ioctl_cluster * ioctl_clusters = (struct ioctl_cluster *) calloc(clusters_number, sizeof(struct ioctl_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_commands = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_args = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_commands[k] = entries[j].command;
				cluster_args[k] = entries[j].arg;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;

				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		ioctl_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(ioctl_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(ioctl_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		ioctl_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", ioctl_clusters[i].path_length_mean);
		ioctl_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", ioctl_clusters[i].path_length_variance);
		ioctl_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", ioctl_clusters[i].path_depth_mean);
		ioctl_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", ioctl_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&ioctl_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&ioctl_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&ioctl_clusters[i].commands, cluster_commands[j]);
			add_integer_uniq(&ioctl_clusters[i].args, cluster_args[j]);
			add_integer_uniq(&ioctl_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&ioctl_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&ioctl_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&ioctl_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&ioctl_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&ioctl_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&ioctl_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&ioctl_clusters[i].egids, cluster_egids[j]);

		}
		ioctl_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_args);
		free(cluster_commands);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return ioctl_clusters;
}
	
struct ioctl_transformed_entry * ioctl_transform_data(struct ioctl_entry * entries, int size){
	
	struct ioctl_transformed_entry * results = (struct ioctl_transformed_entry *) calloc(size, sizeof(struct ioctl_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].command = entries[i].command;
		results[i].arg = entries[i].arg;
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
	}

    //results = ioctl_normalize_data(results, size);
	return results;
}

/**
struct ioctl_transformed_entry * ioctl_normalize_data(struct ioctl_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double ioctl_entries_distance(struct ioctl_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct ioctl_transformed_entry entry1 = entries[index1];
	struct ioctl_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_command = params[4];
	double max_command = params[5];
	double min_arg = params[6];
	double max_arg = params[7];
	double min_retValue = params[8];
	double max_retValue = params[9];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[10];
	double max_path_distance = params[11];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double command_distance=0;
	double arg_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";


	// Compute the components of the distance 

	// Path length component
	if (max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if (max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if (max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);

	// Command component
	if (max_command != min_command)
		command_distance = abs(entries[index1].command - entries[index2].command)/(max_command - min_command);
	printf("\n Max command : %f",max_command);
	printf("\n Min command : %f", min_command);
	printf("\n Command component : %f", command_distance);

	// Arg component
	if (max_arg != min_arg)
		arg_distance = abs(entries[index1].arg - entries[index2].arg)/(max_arg - min_arg);
	printf("\n Max Arg : %f",max_arg);
	printf("\n Min Arg : %f", min_arg);
	printf("\n Arg component : %f", arg_distance);

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + ARG_WEIGHT*arg_distance + COMMAND_WEIGHT*command_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + RGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + ARG_WEIGHT + COMMAND_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct ioctl_cluster ioctl_match_entry_to_cluster(struct ioctl_cluster * clusters, int clusters_number, struct ioctl_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}

	// Command : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].commands,entry.command))
			distances[i] += COMMAND_WEIGHT*1;

		printf("\nCurrent distance (command) : %f", distances[i]);
		
	// Arg : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].args,entry.arg))
			distances[i] += ARG_WEIGHT*1;

		printf("\nCurrent distance (arg) : %f", distances[i]);

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for FCNTL system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Command | Arg | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Command , Return_value : Custom distance
#########################################################################################
**/


struct fcntl_cluster* fcntl_cluster(struct fcntl_entry * entries, int size, int *max_clusters_number){

	struct fcntl_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[10];
	double lengths[size];
	double depths[size];
	double commands[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_fcntl_clusters = NULL;
	struct fcntl_cluster * fcntl_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = fcntl_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("Command : %d\n", results[i].command);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			commands[i] = results[i].command;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(commands, size, false);
		params[5] = min_max_double(commands, size, true);
		params[6] = min_max_double(retVals, size, false);
		params[7] = min_max_double(retVals, size, true);
		params[8] = min_max_string(paths, size, false);
		params[9] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = fcntl_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_fcntl_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_fcntl_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		fcntl_clusters = model_fcntl_clusters(results, size, raw_fcntl_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",fcntl_clusters[i].syscall);
			printf("Path length mean : %f \n", fcntl_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", fcntl_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", fcntl_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", fcntl_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(fcntl_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(fcntl_clusters[i].paths);
			printf("Commands : \n");
			walk_integers(fcntl_clusters[i].commands);
			printf("RetValues : \n");
			walk_integers(fcntl_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_fcntl_clusters[i]);
		free(raw_fcntl_clusters);

        return fcntl_clusters;
	}
}

struct fcntl_cluster * model_fcntl_clusters(struct fcntl_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_commands = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;


	struct fcntl_cluster * fcntl_clusters = (struct fcntl_cluster *) calloc(clusters_number, sizeof(struct fcntl_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_commands = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_commands[k] = entries[j].command;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		fcntl_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(fcntl_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(fcntl_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		fcntl_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", fcntl_clusters[i].path_length_mean);
		fcntl_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", fcntl_clusters[i].path_length_variance);
		fcntl_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", fcntl_clusters[i].path_depth_mean);
		fcntl_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", fcntl_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&fcntl_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&fcntl_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&fcntl_clusters[i].commands, cluster_commands[j]);
			add_integer_uniq(&fcntl_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&fcntl_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&fcntl_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&fcntl_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&fcntl_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&fcntl_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&fcntl_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&fcntl_clusters[i].egids, cluster_egids[j]);

		}
		fcntl_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_commands);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
		free(cluster_retvals);
		free(cluster_paths);
	}

	return fcntl_clusters;
}
	
struct fcntl_transformed_entry * fcntl_transform_data(struct fcntl_entry * entries, int size){
	
	struct fcntl_transformed_entry * results = (struct fcntl_transformed_entry *) calloc(size, sizeof(struct fcntl_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].command = entries[i].command;
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;
	}

    //results = fcntl_normalize_data(results, size);
	return results;
}

/**
struct fcntl_transformed_entry * fcntl_normalize_data(struct fcntl_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double fcntl_entries_distance(struct fcntl_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct fcntl_transformed_entry entry1 = entries[index1];
	struct fcntl_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_command = params[4];
	double max_command = params[5];
	double min_retValue = params[6];
	double max_retValue = params[7];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[8];
	double max_path_distance = params[9];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double command_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";



	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);

	// Command component
	if(max_command != min_command)
		command_distance = abs(entries[index1].command - entries[index2].command)/(max_command - min_command);
	printf("\n Max command : %f",max_command);
	printf("\n Min command : %f", min_command);
	printf("\n Command component : %f", command_distance);

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + COMMAND_WEIGHT*command_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + COMMAND_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct fcntl_cluster fcntl_match_entry_to_cluster(struct fcntl_cluster * clusters, int clusters_number, struct fcntl_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}

	// Command : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].commands,entry.command))
			distances[i] += COMMAND_WEIGHT*1;

		printf("\nCurrent distance (command) : %f", distances[i]);
		
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for GETMSG system call
# Sample format : Sycall | Filedes | Flags | Return_value
# Distances : Syscall : x ; Address : Custom ; Length : Custom ; Return_value : Custom
#########################################################################################
**/


struct getmsg_cluster* getmsg_cluster(struct getmsg_entry * entries, int size, int *max_clusters_number){

	struct getmsg_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[6];
	double filedess[size];
	double flags[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_getmsg_clusters = NULL;
	struct getmsg_cluster * getmsg_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = getmsg_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Filedes : %d\n", results[i].filedes);
				printf("Flags : %d\n", results[i].flags);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			filedess[i] = results[i].filedes;
			flags[i] = results[i].flags;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(filedess, size, false);
		params[1] = min_max_double(filedess, size, true);
		params[2] = min_max_double(flags, size, false);
		params[3] = min_max_double(flags, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = getmsg_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_getmsg_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_getmsg_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		getmsg_clusters = model_getmsg_clusters(results, size, raw_getmsg_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",getmsg_clusters[i].syscall);
			printf("Filedess : \n");
			walk_integers(getmsg_clusters[i].filedess);
			printf("Flags : \n");
			walk_integers(getmsg_clusters[i].flags);
			printf("RetValues : \n");
			walk_integers(getmsg_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_getmsg_clusters[i]);
		free(raw_getmsg_clusters);

        return getmsg_clusters;
	}
}

struct getmsg_cluster * model_getmsg_clusters(struct getmsg_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_filedess = NULL;
	int * cluster_flags = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;


	struct getmsg_cluster * getmsg_clusters = (struct getmsg_cluster *) calloc(clusters_number, sizeof(struct getmsg_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_filedess = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_flags = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_filedess[k] = entries[j].filedes;
				cluster_flags[k] = entries[j].flags;
				cluster_retvals[k++] = entries[j].retValue;
			}
		getmsg_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(getmsg_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(getmsg_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&getmsg_clusters[i].filedess,cluster_filedess[j]);
			add_integer_uniq(&getmsg_clusters[i].flags,cluster_flags[j]);
			add_integer_uniq(&getmsg_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&getmsg_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&getmsg_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&getmsg_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&getmsg_clusters[i].egids, cluster_egids[j]);
		}
		getmsg_clusters[i].cluster_size = cluster_sizes[i];

		free(cluster_filedess);
		free(cluster_flags);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return getmsg_clusters;
}
	
struct getmsg_transformed_entry * getmsg_transform_data(struct getmsg_entry * entries, int size){
	
	struct getmsg_transformed_entry * results = (struct getmsg_transformed_entry *) calloc(size, sizeof(struct getmsg_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].filedes = entries[i].filedes;
		results[i].flags = entries[i].flags;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;

	}

    //results = getmsg_normalize_data(results, size);
	return results;
}

/**
struct getmsg_transformed_entry * getmsg_normalize_data(struct getmsg_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_getmsgs_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_getmsgs_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_getmsgs_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_getmsgs_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_getmsgs_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_getmsgs_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double getmsg_entries_distance(struct getmsg_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct getmsg_transformed_entry entry1 = entries[index1];
	struct getmsg_transformed_entry entry2 = entries[index2];
	double min_filedes = params[0];
	double max_filedes = params[1];
	double min_flags = params[2];
	double max_flags = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	double filedes_distance = 0;
	double flags_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Filedes component
	if(max_filedes != min_filedes){
		filedes_distance = abs(entries[index1].filedes - entries[index2].filedes)/(max_filedes - min_filedes);
		printf("\n Max Filedes : %f",max_filedes);
		printf("\n Min Filedes : %f", min_filedes);
		printf("\n Filedes component : %f", filedes_distance);
	}

	// Flags component
	if(max_flags != min_flags){
		flags_distance = abs(entries[index1].flags - entries[index2].flags)/(max_flags - min_flags);
		printf("\n Max Flags : %f",max_flags);
		printf("\n Min Flags : %f", min_flags);
		printf("\n Flags component : %f", flags_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);


/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (FILEDES_WEIGHT*filedes_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT);

	return distance;
}

struct getmsg_cluster getmsg_match_entry_to_cluster(struct getmsg_cluster * clusters, int clusters_number, struct getmsg_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Filedes : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filedess,entry.filedes))
			distances[i] += FILEDES_WEIGHT*1;

		printf("\nCurrent distance (filedes) : %f", distances[i]);

	// Length : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].flags,entry.flags))
			distances[i] += FLAGS_WEIGHT*1;

		printf("\nCurrent distance (flag) : %f", distances[i]);

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);


	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for SETUID system call
# Sample format : Sycall | Uid | Return_value
# Distances : Syscall : x ; Uid : Custom ; Return_value : Custom
#########################################################################################
**/


struct setuid_cluster* setuid_cluster(struct setuid_entry * entries, int size, int *max_clusters_number){

	struct setuid_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[4];
	double uids[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_setuid_clusters = NULL;
	struct setuid_cluster * setuid_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = setuid_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Uid : %d\n", results[i].uid);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			uids[i] = results[i].uid;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(uids, size, false);
		params[1] = min_max_double(uids, size, true);
		params[2] = min_max_double(retVals, size, false);
		params[3] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = setuid_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_setuid_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_setuid_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		setuid_clusters = model_setuid_clusters(results, size, raw_setuid_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",setuid_clusters[i].syscall);
			printf("Uids : \n");
			walk_integers(setuid_clusters[i].uids);
			printf("RetValues : \n");
			walk_integers(setuid_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_setuid_clusters[i]);
		free(raw_setuid_clusters);

        return setuid_clusters;
	}
}

struct setuid_cluster * model_setuid_clusters(struct setuid_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_uids = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct setuid_cluster * setuid_clusters = (struct setuid_cluster *) calloc(clusters_number, sizeof(struct setuid_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_uids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_uids[k] = entries[j].uid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		setuid_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(setuid_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(setuid_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&setuid_clusters[i].uids,cluster_uids[j]);
			add_integer_uniq(&setuid_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&setuid_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&setuid_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&setuid_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&setuid_clusters[i].egids, cluster_egids[j]);

		}
		
		free(cluster_uids);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);

		setuid_clusters[i].cluster_size = cluster_sizes[i];
	}

	return setuid_clusters;
}
	
struct setuid_transformed_entry * setuid_transform_data(struct setuid_entry * entries, int size){
	
	struct setuid_transformed_entry * results = (struct setuid_transformed_entry *) calloc(size, sizeof(struct setuid_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].uid = entries[i].uid;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;

	}

    //results = setuid_normalize_data(results, size);
	return results;
}

/**
struct setuid_transformed_entry * setuid_normalize_data(struct setuid_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_setuids_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_setuids_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_setuids_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_setuids_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_setuids_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_setuids_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double setuid_entries_distance(struct setuid_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct setuid_transformed_entry entry1 = entries[index1];
	struct setuid_transformed_entry entry2 = entries[index2];
	double min_uid = params[0];
	double max_uid = params[1];
	double min_retValue = params[2];
	double max_retValue = params[3];
	double uid_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Filedes component
	if(max_uid != min_uid){
		uid_distance = abs(entries[index1].uid - entries[index2].uid)/(max_uid - min_uid);
		printf("\n Max Uid : %f",max_uid);
		printf("\n Min Uid : %f", min_uid);
		printf("\n Uid component : %f", uid_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);


	// Compute final distance 
	distance = (UID_WEIGHT*uid_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct setuid_cluster setuid_match_entry_to_cluster(struct setuid_cluster * clusters, int clusters_number, struct setuid_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Uid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].uids,entry.uid))
			distances[i] += UID_WEIGHT*1;

		printf("\nCurrent distance (uid) : %f", distances[i]);


	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);


	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for VFORK system call
# Sample format : Sycall | pid | Return_value
# Distances : Syscall : x ; Pid : Custom ; Return_value : Custom
#########################################################################################
**/


struct vfork_cluster* vfork_cluster(struct vfork_entry * entries, int size, int *max_clusters_number){

	struct vfork_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[4];
	double pids[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_vfork_clusters = NULL;
	struct vfork_cluster * vfork_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = vfork_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Pid : %d\n", results[i].pid);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			pids[i] = results[i].pid;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(pids, size, false);
		params[1] = min_max_double(pids, size, true);
		params[2] = min_max_double(retVals, size, false);
		params[3] = min_max_double(retVals, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = vfork_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_vfork_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_vfork_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		vfork_clusters = model_vfork_clusters(results, size, raw_vfork_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",vfork_clusters[i].syscall);
			printf("Pids : \n");
			walk_integers(vfork_clusters[i].pids);
			printf("RetValues : \n");
			walk_integers(vfork_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_vfork_clusters[i]);
		free(raw_vfork_clusters);
       
		 return vfork_clusters;
	}
}

struct vfork_cluster * model_vfork_clusters(struct vfork_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_pids = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;
	struct vfork_cluster * vfork_clusters = (struct vfork_cluster *) calloc(clusters_number, sizeof(struct vfork_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_pids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_pids[k] = entries[j].pid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		vfork_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(vfork_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(vfork_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&vfork_clusters[i].pids,cluster_pids[j]);
			add_integer_uniq(&vfork_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&vfork_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&vfork_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&vfork_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&vfork_clusters[i].egids, cluster_egids[j]);

		}
		vfork_clusters[i].cluster_size = cluster_sizes[i];

		free(cluster_pids);
		free(cluster_retvals);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return vfork_clusters;
}
	
struct vfork_transformed_entry * vfork_transform_data(struct vfork_entry * entries, int size){
	
	struct vfork_transformed_entry * results = (struct vfork_transformed_entry *) calloc(size, sizeof(struct vfork_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].pid = entries[i].pid;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;

	}

    //results = vfork_normalize_data(results, size);
	return results;
}

/**
struct vfork_transformed_entry * vfork_normalize_data(struct vfork_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_vforks_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_vforks_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_vforks_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_vforks_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_vforks_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_vforks_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double vfork_entries_distance(struct vfork_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct vfork_transformed_entry entry1 = entries[index1];
	struct vfork_transformed_entry entry2 = entries[index2];
	double min_pid = params[0];
	double max_pid = params[1];
	double min_retValue = params[2];
	double max_retValue = params[3];
	double pid_distance = 0;
	double retvalue_distance = 0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;


	// Compute the components of the distance 

	// Filedes component
	if(max_pid != min_pid){
		pid_distance = abs(entries[index1].pid - entries[index2].pid)/(max_pid - min_pid);
		printf("\n Max Pid : %f",max_pid);
		printf("\n Min Pid : %f", min_pid);
		printf("\n Pid component : %f", pid_distance);
	}

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);


/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (PID_WEIGHT*pid_distance + RETVALUE_WEIGHT*retvalue_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance)/(FILEDES_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT);

	return distance;
}

struct vfork_cluster vfork_match_entry_to_cluster(struct vfork_cluster * clusters, int clusters_number, struct vfork_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;

	// Pid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].pids,entry.pid))
			distances[i] += PID_WEIGHT*1;

		printf("\nCurrent distance (pid) : %f", distances[i]);


	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for CHOWN system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Owner | Group | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Owner , Group , Return_value : Custom distance
#########################################################################################
**/


struct chown_cluster* chown_cluster(struct chown_entry * entries, int size, int *max_clusters_number){

	struct chown_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[12];
	double lengths[size];
	double depths[size];
	double owners[size];
	double groups[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_chown_clusters = NULL;
	struct chown_cluster * chown_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = chown_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("Owner : %d\n", results[i].owner);
				printf("Groups : %d\n",results[i].group);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			owners[i] = results[i].owner;
			groups[i] = results[i].group;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(owners, size, false);
		params[5] = min_max_double(owners, size, true);
		params[6] = min_max_double(groups, size, false);
		params[7] = min_max_double(groups, size, true);
		params[8] = min_max_double(retVals, size, false);
		params[9] = min_max_double(retVals, size, true);
		params[10] = min_max_string(paths, size, false);
		params[11] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = chown_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_chown_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_chown_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		chown_clusters = model_chown_clusters(results, size, raw_chown_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",chown_clusters[i].syscall);
			printf("Path length mean : %f \n", chown_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", chown_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", chown_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", chown_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(chown_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(chown_clusters[i].paths);
			printf("Owners : \n");
			walk_integers(chown_clusters[i].owners);
			printf("Groups : \n");
			walk_integers(chown_clusters[i].groups);
			printf("RetValues : \n");
			walk_integers(chown_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_chown_clusters[i]);
		free(raw_chown_clusters);
        return chown_clusters;
	}
}

struct chown_cluster * model_chown_clusters(struct chown_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_owners = NULL;
	int * cluster_groups = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct chown_cluster * chown_clusters = (struct chown_cluster *) calloc(clusters_number, sizeof(struct chown_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_owners = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_groups = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_owners[k] = entries[j].owner;
				cluster_groups[k] = entries[j].group;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		chown_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(chown_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(chown_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		chown_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", chown_clusters[i].path_length_mean);
		chown_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", chown_clusters[i].path_length_variance);
		chown_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", chown_clusters[i].path_depth_mean);
		chown_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", chown_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&chown_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&chown_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&chown_clusters[i].owners, cluster_owners[j]);
			add_integer_uniq(&chown_clusters[i].groups, cluster_groups[j]);
			add_integer_uniq(&chown_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&chown_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&chown_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&chown_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&chown_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&chown_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&chown_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&chown_clusters[i].egids, cluster_egids[j]);

		}
		chown_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_owners);
		free(cluster_groups);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return chown_clusters;
}
	
struct chown_transformed_entry * chown_transform_data(struct chown_entry * entries, int size){
	
	struct chown_transformed_entry * results = (struct chown_transformed_entry *) calloc(size, sizeof(struct chown_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].owner = entries[i].owner;
		results[i].group = entries[i].group;
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = chown_normalize_data(results, size);
	return results;
}

/**
struct chown_transformed_entry * chown_normalize_data(struct chown_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double chown_entries_distance(struct chown_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct chown_transformed_entry entry1 = entries[index1];
	struct chown_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_owner = params[4];
	double max_owner = params[5];
	double min_group = params[6];
	double max_group = params[7];
	double min_retValue = params[8];
	double max_retValue = params[9];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[10];
	double max_path_distance = params[11];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double owner_distance=0;
	double group_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";




	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);

	// Owner component
	if(max_owner != min_owner)
		owner_distance = abs(entries[index1].owner - entries[index2].owner)/(max_owner - min_owner);
	printf("\n Max owner : %f",max_owner);
	printf("\n Min owner : %f", min_owner);
	printf("\n Owner component : %f", owner_distance);

	// Group component
	if(max_group != min_group)
		group_distance = abs(entries[index1].group - entries[index2].group)/(max_group - min_group);
	printf("\n Max Group : %f",max_group);
	printf("\n Min Group : %f", min_group);
	printf("\n Group component : %f", group_distance);

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + GROUP_WEIGHT*group_distance + OWNER_WEIGHT*owner_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + GROUP_WEIGHT + OWNER_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + RGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct chown_cluster chown_match_entry_to_cluster(struct chown_cluster * clusters, int clusters_number, struct chown_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}

	// Owner : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].owners,entry.owner))
			distances[i] += OWNER_WEIGHT*1;

		printf("\nCurrent distance (owner) : %f", distances[i]);
		
	// Group : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].groups,entry.group))
			distances[i] += GROUP_WEIGHT*1;

		printf("\nCurrent distance (group) : %f", distances[i]);

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for CHROOT system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct chroot_cluster* chroot_cluster(struct chroot_entry * entries, int size, int *max_clusters_number){

	struct chroot_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_chroot_clusters = NULL;
	struct chroot_cluster * chroot_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = chroot_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = chroot_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_chroot_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_chroot_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		chroot_clusters = model_chroot_clusters(results, size, raw_chroot_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",chroot_clusters[i].syscall);
			printf("Path length mean : %f \n", chroot_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", chroot_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", chroot_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", chroot_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(chroot_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(chroot_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(chroot_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_chroot_clusters[i]);
		free(raw_chroot_clusters);

        return chroot_clusters;
	}
}

struct chroot_cluster * model_chroot_clusters(struct chroot_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct chroot_cluster * chroot_clusters = (struct chroot_cluster *) calloc(clusters_number, sizeof(struct chroot_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;

				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		chroot_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(chroot_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(chroot_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		chroot_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", chroot_clusters[i].path_length_mean);
		chroot_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", chroot_clusters[i].path_length_variance);
		chroot_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", chroot_clusters[i].path_depth_mean);
		chroot_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", chroot_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&chroot_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&chroot_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&chroot_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&chroot_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&chroot_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&chroot_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&chroot_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&chroot_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&chroot_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&chroot_clusters[i].egids, cluster_egids[j]);

		}
		chroot_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return chroot_clusters;
}
	
struct chroot_transformed_entry * chroot_transform_data(struct chroot_entry * entries, int size){
	
	struct chroot_transformed_entry * results = (struct chroot_transformed_entry *) calloc(size, sizeof(struct chroot_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = chroot_normalize_data(results, size);
	return results;
}

/**
struct chroot_transformed_entry * chroot_normalize_data(struct chroot_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double chroot_entries_distance(struct chroot_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct chroot_transformed_entry entry1 = entries[index1];
	struct chroot_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";




	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct chroot_cluster chroot_match_entry_to_cluster(struct chroot_cluster * clusters, int clusters_number, struct chroot_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}
			
	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for FCHOWN system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Owner | Group | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Owner , Group , Return_value : Custom distance
#########################################################################################
**/


struct fchown_cluster* fchown_cluster(struct fchown_entry * entries, int size, int *max_clusters_number){

	struct fchown_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[12];
	double lengths[size];
	double depths[size];
	double owners[size];
	double groups[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_fchown_clusters = NULL;
	struct fchown_cluster * fchown_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = fchown_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("PathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("Owner : %d\n", results[i].owner);
				printf("Groups : %d\n",results[i].group);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			owners[i] = results[i].owner;
			groups[i] = results[i].group;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(owners, size, false);
		params[5] = min_max_double(owners, size, true);
		params[6] = min_max_double(groups, size, false);
		params[7] = min_max_double(groups, size, true);
		params[8] = min_max_double(retVals, size, false);
		params[9] = min_max_double(retVals, size, true);
		params[10] = min_max_string(paths, size, false);
		params[11] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = fchown_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_fchown_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_fchown_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		fchown_clusters = model_fchown_clusters(results, size, raw_fchown_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",fchown_clusters[i].syscall);
			printf("Path length mean : %f \n", fchown_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", fchown_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", fchown_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", fchown_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(fchown_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(fchown_clusters[i].paths);
			printf("Owners : \n");
			walk_integers(fchown_clusters[i].owners);
			printf("Groups : \n");
			walk_integers(fchown_clusters[i].groups);
			printf("RetValues : \n");
			walk_integers(fchown_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_fchown_clusters[i]);
		free(raw_fchown_clusters);

        return fchown_clusters;
	}
}

struct fchown_cluster * model_fchown_clusters(struct fchown_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_owners = NULL;
	int * cluster_groups = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct fchown_cluster * fchown_clusters = (struct fchown_cluster *) calloc(clusters_number, sizeof(struct fchown_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_owners = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_groups = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_owners[k] = entries[j].owner;
				cluster_groups[k] = entries[j].group;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		fchown_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(fchown_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(fchown_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		fchown_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", fchown_clusters[i].path_length_mean);
		fchown_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", fchown_clusters[i].path_length_variance);
		fchown_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", fchown_clusters[i].path_depth_mean);
		fchown_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", fchown_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&fchown_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&fchown_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&fchown_clusters[i].owners, cluster_owners[j]);
			add_integer_uniq(&fchown_clusters[i].groups, cluster_groups[j]);
			add_integer_uniq(&fchown_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&fchown_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&fchown_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&fchown_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&fchown_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&fchown_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&fchown_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&fchown_clusters[i].egids, cluster_egids[j]);

		}
		fchown_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_groups);
		free(cluster_retvals);	
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);

	}

	return fchown_clusters;
}
	
struct fchown_transformed_entry * fchown_transform_data(struct fchown_entry * entries, int size){
	
	struct fchown_transformed_entry * results = (struct fchown_transformed_entry *) calloc(size, sizeof(struct fchown_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);
		results[i].owner = entries[i].owner;
		results[i].group = entries[i].group;
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = fchown_normalize_data(results, size);
	return results;
}

/**
struct fchown_transformed_entry * fchown_normalize_data(struct fchown_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double fchown_entries_distance(struct fchown_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct fchown_transformed_entry entry1 = entries[index1];
	struct fchown_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_owner = params[4];
	double max_owner = params[5];
	double min_group = params[6];
	double max_group = params[7];
	double min_retValue = params[8];
	double max_retValue = params[9];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[10];
	double max_path_distance = params[11];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double owner_distance=0;
	double group_distance=0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";




	// Compute the components of the distance 

	// Path length component
	if(max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if(max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if(max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);

	// Owner component
	if(max_owner != min_owner)
		owner_distance = abs(entries[index1].owner - entries[index2].owner)/(max_owner - min_owner);
	printf("\n Max owner : %f",max_owner);
	printf("\n Min owner : %f", min_owner);
	printf("\n Owner component : %f", owner_distance);

	// Group component
	if(max_group != min_group)
		group_distance = abs(entries[index1].group - entries[index2].group)/(max_group - min_group);
	printf("\n Max Group : %f",max_group);
	printf("\n Min Group : %f", min_group);
	printf("\n Group component : %f", group_distance);

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + RETVALUE_WEIGHT*retvalue_distance + GROUP_WEIGHT*group_distance + OWNER_WEIGHT*owner_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT + GROUP_WEIGHT + OWNER_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT);

	return distance;
}

struct fchown_cluster fchown_match_entry_to_cluster(struct fchown_cluster * clusters, int clusters_number, struct fchown_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

	// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

	// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}

	// Owner : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].owners,entry.owner))
			distances[i] += OWNER_WEIGHT*1;

		printf("\nCurrent distance (owner) : %f", distances[i]);
		
	// Group : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].groups,entry.group))
			distances[i] += GROUP_WEIGHT*1;

		printf("\nCurrent distance (group) : %f", distances[i]);

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

	// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


	// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for SOCKCONNECT system call
# Sample format : Sycall Socket_type | port | address | fd | priority | Return_value
# Distances : Syscall : x ; Socket type, port, address, fd, priority, Return_value : Custom distance
#########################################################################################
**/


struct sockconnect_cluster* sockconnect_cluster(struct sockconnect_entry * entries, int size, int *max_clusters_number){

	struct sockconnect_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[12];
	double socket_types[size];
	double ports[size];
	double addresses[size];
	double fds[size];
	double priorities[size];
	double retVals[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_sockconnect_clusters = NULL;
	struct sockconnect_cluster * sockconnect_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = sockconnect_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("Socket type : %d\n", results[i].socket_type);
				printf("Port : %d\n",results[i].port);
				printf("Address : %d\n",results[i].address);
				printf("File des : %d\n", results[i].fd);
				printf("Priority : %d\n",results[i].priority);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			socket_types[i] = results[i].socket_type;
			ports[i] = results[i].port;
			addresses[i] = results[i].address;
			fds[i] = results[i].fd;
			priorities[i] = results[i].priority;
			retVals[i] = results[i].retValue;
		}
		params[0] = min_max_double(socket_types, size, false);
		params[1] = min_max_double(socket_types, size, true);
		params[2] = min_max_double(ports, size, false);
		params[3] = min_max_double(ports, size, true);
		params[4] = min_max_double(addresses, size, false);
		params[5] = min_max_double(addresses, size, true);
		params[6] = min_max_double(fds, size, false);
		params[7] = min_max_double(fds, size, true);
		params[8] = min_max_double(priorities, size, false);
		params[9] = min_max_double(priorities, size, true);
		params[10] = min_max_double(retVals, size, false);
		params[11] = min_max_double(retVals, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = sockconnect_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_sockconnect_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
		raw_sockconnect_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		sockconnect_clusters = model_sockconnect_clusters(results, size, raw_sockconnect_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",sockconnect_clusters[i].syscall);
			printf("Socket types : \n");
			walk_integers(sockconnect_clusters[i].socket_types);
			printf("Ports : \n");
			walk_integers(sockconnect_clusters[i].ports);
			printf("Addresses : \n");
			walk_integers(sockconnect_clusters[i].addresses);
			printf("File des : \n");
			walk_integers(sockconnect_clusters[i].fds);
			printf("Priorities : \n");
			walk_integers(sockconnect_clusters[i].priorities);
			printf("RetValues : \n");
			walk_integers(sockconnect_clusters[i].retValues);
			printf("########################################\n");
		}

 		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++)
			free(results[i].syscall);
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_sockconnect_clusters[i]);
		free(raw_sockconnect_clusters);

        return sockconnect_clusters;
	}
}

struct sockconnect_cluster * model_sockconnect_clusters(struct sockconnect_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	int * cluster_socket_types = NULL;
	int * cluster_ports = NULL;
	int * cluster_addresses = NULL;
	int * cluster_fds = NULL;
	int * cluster_priorities = NULL;
	int * cluster_retvals = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;


	struct sockconnect_cluster * sockconnect_clusters = (struct sockconnect_cluster *) calloc(clusters_number, sizeof(struct sockconnect_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_socket_types = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ports = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_addresses = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_fds = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_priorities = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_socket_types[k] = entries[j].socket_type;
				cluster_ports[k] = entries[j].port;
				cluster_addresses[k] = entries[j].address;
				cluster_fds[k] = entries[j].fd;
				cluster_priorities[k] = entries[j].priority;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
			}
		sockconnect_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(sockconnect_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(sockconnect_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		for (j=0; j < cluster_sizes[i]; j++){
			add_integer_uniq(&sockconnect_clusters[i].socket_types, cluster_socket_types[j]);
			add_integer_uniq(&sockconnect_clusters[i].ports, cluster_ports[j]);
			add_integer_uniq(&sockconnect_clusters[i].addresses,cluster_addresses[j]);
			add_integer_uniq(&sockconnect_clusters[i].fds, cluster_fds[j]);
			add_integer_uniq(&sockconnect_clusters[i].priorities, cluster_priorities[j]);
			add_integer_uniq(&sockconnect_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&sockconnect_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&sockconnect_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&sockconnect_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&sockconnect_clusters[i].egids, cluster_egids[j]);
		}
		sockconnect_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_socket_types);
		free(cluster_ports);
		free(cluster_addresses);
		free(cluster_fds);
		free(cluster_priorities);
		free(cluster_retvals);
		free(cluster_euids);
		free(cluster_egids);
		free(cluster_ruids);
		free(cluster_rgids);

	}

	return sockconnect_clusters;
}
	
struct sockconnect_transformed_entry * sockconnect_transform_data(struct sockconnect_entry * entries, int size){
	
	struct sockconnect_transformed_entry * results = (struct sockconnect_transformed_entry *) calloc(size, sizeof(struct sockconnect_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].socket_type = entries[i].socket_type;
		results[i].port = entries[i].port;
		results[i].address = entries[i].address;
		results[i].fd = entries[i].fd;
		results[i].priority = entries[i].priority;
		results[i].retValue = entries[i].retValue;
		results[i].rgid = entries[i].rgid;
		results[i].ruid = entries[i].ruid;
		results[i].egid = entries[i].egid;
		results[i].euid = entries[i].euid;
	}

    //results = sockconnect_normalize_data(results, size);
	return results;
}

/**
struct sockconnect_transformed_entry * sockconnect_normalize_data(struct sockconnect_transformed_entry * entries, int size){
	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}
**/

double sockconnect_entries_distance(struct sockconnect_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct sockconnect_transformed_entry entry1 = entries[index1];
	struct sockconnect_transformed_entry entry2 = entries[index2];
	double min_socket_type = params[0];
	double max_socket_type = params[1];
	double min_port = params[2];
	double max_port = params[3];
	double min_address = params[4];
	double max_address = params[5];
	double min_fd = params[6];
	double max_fd = params[7];
	double min_priority = params[8];
	double max_priority = params[9];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_retValue = params[10];
	double max_retValue = params[11];
	double socket_type_distance=0;
	double port_distance=0;
	double address_distance=0;
	double fd_distance=0;
	double priority_distance=0;
	double retvalue_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;

	// Compute the components of the distance 

	// Socket type component
	if(max_socket_type != min_socket_type)
		socket_type_distance = abs(entries[index1].socket_type - entries[index2].socket_type)/(max_socket_type - min_socket_type);
	printf("\n Max socket_type : %f",max_socket_type);
	printf("\n Min socket_type : %f", min_socket_type);
	printf("\n Socket_type component : %f", socket_type_distance);

	// Port component
	if(max_port != min_port)
		port_distance = abs(entries[index1].port - entries[index2].port)/(max_port - min_port);
	printf("\n Max port : %f",max_port);
	printf("\n Min port : %f", min_port);
	printf("\n Port component : %f", port_distance);

	// Address component
	if(max_address != min_address)
		address_distance = abs(entries[index1].address - entries[index2].address)/(max_address - min_address);
	printf("\n Max address : %f",max_address);
	printf("\n Min address : %f", min_address);
	printf("\n Address component : %f", address_distance);

	// Fd component
	if(max_fd != min_fd)
		fd_distance = abs(entries[index1].fd - entries[index2].fd)/(max_fd - min_fd);
	printf("\n Max fd : %f",max_fd);
	printf("\n Min fd : %f", min_fd);
	printf("\n Fd component : %f", fd_distance);

	// Priority component
	if(max_priority != min_priority)
		priority_distance = abs(entries[index1].priority - entries[index2].priority)/(max_priority - min_priority);
	printf("\n Max Priority : %f",max_priority);
	printf("\n Min Priority : %f", min_priority);
	printf("\n Priority component : %f", priority_distance);

	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);


/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/
	// Compute final distance 
	distance = (SOCKET_TYPE_WEIGHT*socket_type_distance + PORT_WEIGHT*port_distance + ADDRESS_WEIGHT*address_distance + FD_WEIGHT*fd_distance + PRIORITY_WEIGHT*priority_distance + RETVALUE_WEIGHT*retvalue_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance) / (SOCKET_TYPE_WEIGHT + PORT_WEIGHT + ADDRESS_WEIGHT + FD_WEIGHT + PRIORITY_WEIGHT + RETVALUE_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT);

	return distance;
}

struct sockconnect_cluster sockconnect_match_entry_to_cluster(struct sockconnect_cluster * clusters, int clusters_number, struct sockconnect_transformed_entry entry) {

	double distances[clusters_number];
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
		}

	// Socket_type : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].socket_types,entry.socket_type))
			distances[i] += SOCKET_TYPE_WEIGHT*1;

		printf("\nCurrent distance (socket_type) : %f", distances[i]);
	
	// Port : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ports,entry.port))
			distances[i] += PORT_WEIGHT*1;

		printf("\nCurrent distance (port) : %f", distances[i]);

	// Address : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].addresses,entry.address))
			distances[i] += ADDRESS_WEIGHT*1;

		printf("\nCurrent distance (address) : %f", distances[i]);

	// Fd : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].fds,entry.fd))
			distances[i] += FD_WEIGHT*1;

		printf("\nCurrent distance (fd) : %f", distances[i]);
		
	// Priority : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].priorities,entry.priority))
			distances[i] += PRIORITY_WEIGHT*1;

		printf("\nCurrent distance (priority) : %f", distances[i]);

	// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

	// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

	// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

	// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

	// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);


		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}

/**
#########################################################################################
# Clustering methods for EXECVE system call
# Sample format : Syscall | Path_length | Path_depth | Filename | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Return_value : Custom distance
#########################################################################################
**/


struct execve_cluster* execve_cluster(struct execve_entry * entries, int size, int *max_clusters_number){

	struct execve_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double lengths[size];
	double depths[size];
	double retVals[size];
	char * paths[size];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_execve_clusters = NULL;
	struct execve_cluster * execve_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = execve_transform_data(entries, size);
	    int  i = 0;
		if (VERBOSE){
			for (i=0; i<size; i++){
            	printf("###################################\n");
				printf("Syscall : %s\n", results[i].syscall);
				printf("dPathLength : %d\n", results[i].path_length);
				printf("PathDepth : %d\n", results[i].path_depth);
				printf("Filename : %s\n", results[i].filename);
				printf("RetValue : %d\n", results[i].retValue);
			}
		}
		for(i=0; i<size; i++){
			lengths[i] = results[i].path_length;
			depths[i] = results[i].path_depth;
			retVals[i] = results[i].retValue;
			paths[i] = results[i].path;
		}
		params[0] = min_max_double(lengths, size, false);
		params[1] = min_max_double(lengths, size, true);
		params[2] = min_max_double(depths, size, false);
		params[3] = min_max_double(depths, size, true);
		params[4] = min_max_double(retVals, size, false);
		params[5] = min_max_double(retVals, size, true);
		params[6] = min_max_string(paths, size, false);
		params[7] = min_max_string(paths, size, true);


		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				distance_matrix[i][j] = execve_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		//raw_execve_clusters = hierarchical_clustering(distance_matrix,size,*max_clusters_number);
	    raw_execve_clusters = hierarchical_clustering_2(distance_matrix,size,max_clusters_number);
		printf("CLUSTER NUMBER : %d",*max_clusters_number);


		execve_clusters = model_execve_clusters(results, size, raw_execve_clusters, *max_clusters_number);

		for(i=0; i<*max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",execve_clusters[i].syscall);
			printf("Path length mean : %f \n", execve_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", execve_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", execve_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", execve_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			walk_strings(execve_clusters[i].filenames);
			printf("Paths : \n");
			walk_strings(execve_clusters[i].paths);
			printf("RetValues : \n");
			walk_integers(execve_clusters[i].retValues);
			printf("########################################\n");
		}


		// Freeing distance matrix
 		for(i=0; i<size; i++)
			free(distance_matrix[i]); 
		free(distance_matrix);

		// Freeing the transformed entries
		for (i=0;i<size;i++){
			free(results[i].syscall);
			free(results[i].path);
			free(results[i].filename);
		}
		free(results);

		// Freeing the raw clusters

		for (i=0; i<*max_clusters_number; i++)
			free(raw_execve_clusters[i]);
		free(raw_execve_clusters);


        return execve_clusters;
	}
}

struct execve_cluster * model_execve_clusters(struct execve_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number){

	int i,j,k,l,cluster_size=0, nbr_args_cluster=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_paths = NULL;
	int * cluster_nbr_args = NULL;
	char ** cluster_args = NULL;
	int * cluster_retvals = NULL;
	int * cluster_filemodes = NULL;
	int * cluster_file_owner_ids = NULL;
	int * cluster_file_group_ids = NULL;
	int * cluster_ruids = NULL;
	int * cluster_rgids = NULL;
	int * cluster_euids = NULL;
	int * cluster_egids = NULL;

	struct execve_cluster * execve_clusters = (struct execve_cluster *) calloc(clusters_number, sizeof(struct execve_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_paths = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_nbr_args = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_filemodes = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_owner_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_file_group_ids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_ruids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_rgids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_euids = (int *) calloc(cluster_sizes[i], sizeof(int));
		cluster_egids = (int *) calloc(cluster_sizes[i], sizeof(int));

		k = 0;
		nbr_args_cluster = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_paths[k] = entries[j].path;
				cluster_nbr_args[k] = entries[j].nbr_args;
				cluster_filemodes[k] = entries[j].filemode;
				cluster_file_owner_ids[k] = entries[j].file_owner_id;
				cluster_file_group_ids[k] = entries[j].file_group_id;
				cluster_ruids[k] = entries[j].ruid;
				cluster_rgids[k] = entries[j].rgid;
				cluster_euids[k] = entries[j].euid;
				cluster_egids[k] = entries[j].egid;
				cluster_retvals[k++] = entries[j].retValue;
				nbr_args_cluster += entries[j].nbr_args;
			}

		cluster_args = (char **) calloc(nbr_args_cluster, sizeof(char *));
		printf("Nbr args : %d\n",nbr_args_cluster);
		k=0;
		for(j=0; j<size; j++)
			if (raw_clusters[i][j] == true)
				for(l=0; l<entries[j].nbr_args; l++)
					cluster_args[k++] = entries[j].args[l];

		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		execve_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+3);
		strncpy(execve_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall));
		snprintf(execve_clusters[i].syscall + strlen(entries[i].syscall),3,"%d\0",i);
		execve_clusters[i].path_length_mean = mean_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength mean : %f", execve_clusters[i].path_length_mean);
		execve_clusters[i].path_length_variance = variance_double(cluster_path_lengths, cluster_sizes[i]);
		printf("\nLength variance : %f", execve_clusters[i].path_length_variance);
		execve_clusters[i].path_depth_mean = mean_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth mean : %f", execve_clusters[i].path_depth_mean);
		execve_clusters[i].path_depth_variance = variance_double(cluster_path_depths, cluster_sizes[i]);
		printf("\nDepth variance : %f", execve_clusters[i].path_depth_variance);
		for (j=0; j < cluster_sizes[i]; j++){
			add_string_uniq(&execve_clusters[i].filenames,cluster_filenames[j]);
			add_string_uniq(&execve_clusters[i].paths,cluster_paths[j]);
			add_integer_uniq(&execve_clusters[i].nbr_args,cluster_nbr_args[j]);
			add_integer_uniq(&execve_clusters[i].retValues,cluster_retvals[j]);
			add_integer_uniq(&execve_clusters[i].filemodes, cluster_filemodes[j]);
			add_integer_uniq(&execve_clusters[i].file_owner_ids, cluster_file_owner_ids[j]);
			add_integer_uniq(&execve_clusters[i].file_group_ids, cluster_file_group_ids[j]);
			add_integer_uniq(&execve_clusters[i].ruids, cluster_ruids[j]);
			add_integer_uniq(&execve_clusters[i].rgids, cluster_rgids[j]);
			add_integer_uniq(&execve_clusters[i].euids, cluster_euids[j]);
			add_integer_uniq(&execve_clusters[i].egids, cluster_egids[j]);
		}
		for (j=0; j< nbr_args_cluster; j++)
			add_string_uniq(&execve_clusters[i].args, cluster_args[j]);

		execve_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
		free(cluster_filenames);
		free(cluster_paths);
		free(cluster_nbr_args);
		free(cluster_args);
		free(cluster_retvals);
		free(cluster_filemodes);
		free(cluster_file_owner_ids);
		free(cluster_file_group_ids);
		free(cluster_ruids);
		free(cluster_rgids);
		free(cluster_euids);
		free(cluster_egids);
	}

	return execve_clusters;
}
	
struct execve_transformed_entry * execve_transform_data(struct execve_entry * entries, int size){
	
	struct execve_transformed_entry * results = (struct execve_transformed_entry *) calloc(size, sizeof(struct execve_transformed_entry));
	int i,j = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		results[i].path = path;
		int depth = 0;
	    char * token=NULL;
        char * prev_token=NULL;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		if(prev_token != NULL){
				results[i].filename = (char *) malloc(strlen(prev_token)+1);
				strncpy(results[i].filename, prev_token, strlen(prev_token));
				results[i].filename[strlen(prev_token)] = '\0';
		}
		else{
			results[i].filename = (char *) malloc(1);
			results[i].filename[0] = '\0';
		}
		free(path);

		results[i].nbr_args = entries[i].nbr_args;

		printf("Nbr args# : %d",results[i].nbr_args);
		if(results[i].nbr_args > 0){
			printf("%d => %d\n",i,results[i].nbr_args);
			results[i].args = (char **) calloc(results[i].nbr_args, sizeof(char *));
			for(j=0; j<results[i].nbr_args; j++){
				results[i].args[j] = (char *) malloc(strlen(entries[i].args[j])+1);
				sprintf(results[i].args[j],"%s\0",entries[i].args[j]);
				printf("%d,%d => %s",i,j,results[i].args[j]);
			}
		}
		results[i].retValue = entries[i].retValue;
		results[i].filemode = entries[i].filemode;
		results[i].file_owner_id = entries[i].file_owner_id;
		results[i].file_group_id = entries[i].file_group_id;
		results[i].euid = entries[i].euid;
		results[i].egid = entries[i].egid;
		results[i].ruid = entries[i].ruid;
		results[i].rgid = entries[i].rgid;

	}

    //results = execve_normalize_data(results, size);
	return results;
}

double execve_entries_distance(struct execve_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct execve_transformed_entry entry1 = entries[index1];
	struct execve_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	//double min_filename_distance = params[6];
	//double max_filename_distance = params[7];
	double min_path_distance = params[6];
	double max_path_distance = params[7];
	double path_length_distance=0;
	double path_depth_distance=0;
	//double filename_distance;
	double path_distance=0;
	double nbr_args_distance = 0;
	double args_distance = 0;
	double retvalue_distance=0;
	double filemode_distance=0;
	double file_owner_id_distance=0;
	double file_group_id_distance=0;
	double euid_distance=0;
	double egid_distance=0;
	double ruid_distance=0;
	double rgid_distance=0;
	double path_exclusion_distance=0;
	char  ** exclusion_regexps = NULL;
	int nbr_regexps = 1;
	int i;

	// Initializing regexps
	exclusion_regexps = (char **) calloc(nbr_regexps,sizeof(char *));
	exclusion_regexps[0] = "^/tmp/";

	// Compute the components of the distance 

	// Path length component
	if (max_path_length != min_path_length)
		path_length_distance = abs(entries[index1].path_length - entries[index2].path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %d",entries[index1].path_length);
	printf("\n Path length 2 : %d",entries[index2].path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	if (max_path_depth != min_path_depth)
		path_depth_distance = abs(entries[index1].path_depth - entries[index2].path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %d",entries[index1].path_depth);
	printf("\n Path depth 2 : %d",entries[index2].path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);
/**
	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);
**/

	// Filename component
	if (max_path_distance != min_path_distance)
		path_distance = levenshtein_distance(entries[index1].path, entries[index2].path) / (max_path_distance - min_path_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].path, entries[index2].path));
	printf("\n Max path : %f",max_path_distance);
	printf("\n Min path : %f",min_path_distance);
	printf("\nPath component : %f", path_distance);


	// RetValue component
	if (entries[index1].retValue != entries[index2].retValue){
		if(entries[index1].retValue == 0 || entries[index2].retValue == 0)
			retvalue_distance = 1;
		else
			retvalue_distance = 0.5;
	}
	printf("\nRetValue component : %f", retvalue_distance);
/**
	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*filename_distance + FLAGS_WEIGHT*flags_distance + RETVALUE_WEIGHT*retvalue_distance) / 5;
**/

	// Nbr args component

	if(entries[index1].nbr_args != entries[index2].nbr_args)
		nbr_args_distance = 1;

	// Args component

	if(entries[index1].nbr_args == entries[index2].nbr_args){
		for(i=0; i<entries[index1].nbr_args; i++){
			if(strlen(entries[index1].args[i]) > strlen(entries[index2].args[i]))
				args_distance += levenshtein_distance(entries[index1].args[i], entries[index2].args[i])/strlen(entries[index1].args[i]);
			else
				args_distance += levenshtein_distance(entries[index1].args[i], entries[index2].args[i])/strlen(entries[index2].args[i]);	
		}
		if(entries[index1].nbr_args != 0)
			args_distance /= entries[index1].nbr_args;
	}
	else
		args_distance = 1;

	// File mode component
	filemode_distance = compute_filemode_distance(entries[index1].filemode, entries[index2].filemode); 

	// File owner id component
	file_owner_id_distance = compute_file_owner_id_distance(entries[index1].file_owner_id, entries[index2].file_owner_id);

	// File group id component
	file_group_id_distance = compute_file_group_id_distance(entries[index1].file_group_id, entries[index2].file_group_id);

	// Euid component
	euid_distance = compute_euid_distance(entries[index1].euid, entries[index2].euid);

	// Egid component
	egid_distance = compute_egid_distance(entries[index1].egid, entries[index2].egid);

	// Ruid component
	ruid_distance = compute_ruid_distance(entries[index1].ruid, entries[index2].ruid);

	// Rgid component
	rgid_distance = compute_rgid_distance(entries[index1].rgid, entries[index2].rgid);

	// Path exclusion component
	path_exclusion_distance = compute_path_exclusion_distance(entries[index1].path, entries[index2].path, exclusion_regexps, nbr_regexps);

	printf("Path exclusion component : %f \n", path_exclusion_distance);

	// Compute final distance 
	distance = (LENGTH_WEIGHT*path_length_distance + DEPTH_WEIGHT*path_depth_distance + FILENAME_WEIGHT*path_distance + NBR_ARGS_WEIGHT*nbr_args_distance + ARGS_WEIGHT*args_distance + RETVALUE_WEIGHT*retvalue_distance + FILEMODE_WEIGHT*filemode_distance + FILE_OWNER_ID_WEIGHT*file_owner_id_distance + FILE_GROUP_ID_WEIGHT*file_group_id_distance + RUID_WEIGHT*ruid_distance + RGID_WEIGHT*rgid_distance + EUID_WEIGHT*euid_distance + EGID_WEIGHT*egid_distance + PATH_EXCLUSION_WEIGHT*path_exclusion_distance) / (LENGTH_WEIGHT + DEPTH_WEIGHT + FILENAME_WEIGHT + RETVALUE_WEIGHT + FILEMODE_WEIGHT + FILE_OWNER_ID_WEIGHT + FILE_GROUP_ID_WEIGHT + RUID_WEIGHT + RGID_WEIGHT + EUID_WEIGHT + EGID_WEIGHT + PATH_EXCLUSION_WEIGHT + NBR_ARGS_WEIGHT + ARGS_WEIGHT);

	return distance;
}

struct execve_cluster execve_match_entry_to_cluster(struct execve_cluster * clusters, int clusters_number, struct execve_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,k,result = 0;
	bool flag= false;
	double * coeffs = NULL; 
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		if (entry.path_length != clusters[i].path_length_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_length_variance/pow((entry.path_length - clusters[i].path_length_mean),2));
				if (temp > 0){
					distances[i] += LENGTH_WEIGHT*temp;
					printf("\nPath length component : %f",LENGTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_length - clusters[i].path_length_mean)*99;
				printf("\nPath length component : %f",fabs(entry.path_length - clusters[i].path_length_mean)*99);
		   }
		}
		printf("\n Current Distance : %f", distances[i]);

		// Path depth : Chebyshev's inequality for upper bound
		if (entry.path_depth != clusters[i].path_depth_mean){
			if(clusters[i].path_length_variance != 0){
				temp = 1 - (clusters[i].path_depth_variance/pow((entry.path_depth - clusters[i].path_depth_mean),2));
				if (temp > 0){
					distances[i] += DEPTH_WEIGHT*temp; 
					printf("\nPath depth component : %f",DEPTH_WEIGHT*temp);
				}
			}
			else{
				distances[i] += fabs(entry.path_depth - clusters[i].path_depth_mean)*99;
				printf("\nPath depth component : %f",fabs(entry.path_depth - clusters[i].path_depth_mean)*99);
			}
		}

		printf("\nCurrent distance : %f", distances[i]);

		// Filename : Smallest levenshtein distance
		temp = levenshtein_distance(get_string(clusters[i].paths,0)->string, entry.path);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<strings_list_size(clusters[i].paths); j++){
			temp = levenshtein_distance(get_string(clusters[i].paths,j)->string, entry.path);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0){
			printf("\nPath component : %f",FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance));
			distances[i] += FILENAME_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}

		// Nbr args : 1 if not present, 0 otherwise
		if( !integer_list_contains(clusters[i].nbr_args,entry.nbr_args))
			distances[i] += NBR_ARGS_WEIGHT*1;

		// Args : Smallest cumulative levenshtein distance
		for (k=0; k<entry.nbr_args; k++){
			temp = levenshtein_distance(get_string(clusters[i].args,0)->string, entry.args[k]);
			max_levenshtein_distance = temp;
			min_levenshtein_distance = temp;
			for (j=1; j<strings_list_size(clusters[i].args); j++){
				temp = levenshtein_distance(get_string(clusters[i].args,j)->string, entry.args[k]);
				if (temp > max_levenshtein_distance)
					max_levenshtein_distance = temp;
				if (temp < min_levenshtein_distance)
					min_levenshtein_distance = temp;
			}
			if (max_levenshtein_distance != 0)
				distances[i] += ARGS_WEIGHT*(min_levenshtein_distance / max_levenshtein_distance);
		}

		// RetValue : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].retValues,entry.retValue))
			distances[i] += RETVALUE_WEIGHT*1;

		printf("\nCurrent distance (retval) : %f", distances[i]);

		// File owner id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_owner_ids,entry.file_owner_id))
			distances[i] += FILE_OWNER_ID_WEIGHT*1;

		printf("\nCurrent distance (file owner id) : %f", distances[i]);

		// File group id : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].file_group_ids,entry.file_group_id))
			distances[i] += FILE_GROUP_ID_WEIGHT*1;

		printf("\nCurrent distance (file group id) : %f", distances[i]);


		// File mode : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].filemodes,entry.filemode))
			distances[i] += FILEMODE_WEIGHT*1;

		printf("\nCurrent distance (filemode) : %f", distances[i]);

		// Ruid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].ruids,entry.ruid))
			distances[i] += RUID_WEIGHT*1;

		printf("\nCurrent distance (ruid) : %f", distances[i]);

		// Rgid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].rgids, entry.rgid))
			distances[i] += RGID_WEIGHT*1;

		printf("\nCurrent distance (rgid) : %f", distances[i]);

		// Euid : 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].euids,entry.euid))
			distances[i] += EUID_WEIGHT*1;

		printf("\nCurrent distance (euid) : %f", distances[i]);

		// Egid: 1 if not present, 0 otherwise
		if (!integer_list_contains(clusters[i].egids, entry.egid))
			distances[i] += EGID_WEIGHT*1;

		printf("\nCurrent distance (egid) : %f", distances[i]);

		//distances[i] /= ((1-coeffs[0])*LENGTH_WEIGHT + (1-coeffs[1])*DEPTH_WEIGHT + (1-coeffs[2])*FILENAME_WEIGHT + FLAGS_WEIGHT + RETVALUE_WEIGHT);
	}	
	// Return the closest cluster
	min_distance = distances[0];
	printf("Distance to cluster 0 : %f\n",distances[0]);
	result = 0;
	for (i=1; i<clusters_number; i++){
		printf("Distance to cluster %d : %f\n",i,distances[i]);
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	}
	
	return clusters[result];

}
double compute_filemode_distance(double filemode1, double filemode2){

	double distance = 0;
	if (filemode1 == filemode2)
		return distance;

	// Setuid / setgid / sticky bit distance
	if (filemode1 > 1000 && filemode2 < 1000 ||
		filemode1 < 1000 && filemode2 > 1000)
		distance += 1;

	// File permissions distance
	if (filemode1 >= 0 && filemode1 < 7 &&
		filemode2 >= 0 && filemode2 < 7)
		distance += 0.5;
	else if (filemode1 >= 7 && filemode1 < 77 &&
			 filemode2 >= 7 && filemode2 < 77)
		distance += 0.5;	
	else if (filemode1 >= 77 && filemode2 >= 77)
		distance += 0.5;
	else
		distance += 1;

	return distance/2;
}

double compute_file_owner_id_distance(double file_owner_id1, double file_owner_id2){

    // Includes root owner id
	if(file_owner_id1 == file_owner_id2)
		return 0;
	// Both ids in special owner ids category
	else if (file_owner_id1 > 0 && file_owner_id1 <= 100 && 
			 file_owner_id2 > 0 && file_owner_id2 <= 100)
		return 0.5;
	// Both ids in regular owner ids category
	else if (file_owner_id1 > 100 && file_owner_id2 > 100)
		return 0.5;
	// The ids belong to different categories
	else
		return 1;

}

double compute_file_group_id_distance(double file_group_id1, double file_group_id2){

    // Includes root group id
	if(file_group_id1 == file_group_id2)
		return 0;
	// Both ids in special group ids category
	else if (file_group_id1 > 0 && file_group_id1 <= 100 && 
			 file_group_id2 > 0 && file_group_id2 <= 100)
		return 0.5;
	// Both ids in regular group ids category
	else if (file_group_id1 > 100 && file_group_id2 > 100)
		return 0.5;
	// The ids belong to different categories
	else
		return 1;

}

double compute_euid_distance(double euid1, double euid2){

    // Includes root euid
	if(euid1 == euid2)
		return 0;
	// Both ids in special euids category
	else if (euid1 > 0 && euid1 <= 100 && 
			 euid2 > 0 && euid2 <= 100)
		return 0.5;
	// Both ids in regular euids category
	else if (euid1 > 100 && euid2 > 100)
		return 0.5;
	// The ids belong to different categories
	else
		return 1;

}

double compute_egid_distance(double egid1, double egid2){

    // Includes root egid
	if(egid1 == egid2)
		return 0;
	// Both ids in special egids category
	else if (egid1 > 0 && egid1 <= 100 && 
			 egid2 > 0 && egid2 <= 100)
		return 0.5;
	// Both ids in regular egids category
	else if (egid1 > 100 && egid2 > 100)
		return 0.5;
	// The ids belong to different categories
	else
		return 1;


}

double compute_ruid_distance(double ruid1, double ruid2){

    // Includes root ruid
	if(ruid1 == ruid2)
		return 0;
	// Both ids in special ruids category
	else if (ruid1 > 0 && ruid1 <= 100 && 
			 ruid2 > 0 && ruid2 <= 100)
		return 0.5;
	// Both ids in regular ruids category
	else if (ruid1 > 100 && ruid2 > 100)
		return 0.5;
	// The ids belong to different categories
	else
		return 1;
}


double compute_rgid_distance(double rgid1, double rgid2){

    // Includes root rgid
	if(rgid1 == rgid2)
		return 0;
	// Both ids in special rgids category
	else if (rgid1 > 0 && rgid1 <= 100 && 
			 rgid2 > 0 && rgid2 <= 100)
		return 0.5;
	// Both ids in regular rgids category
	else if (rgid1 > 100 && rgid2 > 100)
		return 0.5;
	// The ids belong to different categories
	else
		return 1;
}


double compute_path_exclusion_distance(char * filename1, char * filename2, char ** exclusion_regexps, int nbr_regexps){

	regex_t exp;
	regmatch_t  match[1];
	int rv,i;

	for(i=0; i<nbr_regexps; i++){
		rv = regcomp(&exp, exclusion_regexps[i], REG_EXTENDED);
		printf("%s\n",filename1);
		printf("%s\n",filename2);
		printf("Compiled !\n");
		if (rv != 0){
			printf("Could not compile regexp : %s\n",exclusion_regexps[i]);
			continue;
		}
		if ((regexec(&exp, filename1, 1, match, 0) == 0) && (regexec(&exp, filename2, 1, match, 0) == 0))
			return 0;
	}

	return 1;
}
/** ###############################################################
CLUSTERS PARSERS
##################################################################**/


void open_clusters_writer(char * filename, struct open_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "open");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"flags");
		for (j=0; j<strings_list_size(clusters[i].flags); j++){
			xmlTextWriterWriteElement(writer,"flag", (const xmlChar *) get_string(clusters[i].flags, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void close_clusters_writer(char * filename, struct close_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "close");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}


		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void mmap_clusters_writer(char * filename, struct mmap_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "mmap");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}


		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void stat_clusters_writer(char * filename, struct stat_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "stat");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void access_clusters_writer(char * filename, struct access_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "access");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void munmap_clusters_writer(char * filename, struct munmap_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "munmap");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"addresses");
		for (j=0; j<integers_list_size(clusters[i].addresses); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].addresses,j)->integer);
			xmlTextWriterWriteElement(writer,"address", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void putmsg_clusters_writer(char * filename, struct putmsg_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "putmsg");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filedes");
		for (j=0; j<integers_list_size(clusters[i].filedess); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filedess,j)->integer);
			xmlTextWriterWriteElement(writer,"filedes", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"flags");
		for (j=0; j<integers_list_size(clusters[i].flags); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].flags,j)->integer);
			xmlTextWriterWriteElement(writer,"flag", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void sysinfo_clusters_writer(char * filename, struct sysinfo_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "sysinfo");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"commands");
		for (j=0; j<integers_list_size(clusters[i].commands); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].commands,j)->integer);
			xmlTextWriterWriteElement(writer,"command", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void chdir_clusters_writer(char * filename, struct chdir_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "chdir");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void readlink_clusters_writer(char * filename, struct readlink_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "readlink");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void unlink_clusters_writer(char * filename, struct unlink_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "unlink");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void creat_clusters_writer(char * filename, struct creat_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "creat");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}




void lstat_clusters_writer(char * filename, struct lstat_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "lstat");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void seteuid_clusters_writer(char * filename, struct seteuid_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "seteuid");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"p_euids");
		for (j=0; j<integers_list_size(clusters[i].p_euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].p_euids,j)->integer);
			xmlTextWriterWriteElement(writer,"p_euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void setgid_clusters_writer(char * filename, struct setgid_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "setgid");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"gids");
		for (j=0; j<integers_list_size(clusters[i].gids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].gids,j)->integer);
			xmlTextWriterWriteElement(writer,"gid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void setgroups_clusters_writer(char * filename, struct setgroups_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "setgroups");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"ngroups");
		for (j=0; j<integers_list_size(clusters[i].ngroupss); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ngroupss,j)->integer);
			xmlTextWriterWriteElement(writer,"ngroup", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void setegid_clusters_writer(char * filename, struct setegid_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "setegid");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"p_egids");
		for (j=0; j<integers_list_size(clusters[i].p_egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].p_egids,j)->integer);
			xmlTextWriterWriteElement(writer,"p_egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void rename_clusters_writer(char * filename, struct rename_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "rename");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean1);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean1",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance1);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance1",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean1);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean1",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance1);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance1",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean2);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean2",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance2);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance2",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean2);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean2",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance2);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance2",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames1");
		for (j=0; j<strings_list_size(clusters[i].filenames1); j++){
			xmlTextWriterWriteElement(writer,"filename1", (const xmlChar *) get_string(clusters[i].filenames1, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filenames2");
		for (j=0; j<strings_list_size(clusters[i].filenames2); j++){
			xmlTextWriterWriteElement(writer,"filename2", (const xmlChar *) get_string(clusters[i].filenames2, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths1");
		for (j=0; j<strings_list_size(clusters[i].paths1); j++){
			xmlTextWriterWriteElement(writer,"path1", (const xmlChar *) get_string(clusters[i].paths1, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths2");
		for (j=0; j<strings_list_size(clusters[i].paths2); j++){
			xmlTextWriterWriteElement(writer,"path2", (const xmlChar *) get_string(clusters[i].paths2, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes1");
		for (j=0; j<integers_list_size(clusters[i].filemodes1); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes1,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode1", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file1_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file1_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file1_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file1_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file1_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file1_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file1_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file1_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"filemodes2");
		for (j=0; j<integers_list_size(clusters[i].filemodes2); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes2,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode2", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"file2_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file2_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file2_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file2_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file2_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file2_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file2_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file2_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void ioctl_clusters_writer(char * filename, struct ioctl_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "ioctl");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"commands");
		for (j=0; j<integers_list_size(clusters[i].commands); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].commands,j)->integer);
			xmlTextWriterWriteElement(writer,"command", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"args");
		for (j=0; j<integers_list_size(clusters[i].args); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].args,j)->integer);
			xmlTextWriterWriteElement(writer,"arg", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void fcntl_clusters_writer(char * filename, struct fcntl_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "fcntl");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"commands");
		for (j=0; j<integers_list_size(clusters[i].commands); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].commands,j)->integer);
			xmlTextWriterWriteElement(writer,"command", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void getmsg_clusters_writer(char * filename, struct getmsg_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "getmsg");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filedess");
		for (j=0; j<integers_list_size(clusters[i].filedess); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filedess,j)->integer);
			xmlTextWriterWriteElement(writer,"filedes", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"flags");
		for (j=0; j<integers_list_size(clusters[i].flags); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].flags,j)->integer);
			xmlTextWriterWriteElement(writer,"flag", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void setuid_clusters_writer(char * filename, struct setuid_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "setuid");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"uids");
		for (j=0; j<integers_list_size(clusters[i].uids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].uids,j)->integer);
			xmlTextWriterWriteElement(writer,"uid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}


void vfork_clusters_writer(char * filename, struct vfork_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "vfork");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"pids");
		for (j=0; j<integers_list_size(clusters[i].pids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].pids,j)->integer);
			xmlTextWriterWriteElement(writer,"pid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void chown_clusters_writer(char * filename, struct chown_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "chown");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"owners");
		for (j=0; j<integers_list_size(clusters[i].owners); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].owners,j)->integer);
			xmlTextWriterWriteElement(writer,"owner", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"groups");
		for (j=0; j<integers_list_size(clusters[i].groups); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].groups,j)->integer);
			xmlTextWriterWriteElement(writer,"group", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void chroot_clusters_writer(char * filename, struct chroot_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "chroot");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void fchown_clusters_writer(char * filename, struct fchown_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "fchown");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"owners");
		for (j=0; j<integers_list_size(clusters[i].owners); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].owners,j)->integer);
			xmlTextWriterWriteElement(writer,"owner", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"groups");
		for (j=0; j<integers_list_size(clusters[i].groups); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].groups,j)->integer);
			xmlTextWriterWriteElement(writer,"group", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void sockconnect_clusters_writer(char * filename, struct sockconnect_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "sockconnect");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"ports");
		for (j=0; j<integers_list_size(clusters[i].ports); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ports,j)->integer);
			xmlTextWriterWriteElement(writer,"port", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"addresses");
		for (j=0; j<integers_list_size(clusters[i].addresses); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].addresses,j)->integer);
			xmlTextWriterWriteElement(writer,"address", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"fds");
		for (j=0; j<integers_list_size(clusters[i].fds); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].fds,j)->integer);
			xmlTextWriterWriteElement(writer,"fd", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"priorities");
		for (j=0; j<integers_list_size(clusters[i].priorities); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].priorities,j)->integer);
			xmlTextWriterWriteElement(writer,"priority", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);


		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}

void execve_clusters_writer(char * filename, struct execve_cluster * clusters, int clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur;
	xmlChar * key;
	xmlTextWriterPtr writer;
	char * temp = (char *) malloc(5);
	int rc,i,j;

	writer = xmlNewTextWriterFilename(filename,0);
	xmlTextWriterSetIndent(writer,1);

	rc = xmlTextWriterStartDocument(writer, NULL, "ISO-8859-1", NULL);
	if (rc<0) {
		printf("Error at xmlTextWriterStartDocument\n");
		return;
	}
	rc = xmlTextWriterStartElement(writer,BAD_CAST "execve");
	if (rc<0) {
		printf("Error at xmlTextWriterStartElement\n");
		return;
	}
   
	 for(i=0; i<clusters_number; i++){
		
		rc = xmlTextWriterStartElement(writer,"cluster");
		if (rc<0) {
			printf("Error at xmlTextWriterStartElement\n");
			return;
		}

		rc = xmlTextWriterWriteElement(writer,"syscall",clusters[i].syscall);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_mean);
		rc = xmlTextWriterWriteElement(writer,"path_length_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_length_variance);
		rc = xmlTextWriterWriteElement(writer,"path_length_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_mean);
		rc = xmlTextWriterWriteElement(writer,"path_depth_mean",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		snprintf(temp,5,"%f\0",clusters[i].path_depth_variance);
		rc = xmlTextWriterWriteElement(writer,"path_depth_variance",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		xmlTextWriterStartElement(writer,"filenames");
		for (j=0; j<strings_list_size(clusters[i].filenames); j++){
			xmlTextWriterWriteElement(writer,"filename", (const xmlChar *) get_string(clusters[i].filenames, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"nbr_argss");
		for (j=0; j<integers_list_size(clusters[i].nbr_args); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].nbr_args,j)->integer);
			xmlTextWriterWriteElement(writer,"nbr_args", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"args");
		for (j=0; j<strings_list_size(clusters[i].args); j++){
			xmlTextWriterWriteElement(writer,"arg", (const xmlChar *) get_string(clusters[i].args, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"retValues");
		for (j=0; j<integers_list_size(clusters[i].retValues); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].retValues,j)->integer);
			xmlTextWriterWriteElement(writer,"retValue", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"paths");
		for (j=0; j<strings_list_size(clusters[i].paths); j++){
			xmlTextWriterWriteElement(writer,"path", (const xmlChar *) get_string(clusters[i].paths, j)->string);

		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"filemodes");
		for (j=0; j<integers_list_size(clusters[i].filemodes); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].filemodes,j)->integer);
			xmlTextWriterWriteElement(writer,"filemode", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_owner_ids");
		for (j=0; j<integers_list_size(clusters[i].file_owner_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_owner_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_owner_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"file_group_ids");
		for (j=0; j<integers_list_size(clusters[i].file_group_ids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].file_group_ids,j)->integer);
			xmlTextWriterWriteElement(writer,"file_group_id", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"euids");
		for (j=0; j<integers_list_size(clusters[i].euids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].euids,j)->integer);
			xmlTextWriterWriteElement(writer,"euid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"egids");
		for (j=0; j<integers_list_size(clusters[i].egids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].egids,j)->integer);
			xmlTextWriterWriteElement(writer,"egid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"ruids");
		for (j=0; j<integers_list_size(clusters[i].ruids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].ruids,j)->integer);
			xmlTextWriterWriteElement(writer,"ruid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		xmlTextWriterStartElement(writer,"rgids");
		for (j=0; j<integers_list_size(clusters[i].rgids); j++){
			snprintf(temp,5,"%d\0",get_integer(clusters[i].rgids,j)->integer);
			xmlTextWriterWriteElement(writer,"rgid", (const xmlChar *)temp);
		}
		xmlTextWriterEndElement(writer);

		snprintf(temp,5,"%d\0",clusters[i].cluster_size);
		rc = xmlTextWriterWriteElement(writer,"cluster_size",temp);
		if (rc<0){
			printf("Error at xmlTextWriterWriteElement\n");
			return;
		}

		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
	}
		rc = xmlTextWriterEndElement(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndElement\n");
			return;
		}
		
		rc = xmlTextWriterEndDocument(writer);
		if (rc<0){
			printf("Error at xmlTextWriterEndDocument\n");
			return;
		}
}
struct open_cluster * open_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct open_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if ( file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if open clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "open")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct open_cluster *) realloc(clusters,count*sizeof(struct open_cluster));
			clusters[count-1].filenames = NULL;
			clusters[count-1].flags = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;

			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "flags")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "flag")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Flag : %s\n", key);
							add_string_uniq(&clusters[count-1].flags,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	xmlFreeDoc(doc);
	return clusters;
	
}

struct close_cluster * close_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct close_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if close clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "close")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct close_cluster *) realloc(clusters,count*sizeof(struct close_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							if(key == NULL){
								printf("Null string \n");
								add_string_uniq(&(clusters[count-1].filenames),"\0");
							}
							else{
								printf("Filename : %s", key);
								add_string_uniq(&(clusters[count-1].filenames),key);
							}
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	xmlFreeDoc(doc);
	return clusters;
	
}


struct mmap_cluster * mmap_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct mmap_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if mmap clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "mmap")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct mmap_cluster *) realloc(clusters,count*sizeof(struct mmap_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					printf("Read syscall : %s\n",clusters[count-1].syscall);
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}


struct stat_cluster * stat_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct stat_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if stat clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "stat")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct stat_cluster *) realloc(clusters,count*sizeof(struct stat_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}


struct access_cluster * access_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct access_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if access clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "access")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct access_cluster *) realloc(clusters,count*sizeof(struct access_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct munmap_cluster * munmap_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct munmap_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if munmap clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "munmap")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct munmap_cluster *) realloc(clusters,count*sizeof(struct munmap_cluster));

			clusters[count-1].addresses = NULL;
			clusters[count-1].lengths = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "addresses")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "address")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Address : %s\n", key);
							add_integer_uniq(&clusters[count-1].addresses,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "lengths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "length")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Length : %s\n", key);
							add_integer_uniq(&clusters[count-1].lengths,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				


				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct putmsg_cluster * putmsg_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct putmsg_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if putmsg clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "putmsg")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct putmsg_cluster *) realloc(clusters,count*sizeof(struct putmsg_cluster));

			clusters[count-1].filedess = NULL;
			clusters[count-1].flags = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filedess")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filedes")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filedes : %s\n", key);
							add_integer_uniq(&clusters[count-1].filedess,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "flags")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "flag")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Flag : %s\n", key);
							add_integer_uniq(&clusters[count-1].flags,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				


				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct sysinfo_cluster * sysinfo_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct sysinfo_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if sysinfo clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "sysinfo")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct sysinfo_cluster *) realloc(clusters,count*sizeof(struct sysinfo_cluster));

			clusters[count-1].commands = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "commands")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "command")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Command : %s\n", key);
							add_integer_uniq(&clusters[count-1].commands,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct chdir_cluster * chdir_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct chdir_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if chdir clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "chdir")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;

			clusters = (struct chdir_cluster *) realloc(clusters,count*sizeof(struct chdir_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct readlink_cluster * readlink_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct readlink_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if readlink clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "readlink")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct readlink_cluster *) realloc(clusters,count*sizeof(struct readlink_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct unlink_cluster * unlink_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct unlink_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;


	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if unlink clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "unlink")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct unlink_cluster *) realloc(clusters,count*sizeof(struct unlink_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct creat_cluster * creat_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct creat_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if creat clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "creat")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct creat_cluster *) realloc(clusters,count*sizeof(struct creat_cluster));
			
			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;

			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct lstat_cluster * lstat_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct lstat_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if lstat clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "lstat")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct lstat_cluster *) realloc(clusters,count*sizeof(struct lstat_cluster));
	
			clusters[count-1].filenames = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct seteuid_cluster * seteuid_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct seteuid_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if seteuid clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "seteuid")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct seteuid_cluster *) realloc(clusters,count*sizeof(struct seteuid_cluster));

			clusters[count-1].euids = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].p_euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "p_euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "p_euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("P_Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].p_euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}


struct setgid_cluster * setgid_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct setgid_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if setgid clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "setgid")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct setgid_cluster *) realloc(clusters,count*sizeof(struct setgid_cluster));

			clusters[count-1].gids = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "gids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "gid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Gid : %s\n", key);
							add_integer_uniq(&clusters[count-1].gids,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct setgroups_cluster * setgroups_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct setgroups_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if setgroup clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "setgroup")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct setgroups_cluster *) realloc(clusters,count*sizeof(struct setgroups_cluster));
		
			clusters[count-1].ngroupss = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ngroupss")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ngroups")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ngroups : %s\n", key);
							add_integer_uniq(&clusters[count-1].ngroupss,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct setegid_cluster * setegid_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct setegid_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if setegid clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "setegid")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct setegid_cluster *) realloc(clusters,count*sizeof(struct setegid_cluster));

			clusters[count-1].egids = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].p_egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;

			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "p_egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "p_egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("P_Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].p_egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct rename_cluster * rename_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct rename_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if rename clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "rename")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct rename_cluster *) realloc(clusters,count*sizeof(struct rename_cluster));

			clusters[count-1].filenames1 = NULL;
			clusters[count-1].filenames2 = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths1 = NULL;
			clusters[count-1].paths2 = NULL;
			clusters[count-1].filemodes1 = NULL;
			clusters[count-1].file1_owner_ids = NULL;
			clusters[count-1].file1_group_ids = NULL;
			clusters[count-1].filemodes2 = NULL;
			clusters[count-1].file2_owner_ids = NULL;
			clusters[count-1].file2_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean1")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length 1 mean : %s", key);
					clusters[count-1].path_length_mean1 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance1")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length 1 variance : %s", key);
					clusters[count-1].path_length_variance1 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean1")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth 1 mean : %s", key);
					clusters[count-1].path_depth_mean1 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance1")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth 1 variance : %s", key);
					clusters[count-1].path_depth_variance1 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames1")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename1")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename1 : %s", key);
							add_string_uniq(&(clusters[count-1].filenames1),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean2")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length 2 mean : %s", key);
					clusters[count-1].path_length_mean2 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance2")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length 2 variance : %s", key);
					clusters[count-1].path_length_variance2 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean2")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth 2 mean : %s", key);
					clusters[count-1].path_depth_mean2 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance2")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth 2 variance : %s", key);
					clusters[count-1].path_depth_variance2 = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames2")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename2")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename 2 : %s", key);
							add_string_uniq(&(clusters[count-1].filenames2),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths1")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path1")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path 1: %s\n", key);
							add_string_uniq(&clusters[count-1].paths1,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes1")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode1")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode 1: %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes1, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file1_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file1_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File 1 owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file1_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file1_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file1_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File 1 group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file1_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths2")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path2")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path 2: %s\n", key);
							add_string_uniq(&clusters[count-1].paths2,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes2")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode2")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode 2: %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes2, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file2_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file2_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File 2 owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file2_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file2_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file2_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File 2 group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file2_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}


				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct ioctl_cluster * ioctl_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct ioctl_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if ioctl clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "ioctl")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct ioctl_cluster *) realloc(clusters,count*sizeof(struct ioctl_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].commands = NULL;
			clusters[count-1].args = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "commands")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "command")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Command : %s\n", key);
							add_integer_uniq(&clusters[count-1].commands,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "args")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "arg")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Arg : %s\n", key);
							add_integer_uniq(&clusters[count-1].args,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				


				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct fcntl_cluster * fcntl_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct fcntl_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if fcntl clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "fcntl")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct fcntl_cluster *) realloc(clusters,count*sizeof(struct fcntl_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].commands = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;	
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "commands")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "command")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Command : %s\n", key);
							add_integer_uniq(&clusters[count-1].commands,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct getmsg_cluster * getmsg_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct getmsg_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if getmsg clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "getmsg")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct getmsg_cluster *) realloc(clusters,count*sizeof(struct getmsg_cluster));

			clusters[count-1].filedess = NULL;
			clusters[count-1].flags = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filedess")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filedes")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filedes : %s\n", key);
							add_integer_uniq(&clusters[count-1].filedess,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "flags")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "flag")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Flag : %s\n", key);
							add_integer_uniq(&clusters[count-1].flags,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				


				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct setuid_cluster * setuid_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct setuid_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if setuid clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "setuid")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct setuid_cluster *) realloc(clusters,count*sizeof(struct setuid_cluster));

			clusters[count-1].uids = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "uids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "uid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Uid : %s\n", key);
							add_integer_uniq(&clusters[count-1].uids,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct vfork_cluster * vfork_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct vfork_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if vfork clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "vfork")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct vfork_cluster *) realloc(clusters,count*sizeof(struct vfork_cluster));

			clusters[count-1].pids = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "pids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "pid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Pid : %s\n", key);
							add_integer_uniq(&clusters[count-1].pids,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct chown_cluster * chown_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct chown_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if chown clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "chown")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct chown_cluster *) realloc(clusters,count*sizeof(struct chown_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].owners = NULL;
			clusters[count-1].groups = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct chroot_cluster * chroot_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct chroot_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if chroot clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "chroot")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct chroot_cluster *) realloc(clusters,count*sizeof(struct chroot_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct fchown_cluster * fchown_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct fchown_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if fchown clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "fchown")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct fchown_cluster *) realloc(clusters,count*sizeof(struct fchown_cluster));

			clusters[count-1].filenames = NULL;
			clusters[count-1].owners = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}
					else if (!xmlStrcmp(cluster->name, (const xmlChar *) "owners")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "owner")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Owner : %s\n", key);
							add_integer_uniq(&clusters[count-1].owners,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}	else if (!xmlStrcmp(cluster->name, (const xmlChar *) "groups")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "group")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Group : %s\n", key);
							add_integer_uniq(&clusters[count-1].groups,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct sockconnect_cluster * sockconnect_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct sockconnect_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL; 

	// Check if file exists
	if (file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if sockconnect clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "sockconnect")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct sockconnect_cluster *) realloc(clusters,count*sizeof(struct sockconnect_cluster));

			clusters[count-1].socket_types = NULL;
			clusters[count-1].ports = NULL;
			clusters[count-1].addresses = NULL;
			clusters[count-1].fds = NULL;
			clusters[count-1].priorities = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;
			
			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "socket_types")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "socket_type")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Socket type : %s\n", key);
							add_integer_uniq(&clusters[count-1].socket_types,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "addresses")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "address")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Address : %s\n", key);
							add_integer_uniq(&clusters[count-1].addresses,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ports")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "port")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Port : %s\n", key);
							add_integer_uniq(&clusters[count-1].ports,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "fds")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "fd")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Fd : %s\n", key);
							add_integer_uniq(&clusters[count-1].fds,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "priorities")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "priority")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Priority : %s\n", key);
							add_integer_uniq(&clusters[count-1].priorities,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	return clusters;
	
}

struct execve_cluster * execve_clusters_parser(char * filename, int * clusters_number){

	xmlDocPtr doc;
	xmlNodePtr cur,cluster,temp;
	xmlChar * key;
	struct execve_cluster * clusters = NULL;
	int count=0;
	FILE * file = NULL;

	// Check if file exists
	if ( file = fopen(filename,"r"))
		fclose(file);
	else
		return;

	doc = xmlParseFile(filename);

	if ( doc == NULL){
		printf("Cluster records document could not be parsed correctly\n");
		return NULL;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL){
		printf ("Empty document !\n");
		xmlFreeDoc(doc);
		return NULL;
	}

	// Check if execve clusters document

	if (xmlStrcmp(cur->name, (const xmlChar *) "execve")) {
		printf("Cluster records of wrong type !");
		xmlFreeDoc(doc);
		return NULL;
	}

	cur = cur->xmlChildrenNode;
	
	while (cur != NULL) {
		
		printf("Cur : %s\n",cur->name);
		if(!xmlStrcmp(cur->name, (const xmlChar *) "cluster")){
			count++;
			clusters = (struct execve_cluster *) realloc(clusters,count*sizeof(struct execve_cluster));
			clusters[count-1].filenames = NULL;
			clusters[count-1].nbr_args = NULL;
			clusters[count-1].args = NULL;
			clusters[count-1].retValues = NULL;
			clusters[count-1].paths = NULL;
			clusters[count-1].filemodes = NULL;
			clusters[count-1].file_owner_ids = NULL;
			clusters[count-1].file_group_ids = NULL;
			clusters[count-1].euids = NULL;
			clusters[count-1].egids = NULL;
			clusters[count-1].ruids = NULL;
			clusters[count-1].rgids = NULL;

			cluster = cur->xmlChildrenNode;
			while(cluster != NULL){
				printf("Cluster : %s\n",cluster->name);

				if (!xmlStrcmp(cluster->name, (const xmlChar *) "syscall")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Syscall : %s", key);
					clusters[count-1].syscall = (char *) malloc(sizeof(key)+1);
					strncpy(clusters[count-1].syscall, key, sizeof(key));
					clusters[count-1].syscall[sizeof(key)] = '\0';
					xmlFree(key);
				}
				if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length mean : %s", key);
					clusters[count-1].path_length_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_length_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path length variance : %s", key);
					clusters[count-1].path_length_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_mean")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth mean : %s", key);
					clusters[count-1].path_depth_mean = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "path_depth_variance")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Path depth variance : %s", key);
					clusters[count-1].path_depth_variance = atoi(key);
					xmlFree(key);
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filenames")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filename")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filename : %s", key);
							add_string_uniq(&(clusters[count-1].filenames),key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "args")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "arg")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Arg : %s\n", key);
							add_string_uniq(&clusters[count-1].args,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "nbr_argss")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "nbr_arg")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Nbr Args : %s\n", key);
							add_integer_uniq(&clusters[count-1].nbr_args,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "retValues")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "retValue")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("RetValue : %s\n", key);
							add_integer_uniq(&clusters[count-1].retValues,atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}				

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "paths")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "path")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Path : %s\n", key);
							add_string_uniq(&clusters[count-1].paths,key);
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "filemodes")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "filemode")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Filemode : %s\n", key);
							add_integer_uniq(&clusters[count-1].filemodes, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}
				
				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_owner_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_owner_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File owner id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_owner_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "file_group_ids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "file_group_id")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("File group id : %s\n", key);
							add_integer_uniq(&clusters[count-1].file_group_ids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}				
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "euids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "euid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Euid : %s\n", key);
							add_integer_uniq(&clusters[count-1].euids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "egids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "egid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Egid : %s\n", key);
							add_integer_uniq(&clusters[count-1].egids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "ruids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "ruid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Ruids : %s\n", key);
							add_integer_uniq(&clusters[count-1].ruids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "rgids")){
					temp = cluster->xmlChildrenNode;
					while(temp != NULL){
						if(!xmlStrcmp(temp->name, (const xmlChar *) "rgid")){
							key = xmlNodeListGetString(doc, temp->xmlChildrenNode, 1);
							printf("Rgid : %s\n", key);
							add_integer_uniq(&clusters[count-1].rgids, atoi(key));
							xmlFree(key);
						}
						temp = temp->next;
					}
				}

				else if (!xmlStrcmp(cluster->name, (const xmlChar *) "cluster_size")){
					key = xmlNodeListGetString(doc, cluster->xmlChildrenNode, 1);
					printf("Cluster size : %s\n", key);
					xmlFree(key);
				}
				cluster = cluster->next;
			}
		}
		cur = cur->next;
	}
	*clusters_number = count;
	xmlFreeDoc(doc);
	return clusters;
	
}
