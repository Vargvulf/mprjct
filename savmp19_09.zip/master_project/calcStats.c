#include <stdio.h>

#include <stdlib.h>
#include "clusterers.h"
#include "converters.h"

int main(int argc, char* argv[]){

struct open_entry * entries = NULL;
/**
    struct open_result_entry * res;
    res = open_convert_data(argv[1],atoi(argv[2]));
    if (res != NULL){
        printf("Mean : %d\n",res->length_mean);
        printf("Variance : %d\n",res->length_variance);
    }
    else
        printf("Operation failed !");
**/
/**
	int ** res2 = NULL;
    res2 = open_cluster(argv[1],atoi(argv[2]));
**/
   
   entries = open_load_file(argv[1], atoi(argv[2]));
   open_cluster(entries, atoi(argv[2]));
}
