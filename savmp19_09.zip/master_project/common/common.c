#include "common.h"

struct open_entry * open_load_file(char * filename, int size){

    struct open_entry  * entries = (struct open_entry *) calloc(size, sizeof(struct open_entry));
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    printf("Size : %d\n", size);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[100];
       while(fgets(line,100,infile) != NULL){
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token));
           strncpy(entries[count].syscall, token, strlen(token));
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token));
           strncpy(entries[count].path, token, strlen(token));
           token = strtok(NULL,",");
           entries[count].flags = (char *) malloc(strlen(token));
           strncpy(entries[count].flags, token, strlen(token));
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
           return entries;
       }

    }
}
