#include "clusterers.h"

/**
#########################################################################################
# Clustering methods for OPEN system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Flags | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Flags : Simple matching | Return_value : Manhattan
#########################################################################################
**/

struct open_transformed_entry * open_transform_data(struct open_entry * entries, int size){
	
	struct open_transformed_entry * results = (struct open_transformed_entry *) calloc(size, sizeof(struct open_transformed_entry));
	int i = 0;

	for (i=0; i< size; i++){
		results[i].syscall = entries[i].syscall;
		results[i].path_length = strlen(entries[i].syscall);
		int depth = -1;
	    char * token;
        char * prev_token;
		token = strtok(entries[i].path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		results[i].filename = prev_token;
		results[i].flags = entries[i].flags;
		results[i].retValue = entries[i].retValue;
	}

	return results;
}

int ** open_cluster(struct open_entry * entries, int size){
	struct open_transformed_entry * results = NULL;
	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = open_transform_data(entries, size);
	    int  i = 0;
		for (i=0; i<size; i++){
            printf("###################################\n");
			printf("Syscall : %s\n", results[i].syscall);
			printf("PathLength : %d\n", results[i].path_length);
			printf("PathDepth : %d\n", results[i].path_depth);
			printf("Filename : %s\n", results[i].filename);
			printf("Flags : %s\n", results[i].flags);
			printf("RetValue : %d\n", results[i].retValue);
		} 
        return NULL;
    }
}
