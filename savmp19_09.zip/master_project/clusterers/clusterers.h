#ifndef CLUSTERERS_H
#define CLUSTERERS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"

struct open_transformed_entry {
	char * syscall;
	int path_length;
	int path_depth;
	char * filename;
    char * flags;
	int retValue;
};
	
int ** open_cluster(struct open_entry * entries, int size);
struct open_transformed_entry * open_transform_data(struct open_entry * entries, int size);
#endif
