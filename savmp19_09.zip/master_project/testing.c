#include <stdio.h>
#include <stdlib.h>
#include "convertors/open_convertor.h"


int main(void){

struct entry et1;

et1.retValue = 3;

printf("%d",et1.retValue);

return 0;


}
