#ifndef CONVERTERS_H
#define CONVERTERS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gsl/gsl_statistics_int.h>
#include "common.h"

struct open_result_entry * open_convert_data(char* filename, int size);

#endif
