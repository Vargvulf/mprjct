#include <stdio.h>
#include <stdlib.h>
#include "common/common.h"


int main(void){

//struct string  * str1 = (struct string *) malloc(sizeof(struct string));
struct string ** str1 = (struct string **) malloc(sizeof(struct string *));
int i = 0;

add_string_uniq(str1,"W");
add_string_uniq(str1,"R");
add_string_uniq(str1,"RW");
add_string_uniq(str1,"WT");

for (i=0; i<4; i++)
	printf("%s\n",get_string(*str1,i)->string);

walk_strings(*str1);
return 0;


}
