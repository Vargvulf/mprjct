rm results/putmsg/*
rm results/sysinfo/*

./calcStats putmsg_new 1 1 > res_putmsg
./calcStats sysinfo_new 1 1 > res_sysinfo
