rm results/open/*
rm results/close/*
rm results/stat/*
rm results/mmap/*
rm results/access/*
rm results/munmap/*

./calcStats open_new 12 4 > res_open
./calcStats close_new 20 5 > res_close
./calcStats stat_new 20 3 > res_stat
./calcStats mmap_new 25 3 > res_mmap
./calcStats access_new 2 2 > res_access
./calcStats munmap_new 8 2 > res_munmap
