#include "common.h"



double mean_double(double * data, int size){
	double sum = 0;
	int i = 0;
	for(i=0; i<size; i++)
		sum += data[i];
	return sum/size;
}

int mean_int(int * data, int size){
	int i,sum = 0;
	for(i=0; i<size; i++)
		sum += data[i];
	return sum/size;
}

double variance_double(double * data, int size){
	int i=0;
	double mean = mean_double(data, size);
	double sum = 0;
	for(i=0; i<size; i++)
		sum += pow(data[i] - mean,2);
	if (size > 1)
		return sum/(size-1);
	else
		return 0;
}

int variance_int(int * data, int size){
	int i,sum = 0;
	int mean = mean_int(data, size);
	for(i=0; i<size; i++)
		sum += pow(data[i] - mean,2);
	if (size > 1)
		return sum/(size-1);
	else
		return 0;
}

/**
################## Loading open syscall file ##################
**/
struct open_entry * open_load_file(char * filename, int *size){

    struct open_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct open_entry *) realloc(entries, (count +1)*sizeof(struct open_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].flags = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].flags, token, strlen(token));
		   entries[count].flags[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading close syscall file ##################
**/

struct close_entry * close_load_file(char * filename, int *size){

    struct close_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct close_entry *) realloc(entries, (count +1)*sizeof(struct close_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}


/**
################## Loading mmap syscall file ##################
**/

struct mmap_entry * mmap_load_file(char * filename, int *size){

    struct mmap_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct mmap_entry *) realloc(entries, (count+1)*sizeof(struct mmap_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
		   token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;	
           return entries;
       }

    }
}


/**
################## Loading stat syscall file ##################
**/

struct stat_entry * stat_load_file(char * filename, int *size){

    struct stat_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct stat_entry *) realloc(entries, (count+1)*sizeof(struct stat_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
		   token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;	
           return entries;
       }

    }
}

/**
################## Loading access syscall file ##################
**/

struct access_entry * access_load_file(char * filename, int *size){

    struct access_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct access_entry *) realloc(entries, (count+1)*sizeof(struct access_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
		   token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;	
           return entries;
       }

    }
}


/**
################## Loading munmap syscall file ##################
**/

struct munmap_entry * munmap_load_file(char * filename, int *size){

    struct munmap_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct munmap_entry *) realloc(entries, (count+1)*sizeof(struct munmap_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].address = strtol(token + 2, &temp, 16);
		   printf("Address : %s : %d\n",token, entries[count].address);
		   token = strtok(NULL,",");
           entries[count].length = strtol(token + 2, &temp, 16);
		   printf("Length : %s : %d\n",token, entries[count].length);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading putmsg syscall file ##################
**/

struct putmsg_entry * putmsg_load_file(char * filename, int *size){

    struct putmsg_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct putmsg_entry *) realloc(entries, (count+1)*sizeof(struct putmsg_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].filedes = strtol(token + 2, &temp, 16);
		   printf("Filedes : %d\n", entries[count].filedes);
		   token = strtok(NULL,",");
           entries[count].flags = strtol(token + 2, &temp, 16);
		   printf("Flags : %d\n", entries[count].flags);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading sysinfo syscall file ##################
**/

struct sysinfo_entry * sysinfo_load_file(char * filename, int *size){

    struct sysinfo_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct sysinfo_entry *) realloc(entries, (count+1)*sizeof(struct sysinfo_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].command = strtol(token + 2, &temp, 16);
		   printf("Command : %d\n", entries[count].command);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}


/**
################## Loading seteuid syscall file ##################
**/

struct seteuid_entry * seteuid_load_file(char * filename, int *size){

    struct seteuid_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct seteuid_entry*) realloc(entries, (count+1)*sizeof(struct seteuid_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].euid = strtol(token + 2, &temp, 16);
		   printf("Euid : %d\n", entries[count].euid);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].p_euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading setgid syscall file ##################
**/

struct setgid_entry * setgid_load_file(char * filename, int *size){

    struct setgid_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct setgid_entry *) realloc(entries, (count+1)*sizeof(struct setgid_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].gid = strtol(token + 2, &temp, 16);
		   printf("Gid : %d\n", entries[count].gid);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading setgroups syscall file ##################
**/

struct setgroups_entry * setgroups_load_file(char * filename, int *size){

    struct setgroups_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct setgroups_entry *) realloc(entries, (count+1)*sizeof(struct setgroups_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].ngroups = strtol(token + 2, &temp, 16);
		   printf("Ngroups : %d\n", entries[count].ngroups);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading setegid syscall file ##################
**/

struct setegid_entry * setegid_load_file(char * filename, int *size){

    struct setegid_entry  * entries =NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct setegid_entry *) realloc(entries, (count +1)*sizeof(struct setegid_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].egid = strtol(token + 2, &temp, 16);
		   printf("Egid : %d\n", entries[count].egid);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].p_egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}


/**
Computes the levenshtein distance between two strings
**/
int levenshtein_distance(char * str1, char * str2){

	int len_str1 = strlen(str1);
	int len_str2 = strlen(str2);
	int i = 0;
	int j = 0;
	int d[len_str1 +1][len_str2+1];

	for (i=0; i<= len_str1; i++)
		for (j=0; j<= len_str2; j++)
			d[i][j] = -1;

	int dist(int i, int j){
		if (d[i][j] >= 0) return d[i][j];
		
		int x;
		if (i == len_str1)
			x = len_str2 - j;
		else if (j == len_str2)
			x = len_str1 - i;
		else if (str1[i] == str2[j])
			x = dist(i + 1, j + 1);
		else{
			x = dist(i+1, j+1);
			
			int y;
			if ((y = dist(i,j + 1)) < x) x=y;
			if ((y = dist(i+1, j)) < x) x=y;
			x++;
		}
		return d[i][j] = x;
	}
	return dist(0, 0);
}


/******************************************
String argument data structure operations
******************************************/


void free_string(struct string * head){
	struct string * walker = head;
	struct string * temp = NULL;
	while(walker != NULL){
		free(walker->string);
		temp = walker;
		walker = walker->next;
		free(temp);
	}
}

void add_string_uniq(struct string ** head, char * string){
	struct string * walker = *head;
	struct string * prev_walker = NULL;
	struct string * new_node = (struct string *) malloc(sizeof(struct string));
	new_node->string = (char *) malloc(strlen(string) + 1);
	strncpy(new_node->string,string,strlen(string));
	new_node->string[strlen(string)] = '\0';
	new_node->next = NULL;

	if (*head == NULL){
		*head = new_node;
		return; 
	}
	else{
		while(walker != NULL){
			if (strcmp((walker)->string,string) == 0){
				free(new_node->string);
				free(new_node);
				return;
			 }
			prev_walker = (walker);
			walker = (walker)->next;
		}
	    (prev_walker)->next = new_node;
	}
}

void walk_strings(struct string * head){
	struct string * walker = head;
	while(walker != NULL){
		printf("%s\n",walker->string);
		walker = walker->next;
	}
}

int strings_list_size(struct string *head){

	int size = 0;
	struct string * walker = head;	
	while(walker != NULL){
		size++;
		walker = walker->next;
	}
	return size;
}

struct string *get_string(struct string * head, int index){
	int count = 0;
	struct string * walker = head;
	struct string * result = walker;
	if (index >= strings_list_size(head))
		return NULL;
	while(count != index){
		result = result->next;
		count++;
	}
	return result;
}

bool string_list_contains(struct string * head, char * string){
	int i = 0;
	for(i=0; i<strings_list_size(head);i++){
		if(strcmp(string,get_string(head,i)->string) == 0)
			return true;
	}
	return false;
}

/******************************************
Integer argument data structure operations
******************************************/

void free_integer(struct integer * head){
	struct integer * walker = head;
	struct integer * temp = NULL;
	while(walker != NULL){
		temp = walker;
		walker = walker->next;
		free(temp);
	}
}

void add_integer_uniq(struct integer ** head, int integer){
	struct integer * walker = *head;
	struct integer * prev_walker = NULL;
	struct integer * new_node = (struct integer *) malloc(sizeof(struct integer));
	new_node->integer = integer;
	new_node->next = NULL;

	if (*head == NULL){
		*head = new_node;
		return; 
	}
	else{
		while(walker != NULL){
			if ((walker)->integer == integer){
				free(new_node);
				return;
			 }
			prev_walker = (walker);
			walker = (walker)->next;
		}
	    (prev_walker)->next = new_node;
	}
}

void walk_integers(struct integer * head){
	struct integer * walker = head;
	while(walker != NULL){
		printf("%d\n",walker->integer);
		walker = walker->next;
	}
}

int integers_list_size(struct integer *head){

	int size = 0;
	struct integer * walker = head;	
	while(walker != NULL){
		size++;
		walker = walker->next;
	}
	return size;
}

struct integer *get_integer(struct integer * head, int index){
	int count = 0;
	struct integer * walker = head;
	struct integer * result = walker;
	if (index >= integers_list_size(head))
		return NULL;
	while(count != index){
		result = result->next;
		count++;
	}
	return result;
}

bool integer_list_contains(struct integer * head, int integer){
	int i = 0;
	for(i=0; i<integers_list_size(head);i++)
		if(get_integer(head,i)->integer == integer)
			return true;
	return false;
}

/**
################## Loading chdir syscall file ##################
**/

struct chdir_entry * chdir_load_file(char * filename, int *size){

    struct chdir_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct chdir_entry *) realloc(entries, (count +1)*sizeof(struct chdir_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading readlink syscall file ##################
**/

struct readlink_entry * readlink_load_file(char * filename, int *size){

    struct readlink_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct readlink_entry *) realloc(entries, (count+1)*sizeof(struct readlink_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading unlink syscall file ##################
**/

struct unlink_entry * unlink_load_file(char * filename, int *size){

    struct unlink_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct unlink_entry *) realloc(entries, (count+1)*sizeof(struct unlink_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
	       token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading creat syscall file ##################
**/

struct creat_entry * creat_load_file(char * filename, int *size){

    struct creat_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
	       entries = (struct creat_entry *) realloc(entries, (count+1)*sizeof(struct creat_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading lstat syscall file ##################
**/

struct lstat_entry * lstat_load_file(char * filename, int *size){

    struct lstat_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct lstat_entry *) realloc(entries, (count+1)*sizeof(struct lstat_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}


/**
################## Loading rename syscall file ##################
**/

struct rename_entry * rename_load_file(char * filename, int *size){

    struct rename_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct rename_entry *) realloc(entries, (count+1)*sizeof(struct rename_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path1 = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path1, token, strlen(token));
		   entries[count].path1[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode1 = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file1_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file1_group_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].path2 = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path2, token, strlen(token));
		   entries[count].path2[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode2 = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file2_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file2_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}


/**
################## Loading ioctl syscall file ##################
**/

struct ioctl_entry * ioctl_load_file(char * filename, int *size){

    struct ioctl_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct ioctl_entry *) realloc(entries, (count+1)*sizeof(struct ioctl_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].command = atoi(token);
           token = strtok(NULL,",");
           entries[count].arg = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading getmsg syscall file ##################
**/

struct getmsg_entry * getmsg_load_file(char * filename, int *size){

    struct getmsg_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, *temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct getmsg_entry *) realloc(entries, (count+1)*sizeof(struct getmsg_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].filedes = strtol(token + 2, &temp, 16);
		   printf("Filedes : %d\n", entries[count].filedes);
		   token = strtok(NULL,",");
           entries[count].flags = strtol(token + 2, &temp, 16);
		   printf("Flags : %d\n", entries[count].flags);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}


/**
################## Loading setuid syscall file ##################
**/

struct setuid_entry * setuid_load_file(char * filename, int *size){

    struct setuid_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct setuid_entry *) realloc(entries, (count+1)*sizeof(struct setuid_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].uid = strtol(token + 2, &temp, 16);
		   printf("Uid : %d\n", entries[count].uid);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}
/**
################## Loading vfork syscall file ##################
**/

struct vfork_entry * vfork_load_file(char * filename, int *size){

    struct vfork_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token, * temp = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct vfork_entry *) realloc(entries, (count+1)*sizeof(struct vfork_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].pid = strtol(token + 2, &temp, 16);
		   printf("Pid : %d\n", entries[count].pid);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   printf("RetValue : %d\n",entries[count].retValue);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading chown syscall file ##################
**/

struct chown_entry * chown_load_file(char * filename, int *size){

    struct chown_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct chown_entry *) realloc(entries, (count+1)*sizeof(struct chown_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].owner = atoi(token);
           token = strtok(NULL,",");
           entries[count].group = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading chroot syscall file ##################
**/

struct chroot_entry * chroot_load_file(char * filename, int *size){

    struct chroot_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct chroot_entry *) realloc(entries, (count+1)*sizeof(struct chroot_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading sockconnect syscall file ##################
**/

struct sockconnect_entry * sockconnect_load_file(char * filename, int *size){

    struct sockconnect_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct sockconnect_entry *) realloc(entries, (count+1)*sizeof(struct sockconnect_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].socket_type = atoi(token);
		   token = strtok(NULL,",");
           entries[count].port = atoi(token);
		   token = strtok(NULL,",");
           entries[count].address = atoi(token);
           token = strtok(NULL,",");
           entries[count].fd = atoi(token);
           token = strtok(NULL,",");
           entries[count].priority = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading fcntl syscall file ##################
**/

struct fcntl_entry * fcntl_load_file(char * filename, int *size){

    struct fcntl_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct fcntl_entry *) realloc(entries, (count+1)*sizeof(struct fcntl_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].command = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}

/**
################## Loading fchown syscall file ##################
**/

struct fchown_entry * fchown_load_file(char * filename, int *size){

    struct fchown_entry  * entries = NULL;
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[400];
       while(fgets(line,400,infile) != NULL){
		   entries = (struct fchown_entry *) realloc(entries, (count+1)*sizeof(struct fchown_entry));
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].syscall, token, strlen(token));
		   entries[count].syscall[strlen(token)]='\0';
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token)+1);
           strncpy(entries[count].path, token, strlen(token));
		   entries[count].path[strlen(token)] = '\0';
           token = strtok(NULL,",");
           entries[count].filemode = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_owner_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].file_group_id = atoi(token);
		   token = strtok(NULL,",");
           entries[count].owner = atoi(token);
		   token = strtok(NULL,",");
           entries[count].group = atoi(token);
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
		   token = strtok(NULL,",");
           entries[count].euid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].egid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].ruid = atoi(token);
		   token = strtok(NULL,",");
           entries[count].rgid = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
		   *size = count;
           return entries;
       }

    }
}


