#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>


int main(void){

	printf("Yo !\n");
	return 0;
}
