#include "converters.h"

/*
OPEN sytem call converter
Input structure : OPEN,path,flags,retValue
Output structure : OPEN,length_mean,length_variance,flags,retValue
*/

struct open_result_entry * open_convert_data(char * filename, int size){

    struct open_entry  * entries;
    int lengths[size];
    struct open_result_entry * result = NULL;
    int i = 0;


    entries = open_load_file(filename, &size);

    if (entries == NULL){
        printf("Error processing file \n");
        return NULL;
    }

    else{
        for (i=0; i<size; i++)
            lengths[i] = strlen(entries[i].path);
        for (i=0; i<size; i++)
            printf("Length %d : %d\n",i,lengths[i]);

        printf("Finished reading the file !\n");
        result = (struct open_result_entry *) malloc(sizeof(struct open_result_entry));
        result->length_mean = gsl_stats_int_mean(lengths,1,size);
        result->length_variance = gsl_stats_int_variance(lengths,1,size);
        result->flags = entries[0].flags;
        result->retValue = entries[0].retValue;
        for (i=0; i<size; i++){
            free(entries[i].syscall);
            free(entries[i].path);
            free(entries[i].flags);
        }
        return result;
    }
}
