#include <stdio.h>

#include <stdlib.h>
#include "clusterers.h"
#include "converters.h"

int main(int argc, char* argv[]){

	struct open_entry * entries = NULL;
	struct open_transformed_entry * tr_entries = NULL;
	struct open_cluster * clusters = NULL;
	struct open_cluster cluster;
	int i;
/**
    struct open_result_entry * res;
    res = open_convert_data(argv[1],atoi(argv[2]));
    if (res != NULL){
        printf("Mean : %d\n",res->length_mean);
        printf("Variance : %d\n",res->length_variance);
    }
    else
        printf("Operation failed !");
**/
/**
	int ** res2 = NULL;
    res2 = open_cluster(argv[1],atoi(argv[2]));
**/
    entries = open_load_file(argv[1], atoi(argv[2]));
	printf("###### %s ########\n",entries[0].path);
    clusters = open_cluster(entries, atoi(argv[2]), 6);

	tr_entries = open_transform_data(entries,atoi(argv[2]));
    for (i=0; i< atoi(argv[2]); i++){
		cluster = match_entry_to_cluster(clusters,6,tr_entries[i]);
		printf("\nMatch for : \n");
		printf("\t%s:%s:%d",entries[i].path,entries[i].flags,entries[i].retValue);
		printf("\nCluster : %s \n",cluster.syscall);
	}	
}
