#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct open_entry {
char * syscall;
char * path;
char * flags;
int retValue;
};

struct open_result_entry {
char * syscall;
int length_mean;
int length_variance;
char * flags;
int retValue;
};

struct open_entry * open_load_file(char * filename, int size);

int levenshtein_distance(char * str1, char * str2);
#endif
