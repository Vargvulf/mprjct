#include "common.h"

struct open_entry * open_load_file(char * filename, int size){

    struct open_entry  * entries = (struct open_entry *) calloc(size, sizeof(struct open_entry));
    FILE * infile = NULL;
    int count = 0;
	char * token = NULL;
    
    printf("Filename : %s\n", filename);
    printf("Size : %d\n", size);
    infile = fopen(filename, "r");
    if (infile == NULL){
        printf("Could not open the data file !\n");
        return NULL;
    }
    else{
       printf("File opened\n");
       char line[100];
       while(fgets(line,100,infile) != NULL){
           printf("Count : %d\n",count);
		   printf("%s\n",line);
           token = strtok(line,",");
           entries[count].syscall = (char *) malloc(strlen(token));
           strncpy(entries[count].syscall, token, strlen(token));
           token = strtok(NULL,",");
           entries[count].path = (char *) malloc(strlen(token));
           strncpy(entries[count].path, token, strlen(token));
           token = strtok(NULL,",");
           entries[count].flags = (char *) malloc(strlen(token));
           strncpy(entries[count].flags, token, strlen(token));
           token = strtok(NULL,",");
           entries[count].retValue = atoi(token);
           count++;
		   printf("About to read\n");
       }
       if(ferror(infile)){
	       printf("Error while reading file");
		   return NULL;
	   }
       else{
	       printf("END");
           fclose(infile);
           return entries;
       }

    }
}


/**
Computes the levenshtein distance between two strings
**/
int levenshtein_distance(char * str1, char * str2){

	int len_str1 = strlen(str1);
	int len_str2 = strlen(str2);
	int i = 0;
	int j = 0;
	int d[len_str1 +1][len_str2+1];

	for (i=0; i<= len_str1; i++)
		for (j=0; j<= len_str2; j++)
			d[i][j] = -1;

	int dist(int i, int j){
		if (d[i][j] >= 0) return d[i][j];
		
		int x;
		if (i == len_str1)
			x = len_str2 - j;
		else if (j == len_str2)
			x = len_str1 - i;
		else if (str1[i] == str2[j])
			x = dist(i + 1, j + 1);
		else{
			x = dist(i+1, j+1);
			
			int y;
			if ((y = dist(i,j + 1)) < x) x=y;
			if ((y = dist(i+1, j)) < x) x=y;
			x++;
		}
		return d[i][j] = x;
	}
	return dist(0, 0);
}
