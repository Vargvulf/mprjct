#include "clusterers.h"


/**
########################################################################################
# Performs hierarchical clustering
# Returns a 2-dimensional array of booleans which size is the number of clusters and 
# each row denotes one cluster where the bits set correspond to the members of the cluster
# The distance between two clusters is defined as the average of the 
# distances between any of their members
#########################################################################################
**/

bool ** hierarchical_clustering(double ** distance_matrix, int size, int max_clusters_number){

	int i,j,k,l,count = 0;
	double smallest_distance,temp = 0;
	int smallest_distance_clusters;
	int number_of_clusters = size;
	double  * cluster_distances = NULL;
	bool * (* clusters) = (bool **) calloc(size,sizeof(bool *));
	for (i=0; i<size; i++){
		clusters[i] = (bool *) calloc(size,sizeof(bool));
		if (clusters[i] == NULL)
			printf("Could not allocate memory for cluster !");
	}
	bool * (* new_clusters) = NULL;
	

    // Initialize the clusters : each entry is in one cluster	
	for (i=0; i<size; i++)
		for(j=0; j<size; j++){
			if (i==j)
				clusters[i][j] = true;
			else 
				clusters[i][j] = false;
		}

	printf("Size : %d", size);
	printf("######### CLUSTERS #########\n");
	for (i=0; i<size; i++){
		printf("i : %d \n",i);
		for (j=0; j<size; j++)
			printf("%d ",clusters[i][j]);
	}
	printf("\n###########################\n");


	while(number_of_clusters >  max_clusters_number){

		// Compute the distances between the clusters
		// Uses average for now
		// Linear mapping : d(i,j) = cluster_distances[i*n + j]

		// Note : There will be some unused positions in the cluster distances since we don't need
        //        number_of_clusters*number_of_clusters distances.
		//        Allocating only number_of_clusters*(number_of_clusters-1)/2 saves space but makes
		//        it hard to find the clusters given a position in the cluster_distances array. 
    	cluster_distances = (double *) calloc(number_of_clusters*number_of_clusters,sizeof(double));
		for (i=0; i < number_of_clusters*number_of_clusters; i++)
			cluster_distances[i] = 999;
		for (i=0; i<number_of_clusters; i++)
			for(j=i+1; j<number_of_clusters; j++){
				temp = compute_cluster_distances(clusters[i], clusters[j], distance_matrix, size);
				cluster_distances[i*number_of_clusters + j] = temp;
				cluster_distances[j*number_of_clusters + i] = temp;
			}

		/**
		printf ("Distance between the clusters : \n");
		for (i=0; i<number_of_clusters; i++){
			printf("\n");
			for(j=0; j<number_of_clusters; j++)
				if (i !=j)
					printf("%d:%d => %f ",i,j, cluster_distances[i*size +j]);
		}
		**/
			
		// Pick smallest distance
		smallest_distance = cluster_distances[0];
		k = 0;
		l = 0;
		smallest_distance_clusters = 0;
		for (i=0; i<number_of_clusters; i++){
			for(j=i+1; j<number_of_clusters; j++)
			    if(cluster_distances[i*number_of_clusters + j] < smallest_distance){
					smallest_distance = cluster_distances[i*number_of_clusters + j];
					k = i;
					l = j;
				}
		}
	
		// Merge clusters
	
		printf("\nSmallest distance : %f", smallest_distance);
		printf("\nChosen clusters %d : %d - %d\n", smallest_distance_clusters, k,l);

		printf("Cluster 1 :\n");
		for (i=0; i<size; i++)
			printf("%d",clusters[k][i]);
		printf("\nCluster 2:\n");
		for (i=0; i<size; i++)
			printf("%d",clusters[l][i]);
	
		// XOR the two clusters to merge
		for (i=0; i<size; i++){
			printf("\n%d",clusters[k][i]);
			clusters[k][i] ^= clusters[l][i];
			printf("%d",clusters[k][i]);
		}
	
		printf("\nXored");
		printf("\nXored");
		// Generate new set of clusters
	
		new_clusters = (bool **) calloc(number_of_clusters-1,sizeof(bool *));
		for (i=0; i<number_of_clusters-1; i++)
			new_clusters[i] = (bool *) calloc(size,sizeof(bool));

		printf("\nAllocated");
		printf("\nAllocated");
	
		count = 0;	
		for (i=0; i<number_of_clusters; i++){
			if (i != l){
				for(j=0; j<size; j++)
					new_clusters[count][j] = clusters[i][j];
				count++;
			}
		}

		// Freeing the old clusters
	    for (i=0; i<number_of_clusters; i++)
			free(clusters[i]);
		free(clusters);

		clusters = new_clusters;
		number_of_clusters--;
					
		// Redo while number of clusters not sufficient

		printf("######### CLUSTERS ###########\n");	
		for (i=0; i<number_of_clusters; i++){
			printf("\n");
			for (j=0; j<size; j++)
				printf("%d ",clusters[i][j]);
		}
		printf("\n#############################\n");

	}

    printf("######### Final CLUSTERS ###########\n");	
	for (i=0; i<number_of_clusters; i++){
		printf("\n");
		for (j=0; j<size; j++)
			printf("%d ",clusters[i][j]);
	}
	printf("\n#############################\n");

	return clusters;
}

double compute_cluster_distances(bool * cluster1, bool * cluster2, double ** distance_matrix, int size){

	int i,j;
	double total_distance = 0;
	int number_distances = 0;

	for(i=0; i<size; i++)
		if (cluster1[i] == true)
			for(j=0; j<size; j++)
				if (cluster2[j] == true){
					total_distance += distance_matrix[i][j];
					number_distances++;
				}
	//printf ("Total distance : %f\n", total_distance);
	//printf ("Number distances : %d\n", number_distances);
	
	return total_distance/number_distances;
}




/**
#########################################################################################
# Clustering methods for OPEN system call
# Sample format : Sycall | Path_length | Path_depth | Filename | Flags | Return_value
# Distances : Syscall : x ; Path_length : Manhattan ; Path_depth : Manhattan
#             Filename : Levenshtein | Flags : Simple matching | Return_value : Manhattan
#########################################################################################
**/

struct open_transformed_entry * open_transform_data(struct open_entry * entries, int size){
	
	struct open_transformed_entry * results = (struct open_transformed_entry *) calloc(size, sizeof(struct open_transformed_entry));
	int i = 0;
	char * path = NULL;

	for (i=0; i< size; i++){
		results[i].syscall = (char *) malloc(strlen(entries[i].syscall) + 1);
		strncpy(results[i].syscall,entries[i].syscall,strlen(entries[i].syscall)+1);
		results[i].path_length = strlen(entries[i].path);
		int depth = -1;
	    char * token;
        char * prev_token;
		path = (char *) malloc(results[i].path_length+1);
		strncpy(path,entries[i].path,strlen(entries[i].path)+1);
		token = strtok(path,"/");
        while(token != NULL){
			depth++;
			prev_token = token;
            token = strtok(NULL,"/");
		}
		results[i].path_depth = depth;
		results[i].filename = prev_token;
		results[i].flags = entries[i].flags;
		results[i].retValue = entries[i].retValue;
	}

    results = open_normalize_data(results, size);

	return results;
}

struct open_cluster * open_cluster(struct open_entry * entries, int size, int max_clusters_number){
	struct open_transformed_entry * results = NULL;
	int i,j;
	double temp;
	double params[8];
	double  ** distance_matrix = malloc(sizeof(double *)*size);
	for(i=0; i<size; i++)
		distance_matrix[i] = malloc(sizeof(double)*size);
	bool ** raw_open_clusters = NULL;
	struct open_cluster * open_clusters = NULL;


	printf("Called !");

    if (entries == NULL){
        printf("Error processing the data\n");
        return NULL;
    }
    else {
	    results = open_transform_data(entries, size);
	    int  i = 0;
		for (i=0; i<size; i++){
            printf("###################################\n");
			printf("Syscall : %s\n", results[i].syscall);
			printf("PathLength : %f\n", results[i].z_score_path_length);
			printf("PathDepth : %f\n", results[i].z_score_path_depth);
			printf("Filename : %s\n", results[i].filename);
			printf("Flags : %s\n", results[i].flags);
			printf("RetValue : %f\n", results[i].z_score_retValue);
		}

		params[0] = open_min_max_path_length(results, size, false);
		params[1] = open_min_max_path_length(results, size, true);
		params[2] = open_min_max_path_depth(results, size, false);
		params[3] = open_min_max_path_depth(results, size, true);
		params[4] = open_min_max_retValue(results, size, false);
		params[5] = open_min_max_retValue(results, size, true);
		params[6] = open_min_max_filename(results, size, false);
		params[7] = open_min_max_filename(results, size, true);

		for (i=0; i<size; i++)
			distance_matrix[i][i] = 0;

		for (i=0; i<size; i++)
			for(j=i+1; j<size; j++){
				printf ("Processing %d : %d\n",i,j);
				distance_matrix[i][j] = open_entries_distance(results,size,i,j,params);
				distance_matrix[j][i] = distance_matrix[i][j];
			}

		/**
		printf("####################################\n");
		printf("Entries distance matrix : \n");
		for (i=0; i<size; i++){
			for(j=0; j<size; j++)
				printf("%f ",distance_matrix[i][j]);		
			printf("\n");
		}
		**/
		raw_open_clusters = hierarchical_clustering(distance_matrix,size,max_clusters_number);

		open_clusters = model_open_clusters(results, size, raw_open_clusters, max_clusters_number);

		for(i=0; i<max_clusters_number; i++){
			printf("Cluster : %d \n",i);
			printf("Syscall : %s \n",open_clusters[i].syscall);
			printf("Path length mean : %f \n", open_clusters[i].path_length_mean);
			printf("Path length variance : %f \n", open_clusters[i].path_length_variance);
			printf("Path depth mean : %f \n", open_clusters[i].path_depth_mean);
			printf("Path depth variance : %f \n", open_clusters[i].path_depth_variance);
			printf("Filenames : \n");
			for(j=0; j<open_clusters[i].cluster_size; j++)
				printf("\t%s\n",open_clusters[i].filenames[j]);
			printf("Flags : \n");
			for (j=0; j<open_clusters[i].cluster_size; j++)
				printf("\t%s\n",open_clusters[i].flags[j]);
			printf("RetValues : \n");
			for (j=0; j<open_clusters[i].cluster_size; j++)
				printf("\t%d\n",open_clusters[i].retValues[j]);
			printf("########################################\n");
		}

		// Need to free the distance matrix !!
        return open_clusters;
    }
}



struct open_cluster * model_open_clusters(struct open_transformed_entry * entries, int size, bool ** raw_clusters, int clusters_number){

	int i,j,k,cluster_size=0;
	int cluster_sizes[clusters_number];
	double * cluster_path_lengths = NULL;
	double * cluster_path_depths  = NULL;
	char ** cluster_filenames = NULL;
	char ** cluster_flags = NULL;
	int * cluster_retvals = NULL;
	struct open_cluster * open_clusters = (struct open_cluster *) calloc(clusters_number, sizeof(struct open_cluster));

	for (i=0; i < clusters_number; i++){
		cluster_size = 0;
		for (j = 0; j < size; j++)
			if (raw_clusters[i][j] == true)
				cluster_size++;
		cluster_sizes[i] = cluster_size;
	}

	for(i=0; i < clusters_number; i++){
		cluster_path_lengths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_path_depths = (double *) calloc(cluster_sizes[i], sizeof(double));
		cluster_filenames = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_flags = (char **) calloc(cluster_sizes[i], sizeof(char *));
		cluster_retvals = (int *) calloc(cluster_sizes[i], sizeof(int));
		k = 0;
		for(j=0; j < size; j++)
			if (raw_clusters[i][j] == true){
				cluster_path_lengths[k] = entries[j].path_length;
				cluster_path_depths[k] = entries[j].path_depth;
				cluster_filenames[k] = entries[j].filename;
				cluster_flags[k] = entries[j].flags;
				cluster_retvals[k++] = entries[j].retValue;
			}
		printf("\nCluster path depths :\n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_depths[j]);
		printf("\nCluster path lengths : \n");
		for (j=0; j<cluster_sizes[i]; j++)
			printf("%f\n",cluster_path_lengths[j]);
		/*** DANGER : Cluster number might need more than one character ! ***/
		open_clusters[i].syscall = (char *) malloc(strlen(entries[i].syscall)+1);
		strncpy(open_clusters[i].syscall, entries[i].syscall, strlen(entries[i].syscall)+1);
		snprintf(open_clusters[i].syscall + strlen(entries[i].syscall),2,"%d",i);
		open_clusters[i].path_length_mean = gsl_stats_mean(cluster_path_lengths, 1, cluster_sizes[i]);
		open_clusters[i].path_length_variance = gsl_stats_variance(cluster_path_lengths, 1, cluster_sizes[i]);
		open_clusters[i].path_depth_mean = gsl_stats_mean(cluster_path_depths, 1, cluster_sizes[i]);
		open_clusters[i].path_depth_variance = gsl_stats_variance(cluster_path_depths, 1, cluster_sizes[i]);
		open_clusters[i].filenames = cluster_filenames;
		open_clusters[i].flags = cluster_flags;
		open_clusters[i].retValues = cluster_retvals;
		open_clusters[i].cluster_size = cluster_sizes[i];
		
		free(cluster_path_lengths);
		free(cluster_path_depths);
	}

	return open_clusters;
				
}
/**
Computes the z-score for the path length, the path depth and the return value of the OPEN syscall
entries
**/

struct open_transformed_entry * open_normalize_data(struct open_transformed_entry * entries, int size) {

	int i = 0;
	double path_length_mean = 0;
    double path_length_mabsd = 0;
	double path_depth_mean = 0;
	double path_depth_mabsd = 0;
    double retvalue_mean = 0;
	double retvalue_mabsd = 0;
	double path_lengths_entries[size];
	double path_depths_entries[size];
	double retvalues_entries[size];

	// Gather all the path lengths, path depths and returne values
	for (i=0; i<size; i++){
		path_lengths_entries[i] = entries[i].path_length;
		path_depths_entries[i] = entries[i].path_depth;
		retvalues_entries[i] = entries[i].retValue;
	}

	// Calculate the means
	path_length_mean = gsl_stats_mean(path_lengths_entries, 1, size);
	path_depth_mean = gsl_stats_mean(path_depths_entries, 1, size);
	retvalue_mean = gsl_stats_mean(retvalues_entries, 1, size);

	// Calculate the mean absolute deviations
	path_length_mabsd = gsl_stats_absdev(path_lengths_entries, 1, size);
	path_depth_mabsd = gsl_stats_absdev(path_depths_entries, 1, size);
	retvalue_mabsd = gsl_stats_absdev(retvalues_entries, 1, size);

	// Calculate the z-scores for each of the entries
	for (i=0; i<size; i++){
		entries[i].z_score_path_length = (entries[i].path_length - path_length_mean)/path_length_mabsd ;
		entries[i].z_score_path_depth = (entries[i].path_depth - path_depth_mean)/path_depth_mabsd;
		entries[i].z_score_retValue = (entries[i].retValue - retvalue_mean)/retvalue_mabsd;
	}

	return entries;
}

double open_entries_distance(struct open_transformed_entry * entries, int size, int index1, int index2, double * params){

	double distance;
	struct open_transformed_entry entry1 = entries[index1];
	struct open_transformed_entry entry2 = entries[index2];
	double min_path_length = params[0];
	double max_path_length = params[1];
	double min_path_depth = params[2];
	double max_path_depth = params[3];
	double min_retValue = params[4];
	double max_retValue = params[5];
	double min_filename_distance = params[6];
	double max_filename_distance = params[7];
	double path_length_distance;
	double path_depth_distance;
	double filename_distance;
	double flags_distance;
	double retvalue_distance;


	// Compute the components of the distance 

	// Path length component
	path_length_distance = abs(entries[index1].z_score_path_length - entries[index2].z_score_path_length)/(max_path_length - min_path_length);
	printf("\n Path length 1 : %f",entries[index1].z_score_path_length);
	printf("\n Path length 2 : %f",entries[index2].z_score_path_length);
	printf("\n Max Path length : %f",max_path_length);
	printf("\n Min Path length : %f",min_path_length);
	printf("\nPath length component : %f", path_length_distance);

	// Path depth component
	path_depth_distance = abs(entries[index1].z_score_path_depth - entries[index2].z_score_path_depth)/(max_path_depth - min_path_depth);
    printf("\n Path depth 1 : %f",entries[index1].z_score_path_depth);
	printf("\n Path depth 2 : %f",entries[index2].z_score_path_depth);
	printf("\n Max Path depth : %f", max_path_depth);
	printf("\n Min Path depth : %f", min_path_depth);	
	printf("\nDepth component : %f", path_depth_distance);

	// Filename component
	filename_distance = levenshtein_distance(entries[index1].filename, entries[index2].filename) / (max_filename_distance - min_filename_distance);
	printf("\n Levenshtein distance : %d", levenshtein_distance(entries[index1].filename, entries[index2].filename));
	printf("\n Max filename : %f",max_filename_distance);
	printf("\n Min filename : %f",min_filename_distance);
	printf("\nFilename component : %f", filename_distance);

	// Flags component
	if (strcmp(entries[index1].flags,entries[index2].flags))
		flags_distance = 1;
	else
		flags_distance = 0;

	printf("\nFlags component : %f", flags_distance);

	// RetValue component
	retvalue_distance = abs(entries[index1].z_score_retValue - entries[index2].z_score_retValue)/(max_retValue - min_retValue);
	printf("\n Max RetValue : %f",max_retValue);
	printf("\n Min RetValue : %f", min_retValue);
	printf("\nRetValue component : %f", retvalue_distance);

	// Compute final distance 
	distance = (path_length_distance + path_depth_distance + filename_distance + flags_distance + retvalue_distance) / 5;

	return distance;

}

double open_min_max_path_length(struct open_transformed_entry * entries, int size, bool min_max){

	int i;
	double result = entries[0].z_score_path_length;

    for (i = 1; i <size; i++){
		if (!min_max){
			if (entries[i].z_score_path_length < result)
				result = entries[i].z_score_path_length;
		}
		else if (min_max){
			if (entries[i].z_score_path_length > result)
				result = entries[i].z_score_path_length;
		}
	}
	return result;

}

double open_min_max_path_depth(struct open_transformed_entry * entries, int size, bool min_max){
	
	int i;
	double result = entries[0].z_score_path_depth;
	
	for(i=1; i<size; i++){
		if (!min_max){
			if (entries[i].z_score_path_depth < result)
				result = entries[i].z_score_path_depth;
		}
		else if (min_max){
			if (entries[i].z_score_path_depth > result)
				result = entries[i].z_score_path_depth;
		}
	}
	return result;
}

double open_min_max_retValue(struct open_transformed_entry * entries, int size, bool min_max){

	int i;
	double result = entries[0].z_score_retValue;

	for(i=1; i<size; i++){
		if(!min_max){
			if (entries[i].z_score_retValue < result)
				result = entries[i].z_score_retValue;
		}
		else if (min_max){
			if(entries[i].z_score_retValue > result)
				result = entries[i].z_score_retValue;
		}
	}
	return result;
}

double open_min_max_filename(struct open_transformed_entry * entries, int size, bool min_max){

	int i,j;
	double result=0;
	double distance_matrix[size][size];
	double temp;
	// Compute levenshtein matrix

	for (i = 0; i < size; i++){
		distance_matrix[i][i] = 0;
		for (j = i +1 ; j < size; j++){
			temp = levenshtein_distance(entries[i].filename, entries[j].filename);
			distance_matrix[i][j] = temp;
			distance_matrix[j][i] = temp;
		}
	}

    /**
	printf("\n Levenshtein distance matrix :\n");
	for (i = 0; i < size ; i++){
		for(j=0; j < size ; j++)
			printf("%f-",distance_matrix[i][j]);
		printf("\n");
	}
	**/

	for (i = 0; i < size; i++)
		for (j = 0; j < size; j++){
			if (i != j) {
				if (!min_max){
					if (distance_matrix[i][j] < result)
						result = distance_matrix[i][j];
				}
				else if (min_max){
					if (distance_matrix[i][j] > result)
						result = distance_matrix[i][j];
				}
			}
		}

	return result;
}


struct open_cluster match_entry_to_cluster(struct open_cluster * clusters, int clusters_number, struct open_transformed_entry entry) {

	double distances[clusters_number];
	double min_levenshtein_distance = 0;
    double max_levenshtein_distance = 0;
	double temp,min_distance = 0;
	int i,j,result = 0;
	bool flag= false;
	// Compute the distance to each of the clusters

	for (i=0; i<clusters_number; i++){
		distances[i] = 0;
	// Path length : Chebyshev's inequality for upper bound
		distances[i] += clusters[i].path_length_variance / pow((entry.path_length - clusters[i].path_length_mean),2);

	// Path depth : Chebyshev's inequality for upper bound
		distances[i] += clusters[i].path_depth_variance / pow((entry.path_depth - clusters[i].path_depth_mean),2);

	// Filename : Least levenshtein distance
		temp = levenshtein_distance(clusters[i].filenames[0], entry.filename);
		max_levenshtein_distance = temp;
		min_levenshtein_distance = temp;
		for (j=1; j<clusters[i].cluster_size; j++){
			temp = levenshtein_distance(clusters[i].filenames[j], entry.filename);
			if (temp > max_levenshtein_distance)
				max_levenshtein_distance = temp;
			if (temp < min_levenshtein_distance)
				min_levenshtein_distance = temp;
		}

		if (max_levenshtein_distance != 0)
			distances[i] += min_levenshtein_distance / max_levenshtein_distance;
			
	// Flags : 1 if not present, 0 otherwise
		flag = false;
		for (j=0; j<clusters[i].cluster_size; j++)
			if (strcmp(entry.flags, clusters[i].flags[j]) == 0){
				flag = true;
				break;
			}
		if(!flag)
			distances[i] += 1;
			
	// RetValue : 1 if not present, 0 otherwise
		flag = false;
		for (j=0; j<clusters[i].cluster_size; j++)
			if (entry.retValue == clusters[i].retValues[j]){
				flag = true;
				break;
			}
		if(!flag)
			distances[i] += 1;
	}	
	// Return the closest cluster
	min_distance = distances[0];
	result = 0;
	for (i=1; i<clusters_number; i++)
		if (distances[i] < min_distance){
			min_distance = distances[i];
			result = i;
		}
	
	return clusters[result];

}
