#ifndef CLUSTERERS_H
#define CLUSTERERS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "common.h"

struct open_transformed_entry {
	char * syscall;
	double path_length;
	double z_score_path_length;
	double path_depth;
	double z_score_path_depth;
	char * filename;
    char * flags;
	double retValue;
	double z_score_retValue;
};


struct open_cluster {
	char * syscall;
	double path_length_mean;
	double path_length_variance;
	double path_depth_mean;
	double path_depth_variance;
	char ** filenames;
	char ** flags;
	int * retValues;
	int cluster_size;
};
	
struct open_cluster* open_cluster(struct open_entry * entries, int size, int max_clusters_number);

struct open_cluster * model_open_clusters(struct open_transformed_entry * entries, int size,  bool ** raw_clusters, int clusters_number);

struct open_transformed_entry * open_transform_data(struct open_entry * entries, int size);

struct open_transformed_entry * open_normalize_data(struct open_transformed_entry * entries, int size);

double open_entries_distance(struct open_transformed_entry * entries, int size, int index1, int index2, double * params);

double open_min_max_retValue(struct open_transformed_entry * entries, int size, bool min_max);

double open_min_max_path_depth(struct open_transformed_entry * entries, int size, bool min_max);

double open_min_max_path_length(struct open_transformed_entry * entries, int size, bool min_max);

double open_min_max_filename(struct open_transformed_entry * entries, int size, bool min_max);

bool ** hierarchical_clustering(double ** distance_matrix, int size, int max_clusters_number);

double compute_cluster_distances(bool * cluster1, bool * cluster2, double ** distance_matrix, int size);

struct open_cluster match_entry_to_cluster(struct open_cluster * clusters, int clusters_number, struct open_transformed_entry entry);

#endif
